# AI 工程约束系统统一入口

本文件是安装后各 AI 客户端的统一薄入口。

## 会话启动

1. 从项目根目录运行 `python .ai/system/aic.py status --json`，核对安装状态和包完整性。
2. 若状态中心尚未初始化，运行 `python .ai/system/aic.py state init --project-name "<项目名>" --json`；不得直接创建或编辑状态文件。
3. 运行 `python .ai/system/aic.py session start --client "<客户端>" --json`，保存会话 ID 和启动时读取的状态修订号。
4. 运行 `python .ai/system/aic.py state show --json`，以其中的活动任务和推荐下一步作为续做依据；不得用聊天记忆覆盖结构化状态。
5. 读取 `.ai/AGENTS.md`、`.ai/AI-INSTRUCTIONS.md` 和 `.ai/.ai-engineering/RULES_INDEX.md`，继续使用已保留的 V6 规则与专业规范。
6. 修改前检查 Git 和用户已有改动。状态写入必须使用 `task`、`next`、`legacy` 等统一命令，并携带刚读取的 `expected-state-revision`；冲突后重新读取，禁止直接覆盖。
7. 使用 `evidence add` 保存真实测试或产物证据；使用 `task transition` 更新任务，不得绕过完成门禁。
8. 重要节点使用 `summary generate` 生成确定性总结并核验；节点结束前运行 `state verify` 和 `view render`。

## 当前能力边界

这是 7.0.0-alpha.3 阶段 3 候选包，已经实现统一状态内核、任务状态转换注册表、证据哈希与有效性、证据过期传播、完成门禁以及从状态、Git 和证据生成并去重的研发节点总结。

自动环境漂移发现、总结自动触发、范围锁、租约、异常会话接管和损坏事件链修复仍属于后续阶段。当前本机状态写锁只阻止同一工作副本同时写入，不得声称可以协调不同计算机或仓库副本。

不得把本阶段候选包描述为已经满足最终目标基线。
