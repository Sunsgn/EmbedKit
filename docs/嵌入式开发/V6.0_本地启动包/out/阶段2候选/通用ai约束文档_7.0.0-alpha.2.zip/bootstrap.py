#!/usr/bin/env python3
"""Safe, transactional installer for the self-contained AI constraint package."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import sys
from typing import Any, Iterable
import uuid
import zipfile


SCHEMA_VERSION = "1.0.0"
MANIFEST_NAME = "PACKAGE_MANIFEST.json"
PACKAGE_NAME = "PACKAGE.json"
BEGIN_MARKER = b"<!-- AI-CONSTRAINTS:BEGIN managed version=1 -->"
END_MARKER = b"<!-- AI-CONSTRAINTS:END managed -->"
MAX_MEMBERS = 2000
MAX_MEMBER_SIZE = 10 * 1024 * 1024
MAX_TOTAL_SIZE = 50 * 1024 * 1024
MAX_COMPRESSION_RATIO = 200
MAX_ENTRYPOINT_SIZE = 2 * 1024 * 1024


def configure_stdio() -> None:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def new_id(prefix: str) -> str:
    return prefix + uuid.uuid4().hex


class AICError(RuntimeError):
    def __init__(self, code: str, message: str, **details: Any):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details


def response(ok: bool, code: str, message: str, *, retryable: bool = False,
             requires_user_action: bool = False, **details: Any) -> dict[str, Any]:
    return {
        "ok": ok,
        "code": code,
        "message": message,
        "retryable": retryable,
        "requires_user_action": requires_user_action,
        "details": details,
    }


def emit(data: dict[str, Any], as_json: bool) -> int:
    if as_json:
        print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(("PASS" if data["ok"] else "FAIL") + f" [{data['code']}] {data['message']}")
        if data.get("details"):
            print(json.dumps(data["details"], ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if data["ok"] else 2


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_json(data: Any) -> bytes:
    return (json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.parent / ("." + path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        fd = os.open(temp, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        if temp.exists():
            temp.unlink()


def load_json(path: Path, code: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise AICError(code, f"无法读取 JSON: {path}", error=str(exc)) from exc
    if not isinstance(value, dict):
        raise AICError(code, f"JSON 根必须是对象: {path}")
    return value


def safe_zip_name(name: str) -> PurePosixPath:
    if not name or "\x00" in name or "\\" in name:
        raise AICError("PACKAGE_UNSAFE_PATH", "ZIP 成员路径非法", member=name)
    if name.startswith(("/", "//")) or re.match(r"^[A-Za-z]:", name):
        raise AICError("PACKAGE_UNSAFE_PATH", "ZIP 成员为绝对路径", member=name)
    path = PurePosixPath(name)
    if any(part in {"", ".", ".."} for part in path.parts):
        raise AICError("PACKAGE_UNSAFE_PATH", "ZIP 成员包含路径穿越或空组件", member=name)
    return path


def safe_relative(value: str, label: str) -> PurePosixPath:
    try:
        path = safe_zip_name(value)
    except AICError as exc:
        raise AICError("PATH_INVALID_RELATIVE", f"{label} 不是安全相对路径", value=value) from exc
    return path


def is_reparse_or_link(path: Path) -> bool:
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    attrs = getattr(info, "st_file_attributes", 0)
    reparse_flag = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    return stat.S_ISLNK(info.st_mode) or bool(attrs & reparse_flag)


def target_path(root: Path, relative: str, *, check_links: bool = True) -> Path:
    rel = safe_relative(relative, "target")
    root = root.resolve()
    lexical = root.joinpath(*rel.parts)
    resolved = lexical.resolve(strict=False)
    if not resolved.is_relative_to(root):
        raise AICError("PATH_ESCAPE", "目标路径逃逸项目根目录", target=relative, resolved=str(resolved))
    if check_links:
        current = root
        for part in rel.parts:
            current = current / part
            if current.exists() and is_reparse_or_link(current):
                raise AICError("PATH_REPARSE_POINT", "目标路径包含符号链接或重解析点", target=relative, component=str(current))
    return lexical


def zip_preflight(zip_path: Path) -> dict[str, Any]:
    if not zip_path.is_file():
        raise AICError("PACKAGE_NOT_FOUND", "ZIP 不存在", path=str(zip_path))
    seen: set[str] = set()
    total = 0
    files = 0
    try:
        with zipfile.ZipFile(zip_path) as archive:
            infos = archive.infolist()
            if len(infos) > MAX_MEMBERS:
                raise AICError("PACKAGE_MEMBER_LIMIT", "ZIP 成员数量超限", actual=len(infos), limit=MAX_MEMBERS)
            for info in infos:
                safe_zip_name(info.filename.rstrip("/") if info.is_dir() else info.filename)
                key = info.filename.rstrip("/").casefold()
                if key in seen:
                    raise AICError("PACKAGE_DUPLICATE_PATH", "ZIP 存在重复或大小写碰撞路径", member=info.filename)
                seen.add(key)
                if info.flag_bits & 0x1:
                    raise AICError("PACKAGE_ENCRYPTED_MEMBER", "不允许加密 ZIP 成员", member=info.filename)
                mode = (info.external_attr >> 16) & 0xFFFF
                file_type = stat.S_IFMT(mode)
                if file_type and file_type not in {stat.S_IFREG, stat.S_IFDIR}:
                    raise AICError("PACKAGE_SPECIAL_FILE", "不允许符号链接或特殊文件", member=info.filename, mode=oct(mode))
                if info.is_dir():
                    continue
                files += 1
                if info.file_size > MAX_MEMBER_SIZE:
                    raise AICError("PACKAGE_MEMBER_SIZE_LIMIT", "ZIP 单文件解压大小超限", member=info.filename, actual=info.file_size, limit=MAX_MEMBER_SIZE)
                total += info.file_size
                if total > MAX_TOTAL_SIZE:
                    raise AICError("PACKAGE_TOTAL_SIZE_LIMIT", "ZIP 总解压大小超限", actual=total, limit=MAX_TOTAL_SIZE)
                ratio = info.file_size / max(info.compress_size, 1)
                if info.file_size > 1024 * 1024 and ratio > MAX_COMPRESSION_RATIO:
                    raise AICError("PACKAGE_COMPRESSION_RATIO_LIMIT", "ZIP 成员压缩比异常", member=info.filename, ratio=ratio)
            bad = archive.testzip()
            if bad:
                raise AICError("PACKAGE_CRC_FAILED", "ZIP CRC 校验失败", member=bad)
    except zipfile.BadZipFile as exc:
        raise AICError("PACKAGE_INVALID_ZIP", "ZIP 格式无效", error=str(exc)) from exc
    return {"members": len(seen), "files": files, "uncompressed_bytes": total, "sha256": sha256_file(zip_path)}


def read_zip_json(archive: zipfile.ZipFile, member: str, code: str) -> dict[str, Any]:
    try:
        value = json.loads(archive.read(member).decode("utf-8"))
    except (KeyError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise AICError(code, f"ZIP 内 JSON 无法读取: {member}", error=str(exc)) from exc
    if not isinstance(value, dict):
        raise AICError(code, f"ZIP 内 JSON 根必须是对象: {member}")
    return value


def verify_package(zip_path: Path) -> dict[str, Any]:
    preflight = zip_preflight(zip_path)
    with zipfile.ZipFile(zip_path) as archive:
        package = read_zip_json(archive, PACKAGE_NAME, "PACKAGE_IDENTITY_INVALID")
        manifest = read_zip_json(archive, MANIFEST_NAME, "PACKAGE_MANIFEST_INVALID")
        if package.get("schema") != "aic.package" or package.get("schema_version") != "1.0.0":
            raise AICError("PACKAGE_IDENTITY_UNSUPPORTED", "PACKAGE.json 格式不兼容")
        if manifest.get("schema") != "aic.package-manifest" or manifest.get("schema_version") != "1.0.0":
            raise AICError("PACKAGE_MANIFEST_UNSUPPORTED", "PACKAGE_MANIFEST.json 格式不兼容")
        if manifest.get("package_id") != package.get("package_id") or manifest.get("package_version") != package.get("package_version"):
            raise AICError("PACKAGE_IDENTITY_MISMATCH", "包身份与清单不一致")
        entries = manifest.get("files")
        if not isinstance(entries, list):
            raise AICError("PACKAGE_MANIFEST_INVALID", "清单 files 必须是数组")
        actual = {info.filename for info in archive.infolist() if not info.is_dir() and info.filename != MANIFEST_NAME}
        listed: set[str] = set()
        targets: set[str] = set()
        for entry in entries:
            if not isinstance(entry, dict):
                raise AICError("PACKAGE_MANIFEST_INVALID", "清单文件项必须是对象")
            member = entry.get("path")
            if not isinstance(member, str):
                raise AICError("PACKAGE_MANIFEST_INVALID", "清单路径缺失")
            safe_zip_name(member)
            if member in listed:
                raise AICError("PACKAGE_MANIFEST_DUPLICATE", "清单路径重复", member=member)
            listed.add(member)
            if member not in actual:
                raise AICError("PACKAGE_MANIFEST_FILE_MISSING", "清单成员在 ZIP 中不存在", member=member)
            data = archive.read(member)
            actual_hash = sha256_bytes(data)
            if actual_hash != entry.get("sha256") or len(data) != entry.get("size"):
                raise AICError("PACKAGE_MANIFEST_HASH_MISMATCH", "成员哈希或大小不匹配", member=member)
            strategy = entry.get("strategy")
            target = entry.get("target")
            if strategy not in {"package_file", "managed_block"} or not isinstance(target, str):
                raise AICError("PACKAGE_MANIFEST_STRATEGY_INVALID", "清单安装策略无效", member=member)
            safe_relative(target, "manifest target")
            target_key = target.casefold()
            if target_key in targets:
                raise AICError("PACKAGE_TARGET_COLLISION", "多个成员映射到同一目标", target=target)
            targets.add(target_key)
        if listed != actual:
            raise AICError("PACKAGE_MANIFEST_FILESET_MISMATCH", "ZIP 文件集合与清单不一致", unlisted=sorted(actual - listed), stale=sorted(listed - actual))
    return {"preflight": preflight, "package": package, "manifest": manifest}


def file_snapshot(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"exists": False, "kind": "missing", "sha256": None, "size": 0}
    if is_reparse_or_link(path):
        return {"exists": True, "kind": "reparse", "sha256": None, "size": 0}
    if not path.is_file():
        return {"exists": True, "kind": "other", "sha256": None, "size": 0}
    return {"exists": True, "kind": "file", "sha256": sha256_file(path), "size": path.stat().st_size}


def managed_block(data: bytes) -> bytes:
    begin_count = data.count(BEGIN_MARKER)
    end_count = data.count(END_MARKER)
    if begin_count != 1 or end_count != 1:
        raise AICError("PACKAGE_ENTRYPOINT_INVALID", "入口模板必须且只能包含一个完整受控块")
    start = data.index(BEGIN_MARKER)
    end = data.index(END_MARKER, start) + len(END_MARKER)
    block = data[start:end]
    try:
        block.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise AICError("PACKAGE_ENTRYPOINT_INVALID", "入口模板不是 UTF-8") from exc
    return block


def merge_managed(existing: bytes | None, block: bytes) -> tuple[str, bytes, str | None]:
    if existing is None:
        return "CREATE_ENTRYPOINT", block + b"\n", None
    if len(existing) > MAX_ENTRYPOINT_SIZE:
        return "CONFLICT", existing, "ENTRYPOINT_SIZE_LIMIT"
    begins = existing.count(b"<!-- AI-CONSTRAINTS:BEGIN managed")
    ends = existing.count(END_MARKER)
    if begins == 0 and ends == 0:
        separator = b"" if not existing else (b"\n" if existing.endswith((b"\n", b"\r")) else b"\n\n")
        return "MERGE_MANAGED_BLOCK", existing + separator + block + b"\n", None
    if begins != 1 or ends != 1:
        return "CONFLICT", existing, "ENTRYPOINT_MARKERS_INVALID"
    start = existing.find(b"<!-- AI-CONSTRAINTS:BEGIN managed")
    end = existing.find(END_MARKER, start)
    if end < 0:
        return "CONFLICT", existing, "ENTRYPOINT_MARKERS_INVALID"
    current = existing[start:end + len(END_MARKER)]
    if current == block:
        return "KEEP", existing, None
    return "CONFLICT", existing, "ENTRYPOINT_MANAGED_BLOCK_MODIFIED"


def load_previous_state(root: Path) -> tuple[dict[str, Any] | None, str | None]:
    path = root / ".ai" / "INSTALL_STATE.json"
    if not path.exists():
        return None, None
    if is_reparse_or_link(path) or not path.is_file():
        return None, "INSTALL_STATE_UNSAFE"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None, "INSTALL_STATE_INVALID"
    if not isinstance(data, dict) or data.get("schema") != "aic.install-state":
        return None, "INSTALL_STATE_UNSUPPORTED"
    return data, None


def owned_hashes(state: dict[str, Any] | None) -> dict[str, str]:
    if not state:
        return {}
    result: dict[str, str] = {}
    for item in state.get("package_files", []):
        if isinstance(item, dict) and isinstance(item.get("target"), str) and isinstance(item.get("sha256"), str):
            result[item["target"].casefold()] = item["sha256"]
    return result


def legacy_owned_hashes(root: Path) -> tuple[dict[str, str], bool]:
    """Recognize an unmodified V6 package using its complete Markdown manifest."""
    manifest_path = root / ".ai" / ".ai-engineering" / "installation" / "PACKAGE_MANIFEST.md"
    if not manifest_path.is_file() or is_reparse_or_link(manifest_path):
        return {}, False
    try:
        text = manifest_path.read_text(encoding="utf-8")
    except OSError:
        return {}, False
    entries = re.findall(r"^\| `([^`]+)` \| `([0-9a-f]{64})` \|$", text, re.MULTILINE)
    if not entries:
        return {}, False
    owned: dict[str, str] = {}
    for relative, expected in entries:
        target_rel = ".ai/" + relative
        try:
            path = target_path(root, target_rel)
        except AICError:
            return {}, False
        if not path.is_file() or is_reparse_or_link(path) or sha256_file(path) != expected:
            return {}, False
        owned[target_rel.casefold()] = expected
    owned[".ai/.ai-engineering/installation/package_manifest.md"] = sha256_file(manifest_path)
    return owned, True


def build_plan(zip_path: Path, root: Path) -> dict[str, Any]:
    verified = verify_package(zip_path)
    package = verified["package"]
    manifest = verified["manifest"]
    root = root.resolve()
    if not root.is_dir():
        raise AICError("PROJECT_ROOT_NOT_FOUND", "项目根目录不存在", target=str(root))
    if is_reparse_or_link(root):
        raise AICError("PROJECT_ROOT_REPARSE_POINT", "项目根目录本身是符号链接或重解析点", target=str(root))
    previous_state, previous_error = load_previous_state(root)
    legacy_owned, legacy_verified = legacy_owned_hashes(root)
    owned = {**legacy_owned, **owned_hashes(previous_state)}
    operations: list[dict[str, Any]] = []
    conflicts: list[dict[str, Any]] = []
    with zipfile.ZipFile(zip_path) as archive:
        entries = list(manifest["files"])
        # The manifest cannot list itself; install a verified copy explicitly.
        entries.append({
            "path": MANIFEST_NAME,
            "sha256": sha256_bytes(archive.read(MANIFEST_NAME)),
            "size": len(archive.read(MANIFEST_NAME)),
            "strategy": "package_file",
            "target": ".ai/system/PACKAGE_MANIFEST.json",
        })
        for index, entry in enumerate(entries):
            member = entry["path"]
            target_rel = entry["target"]
            target = target_path(root, target_rel)
            before = file_snapshot(target)
            source = archive.read(member)
            if before["kind"] in {"reparse", "other"}:
                op = {"index": index, "kind": "CONFLICT", "member": member, "target": target_rel, "before": before, "reason": "TARGET_UNSAFE_TYPE"}
                operations.append(op); conflicts.append(op); continue
            if entry["strategy"] == "managed_block":
                existing = target.read_bytes() if before["exists"] else None
                block = managed_block(source)
                kind, final, reason = merge_managed(existing, block)
                op = {
                    "index": index, "kind": kind, "strategy": "managed_block", "member": member,
                    "target": target_rel, "before": before, "post_sha256": sha256_bytes(final),
                    "managed_block_sha256": sha256_bytes(block), "reason": reason,
                }
                operations.append(op)
                if kind == "CONFLICT": conflicts.append(op)
                continue
            expected = entry["sha256"]
            if not before["exists"]:
                kind = "CREATE"
            elif before["sha256"] == expected:
                kind = "KEEP"
            elif owned.get(target_rel.casefold()) == before["sha256"]:
                kind = "REPLACE_PACKAGE_OWNED"
            else:
                kind = "CONFLICT"
            op = {
                "index": index, "kind": kind, "strategy": "package_file", "member": member,
                "target": target_rel, "before": before, "post_sha256": expected,
                "reason": "TARGET_EXISTS_WITH_UNKNOWN_CONTENT" if kind == "CONFLICT" else None,
            }
            operations.append(op)
            if kind == "CONFLICT": conflicts.append(op)
    plan = {
        "schema": "aic.install-plan",
        "schema_version": SCHEMA_VERSION,
        "plan_id": new_id("PLAN-"),
        "created_at": now(),
        "package": {
            "path": str(zip_path.resolve()),
            "sha256": verified["preflight"]["sha256"],
            "package_id": package["package_id"],
            "package_version": package["package_version"],
            "structure_version": package["structure_version"],
        },
        "target_root": str(root),
        "previous_install_state": previous_state.get("package") if previous_state else None,
        "previous_install_error": previous_error,
        "legacy_package_verified": legacy_verified,
        "install_state_before": file_snapshot(root / ".ai" / "INSTALL_STATE.json"),
        "operations": operations,
        "conflicts": conflicts,
        "can_apply": not conflicts and previous_error is None,
        "preflight": verified["preflight"],
    }
    return plan


def ensure_plan_output(path: Path, root: Path) -> Path:
    path = path.resolve(strict=False)
    if path.is_relative_to(root.resolve()):
        raise AICError("INSTALL_PLAN_INSIDE_PROJECT", "安装计划和事务目录必须位于项目外", output=str(path))
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise AICError("INSTALL_PLAN_EXISTS", "拒绝覆盖已有安装计划", output=str(path))
    return path


def same_snapshot(path: Path, expected: dict[str, Any]) -> bool:
    current = file_snapshot(path)
    return current == expected


def make_backup(tx_dir: Path, target: Path, index: int) -> str:
    rel = Path("backup") / f"{index:05d}.bin"
    dest = tx_dir / rel
    atomic_write(dest, target.read_bytes())
    return rel.as_posix()


def missing_parent_dirs(root: Path, target: Path) -> list[str]:
    missing: list[Path] = []
    current = target.parent
    while current != root and current.is_relative_to(root):
        if current.exists():
            break
        missing.append(current)
        current = current.parent
    return [path.relative_to(root).as_posix() for path in reversed(missing)]


def record_tx(tx_path: Path, tx: dict[str, Any]) -> None:
    tx["updated_at"] = now()
    atomic_write(tx_path, canonical_json(tx))


def read_member(archive: zipfile.ZipFile, op: dict[str, Any], target: Path) -> bytes:
    source = archive.read(op["member"])
    if op["strategy"] == "package_file":
        return source
    block = managed_block(source)
    existing = target.read_bytes() if target.exists() else None
    kind, final, reason = merge_managed(existing, block)
    if kind != op["kind"] or reason:
        raise AICError("INSTALL_PLAN_STALE", "入口文件自计划生成后发生变化", target=op["target"], planned=op["kind"], actual=kind, reason=reason)
    return final


def apply_file_operation(tx: dict[str, Any], tx_path: Path, archive: zipfile.ZipFile, op: dict[str, Any]) -> None:
    root = Path(tx["target_root"])
    tx_dir = tx_path.parent
    target = target_path(root, op["target"])
    if op["kind"] == "KEEP":
        if not same_snapshot(target, op["before"]):
            raise AICError("INSTALL_PLAN_STALE", "KEEP 目标自计划生成后发生变化", target=op["target"])
        return
    if not same_snapshot(target, op["before"]):
        raise AICError("INSTALL_PLAN_STALE", "目标自计划生成后发生变化", target=op["target"])
    content = read_member(archive, op, target)
    if sha256_bytes(content) != op["post_sha256"]:
        raise AICError("INSTALL_POST_HASH_MISMATCH", "计划后内容哈希不一致", target=op["target"])
    backup = None
    if target.exists():
        backup = make_backup(tx_dir, target, op["index"])
    tx["in_flight"] = {
        "index": op["index"], "target": op["target"], "existed": target.exists(),
        "pre_sha256": op["before"].get("sha256"), "post_sha256": op["post_sha256"],
        "backup": backup, "kind": op["kind"], "created_dirs": missing_parent_dirs(root, target),
    }
    record_tx(tx_path, tx)
    atomic_write(target, content)
    tx["applied"].append(tx["in_flight"])
    tx["in_flight"] = None
    record_tx(tx_path, tx)


def write_generated(tx: dict[str, Any], tx_path: Path, target_rel: str, data: bytes, kind: str,
                    expected_before: dict[str, Any] | None = None) -> None:
    root = Path(tx["target_root"])
    target = target_path(root, target_rel)
    before = file_snapshot(target)
    if expected_before is not None and before != expected_before:
        raise AICError("INSTALL_PLAN_STALE", "生成文件目标自计划后发生变化", target=target_rel, expected=expected_before, actual=before)
    backup = make_backup(tx_path.parent, target, 90000 + len(tx["applied"])) if target.exists() else None
    item = {
        "index": 90000 + len(tx["applied"]), "target": target_rel, "existed": target.exists(),
        "pre_sha256": before.get("sha256"), "post_sha256": sha256_bytes(data),
        "backup": backup, "kind": kind, "created_dirs": missing_parent_dirs(root, target),
    }
    tx["in_flight"] = item
    record_tx(tx_path, tx)
    atomic_write(target, data)
    tx["applied"].append(item)
    tx["in_flight"] = None
    record_tx(tx_path, tx)


def install_state_for(tx: dict[str, Any], plan: dict[str, Any]) -> dict[str, Any]:
    package_files = []
    managed = []
    for op in plan["operations"]:
        item = {"member": op["member"], "target": op["target"], "sha256": op["post_sha256"]}
        if op["strategy"] == "package_file":
            package_files.append(item)
        else:
            item["managed_block_sha256"] = op["managed_block_sha256"]
            managed.append(item)
    return {
        "schema": "aic.install-state",
        "schema_version": SCHEMA_VERSION,
        "status": "INSTALLED",
        "package": plan["package"],
        "install_transaction_id": tx["transaction_id"],
        "installed_at": tx["started_at"],
        "installer_version": "7.0.0-alpha.1",
        "package_files": sorted(package_files, key=lambda item: item["target"]),
        "managed_entrypoints": sorted(managed, key=lambda item: item["target"]),
        "ownership": {
            "package": [".ai/system/", "managed entrypoint blocks"],
            "project": [".ai/project/", ".ai/extensions/", ".ai/local/"],
            "state": [".ai/state/", ".ai/run/", ".ai/tasks/", ".ai/evidence/", ".ai/summaries/"],
            "audit": [".ai/INSTALL_STATE.json", ".ai/audit/", ".ai/legacy/"],
            "views": [".ai/views/"],
        },
    }


def recover_in_flight(tx: dict[str, Any], tx_path: Path) -> None:
    item = tx.get("in_flight")
    if not item:
        return
    root = Path(tx["target_root"])
    target = target_path(root, item["target"])
    current = file_snapshot(target)
    if current.get("sha256") == item["post_sha256"]:
        tx["applied"].append(item)
        tx["in_flight"] = None
        record_tx(tx_path, tx)
        return
    if item["existed"] and current.get("sha256") == item["pre_sha256"]:
        tx["in_flight"] = None
        record_tx(tx_path, tx)
        return
    if not item["existed"] and not current["exists"]:
        tx["in_flight"] = None
        record_tx(tx_path, tx)
        return
    tx["status"] = "NEEDS_REVIEW"
    tx["error"] = {"code": "INSTALL_IN_FLIGHT_AMBIGUOUS", "target": item["target"], "current": current}
    record_tx(tx_path, tx)
    raise AICError("INSTALL_IN_FLIGHT_AMBIGUOUS", "无法安全判断中断写入结果", target=item["target"])


def execute_transaction(tx_path: Path) -> dict[str, Any]:
    tx = load_json(tx_path, "INSTALL_TRANSACTION_INVALID")
    if tx.get("status") == "COMMITTED":
        return response(True, "INSTALL_ALREADY_COMMITTED", "事务已经提交", transaction=str(tx_path))
    if tx.get("status") in {"ROLLED_BACK", "ROLLING_BACK", "NEEDS_REVIEW"}:
        raise AICError("INSTALL_TRANSACTION_NOT_RESUMABLE", "事务当前状态不能继续", status=tx.get("status"))
    plan_path = Path(tx["plan_path"])
    if sha256_file(plan_path) != tx.get("plan_sha256"):
        raise AICError("INSTALL_PLAN_CHANGED", "安装计划自事务创建后发生变化")
    plan = load_json(plan_path, "INSTALL_PLAN_INVALID")
    zip_path = Path(plan["package"]["path"])
    if sha256_file(zip_path) != plan["package"]["sha256"]:
        raise AICError("PACKAGE_CHANGED_AFTER_PLAN", "ZIP 自计划生成后发生变化")
    verify_package(zip_path)
    recover_in_flight(tx, tx_path)
    applied_indices = {item["index"] for item in tx["applied"] if item["index"] < 90000}
    for item in tx["applied"]:
        target = target_path(Path(tx["target_root"]), item["target"])
        if file_snapshot(target).get("sha256") != item["post_sha256"]:
            tx["status"] = "NEEDS_REVIEW"
            tx["error"] = {"code": "INSTALL_APPLIED_TARGET_CHANGED", "target": item["target"]}
            record_tx(tx_path, tx)
            raise AICError("INSTALL_APPLIED_TARGET_CHANGED", "已应用文件在恢复前被修改", target=item["target"])
    if not tx["applied"]:
        current_plan = build_plan(zip_path, Path(tx["target_root"]))
        if current_plan["operations"] != plan["operations"] or current_plan["install_state_before"] != plan["install_state_before"]:
            raise AICError("INSTALL_PLAN_STALE", "项目状态自计划生成后发生变化")
    tx["status"] = "APPLYING"
    tx["error"] = None
    record_tx(tx_path, tx)
    fail_after = None
    if os.environ.get("AIC_TEST_MODE") == "1" and os.environ.get("AIC_TEST_FAIL_AFTER"):
        fail_after = int(os.environ["AIC_TEST_FAIL_AFTER"])
    try:
        with zipfile.ZipFile(zip_path) as archive:
            for op in plan["operations"]:
                if op["kind"] == "CONFLICT":
                    raise AICError("INSTALL_PLAN_HAS_CONFLICTS", "安装计划包含冲突")
                if op["index"] in applied_indices:
                    continue
                apply_file_operation(tx, tx_path, archive, op)
                if fail_after is not None and len([x for x in tx["applied"] if x["index"] < 90000]) >= fail_after:
                    raise RuntimeError("INJECTED_TEST_FAILURE")
        tx["phase"] = "INSTALL_STATE"
        record_tx(tx_path, tx)
        if not any(item["kind"] == "WRITE_INSTALL_STATE" for item in tx["applied"]):
            state = install_state_for(tx, plan)
            write_generated(
                tx, tx_path, ".ai/INSTALL_STATE.json", canonical_json(state), "WRITE_INSTALL_STATE",
                expected_before=plan["install_state_before"],
            )
        tx["phase"] = "AUDIT"
        record_tx(tx_path, tx)
        audit_rel = f".ai/audit/transactions/{tx['transaction_id']}.json"
        if not any(item["kind"] == "WRITE_AUDIT" for item in tx["applied"]):
            audit = {
                "schema": "aic.install-audit",
                "schema_version": SCHEMA_VERSION,
                "transaction_id": tx["transaction_id"],
                "status": "COMMITTED",
                "package": plan["package"],
                "target_root": tx["target_root"],
                "external_transaction_record": str(tx_path),
                "started_at": tx["started_at"],
                "completed_at": now(),
                "operation_count": len(plan["operations"]),
                "changed_count": len([op for op in plan["operations"] if op["kind"] not in {"KEEP"}]),
            }
            write_generated(
                tx, tx_path, audit_rel, canonical_json(audit), "WRITE_AUDIT",
                expected_before={"exists": False, "kind": "missing", "sha256": None, "size": 0},
            )
        tx["phase"] = "DONE"
        tx["status"] = "COMMITTED"
        tx["completed_at"] = now()
        record_tx(tx_path, tx)
        return response(True, "INSTALL_COMMITTED", "安装事务已提交", transaction=str(tx_path), target=tx["target_root"])
    except Exception as exc:
        tx = load_json(tx_path, "INSTALL_TRANSACTION_INVALID")
        if tx.get("status") != "NEEDS_REVIEW":
            tx["status"] = "FAILED"
            tx["error"] = {"code": getattr(exc, "code", "INSTALL_EXECUTION_FAILED"), "message": str(exc)}
            record_tx(tx_path, tx)
        raise


def rollback_transaction(tx_path: Path) -> dict[str, Any]:
    tx = load_json(tx_path, "INSTALL_TRANSACTION_INVALID")
    if tx.get("status") == "ROLLED_BACK":
        return response(True, "INSTALL_ALREADY_ROLLED_BACK", "事务已经回滚", transaction=str(tx_path))
    if tx.get("status") == "COMMITTED":
        # A committed installation is still reversible while backups exist.
        pass
    recover_in_flight(tx, tx_path)
    tx["status"] = "ROLLING_BACK"
    tx["rollback_conflicts"] = []
    record_tx(tx_path, tx)
    root = Path(tx["target_root"])
    for item in reversed(tx.get("applied", [])):
        target = target_path(root, item["target"])
        current = file_snapshot(target)
        if current.get("sha256") != item["post_sha256"]:
            tx["rollback_conflicts"].append({"target": item["target"], "reason": "TARGET_CHANGED_AFTER_APPLY", "current": current})
            continue
        if item["existed"]:
            backup = tx_path.parent / item["backup"]
            if not backup.is_file() or sha256_file(backup) != item["pre_sha256"]:
                tx["rollback_conflicts"].append({"target": item["target"], "reason": "BACKUP_MISSING_OR_INVALID"})
                continue
            atomic_write(target, backup.read_bytes())
        else:
            target.unlink()
        for rel in reversed(item.get("created_dirs", [])):
            directory = target_path(root, rel)
            try:
                directory.rmdir()
            except OSError:
                pass
    if tx["rollback_conflicts"]:
        tx["status"] = "NEEDS_REVIEW"
        tx["error"] = {"code": "INSTALL_ROLLBACK_CONFLICT"}
        record_tx(tx_path, tx)
        return response(False, "INSTALL_ROLLBACK_CONFLICT", "回滚存在冲突，未覆盖外部变化", requires_user_action=True, transaction=str(tx_path), conflicts=tx["rollback_conflicts"])
    tx["status"] = "ROLLED_BACK"
    tx["rolled_back_at"] = now()
    record_tx(tx_path, tx)
    return response(True, "INSTALL_ROLLED_BACK", "安装事务已安全回滚", transaction=str(tx_path))


def start_transaction(plan_path: Path) -> Path:
    plan = load_json(plan_path, "INSTALL_PLAN_INVALID")
    if plan.get("schema") != "aic.install-plan" or plan.get("schema_version") != SCHEMA_VERSION:
        raise AICError("INSTALL_PLAN_UNSUPPORTED", "安装计划格式不兼容")
    if not plan.get("can_apply") or plan.get("conflicts"):
        raise AICError("INSTALL_PLAN_HAS_CONFLICTS", "安装计划包含冲突，不能应用", conflicts=plan.get("conflicts"))
    target_root = Path(plan["target_root"]).resolve()
    if plan_path.resolve().is_relative_to(target_root):
        raise AICError("INSTALL_PLAN_INSIDE_PROJECT", "安装计划必须位于项目外")
    tx_id = new_id("TXN-")
    tx_dir = plan_path.parent / "transactions" / tx_id
    tx_dir.mkdir(parents=True, exist_ok=False)
    tx_path = tx_dir / "transaction.json"
    tx = {
        "schema": "aic.install-transaction",
        "schema_version": SCHEMA_VERSION,
        "transaction_id": tx_id,
        "status": "PREPARED",
        "phase": "FILES",
        "plan_path": str(plan_path.resolve()),
        "plan_sha256": sha256_file(plan_path),
        "target_root": plan["target_root"],
        "started_at": now(),
        "updated_at": now(),
        "applied": [],
        "in_flight": None,
        "error": None,
    }
    record_tx(tx_path, tx)
    return tx_path


def execute_with_context(tx_path: Path) -> dict[str, Any]:
    try:
        return execute_transaction(tx_path)
    except AICError as exc:
        exc.details.setdefault("transaction", str(tx_path))
        raise
    except Exception as exc:
        raise AICError(
            "INSTALL_EXECUTION_FAILED", "安装执行失败，可使用事务记录恢复或回滚",
            transaction=str(tx_path), error=repr(exc),
        ) from exc


def inspect_target(root: Path) -> dict[str, Any]:
    root = root.resolve()
    markers = []
    for name in [".git", "CMakeLists.txt", "package.json", "pyproject.toml", "Makefile", "platformio.ini", ".project"]:
        if (root / name).exists():
            markers.append(name)
    entrypoints = {}
    for rel in ["AGENTS.md", "CLAUDE.md", "GEMINI.md", ".github/copilot-instructions.md"]:
        path = target_path(root, rel)
        entrypoints[rel] = file_snapshot(path)
    previous, error = load_previous_state(root)
    return {
        "root": str(root),
        "markers": markers,
        "entrypoints": entrypoints,
        "ai_directory": file_snapshot(root / ".ai"),
        "previous_install": previous.get("package") if previous else None,
        "previous_install_error": error,
    }


def main() -> int:
    configure_stdio()
    parser = argparse.ArgumentParser(description="AI constraint package bootstrap")
    parser.add_argument("--json", action="store_true")
    sub = parser.add_subparsers(dest="command", required=True)
    inspect = sub.add_parser("inspect")
    inspect.add_argument("--zip", required=True)
    inspect.add_argument("--target", required=True)
    inspect.add_argument("--expected-sha256", default="")
    inspect.add_argument("--json", action="store_true")
    plan_cmd = sub.add_parser("plan")
    plan_cmd.add_argument("--zip", required=True)
    plan_cmd.add_argument("--target", required=True)
    plan_cmd.add_argument("--output", required=True)
    plan_cmd.add_argument("--expected-sha256", default="")
    plan_cmd.add_argument("--json", action="store_true")
    apply_cmd = sub.add_parser("apply")
    apply_cmd.add_argument("--plan", required=True)
    apply_cmd.add_argument("--json", action="store_true")
    resume_cmd = sub.add_parser("resume")
    resume_cmd.add_argument("--transaction", required=True)
    resume_cmd.add_argument("--json", action="store_true")
    rollback_cmd = sub.add_parser("rollback")
    rollback_cmd.add_argument("--transaction", required=True)
    rollback_cmd.add_argument("--json", action="store_true")
    args = parser.parse_args()
    as_json = bool(getattr(args, "json", False))
    try:
        if args.command == "inspect":
            zip_path = Path(args.zip).resolve()
            if args.expected_sha256 and sha256_file(zip_path).lower() != args.expected_sha256.lower():
                raise AICError("PACKAGE_EXPECTED_HASH_MISMATCH", "ZIP SHA-256 与初始化指令不一致")
            verified = verify_package(zip_path)
            target = Path(args.target)
            if not target.is_dir():
                raise AICError("PROJECT_ROOT_NOT_FOUND", "项目根目录不存在", target=str(target))
            data = response(True, "INSPECT_OK", "包和目标只读检查通过", package=verified["package"], preflight=verified["preflight"], target=inspect_target(target))
        elif args.command == "plan":
            target = Path(args.target).resolve()
            zip_path = Path(args.zip).resolve()
            if args.expected_sha256 and sha256_file(zip_path).lower() != args.expected_sha256.lower():
                raise AICError("PACKAGE_EXPECTED_HASH_MISMATCH", "ZIP SHA-256 与初始化指令不一致")
            plan = build_plan(zip_path, target)
            output = ensure_plan_output(Path(args.output), target)
            atomic_write(output, canonical_json(plan))
            code = "PLAN_READY" if plan["can_apply"] else "PLAN_CREATED_WITH_CONFLICTS"
            data = response(True, code, "安装计划已生成", requires_user_action=not plan["can_apply"], plan=str(output), can_apply=plan["can_apply"], conflicts=plan["conflicts"], operation_count=len(plan["operations"]))
        elif args.command == "apply":
            plan_path = Path(args.plan).resolve()
            tx_path = start_transaction(plan_path)
            data = execute_with_context(tx_path)
        elif args.command == "resume":
            data = execute_with_context(Path(args.transaction).resolve())
        else:
            data = rollback_transaction(Path(args.transaction).resolve())
        return emit(data, as_json)
    except AICError as exc:
        return emit(response(False, exc.code, exc.message, requires_user_action=True, **exc.details), as_json)
    except Exception as exc:
        return emit(response(False, "INTERNAL_ERROR", "未处理的内部错误", requires_user_action=True, error=repr(exc)), as_json)


if __name__ == "__main__":
    raise SystemExit(main())
