#!/usr/bin/env python3
"""Installed AI constraint system entry point."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Any

sys.dont_write_bytecode = True

from state_core import StateError, StateStore, error_result, success


def configure_stdio() -> None:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def result(ok: bool, code: str, message: str, **details: Any) -> dict[str, Any]:
    return {
        "ok": ok,
        "code": code,
        "message": message,
        "retryable": False,
        "requires_user_action": not ok,
        "details": details,
    }


def emit(data: dict[str, Any], as_json: bool) -> int:
    if as_json:
        print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(("PASS" if data["ok"] else "FAIL") + f" [{data['code']}] {data['message']}")
        if data.get("details"):
            print(json.dumps(data["details"], ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if data["ok"] else 2


def project_root() -> Path:
    # Installed path: <project>/.ai/system/aic.py
    return Path(__file__).resolve().parents[2]


def load_install_state(root: Path) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    state_path = root / ".ai" / "INSTALL_STATE.json"
    if not state_path.is_file():
        return None, result(False, "INSTALL_STATE_MISSING", "安装状态不存在", path=str(state_path))
    try:
        data = json.loads(state_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return None, result(False, "INSTALL_STATE_INVALID", "安装状态无法读取", error=str(exc))
    if data.get("schema") != "aic.install-state" or data.get("schema_version") != "1.0.0":
        return None, result(False, "INSTALL_STATE_SCHEMA_UNSUPPORTED", "安装状态格式不兼容")
    return data, None


def verify_installed(root: Path, state: dict[str, Any]) -> dict[str, Any]:
    errors: list[dict[str, Any]] = []
    checked = 0
    for entry in state.get("package_files", []):
        rel = entry.get("target")
        expected = entry.get("sha256")
        if not isinstance(rel, str) or not isinstance(expected, str):
            errors.append({"code": "INSTALL_STATE_FILE_ENTRY_INVALID", "entry": entry})
            continue
        path = (root / Path(rel)).resolve(strict=False)
        if not path.is_relative_to(root.resolve()):
            errors.append({"code": "PATH_ESCAPE", "target": rel})
            continue
        if not path.is_file():
            errors.append({"code": "PACKAGE_FILE_MISSING", "target": rel})
            continue
        actual = digest(path)
        checked += 1
        if actual != expected:
            errors.append({"code": "PACKAGE_FILE_HASH_MISMATCH", "target": rel, "expected": expected, "actual": actual})
    for entry in state.get("managed_entrypoints", []):
        rel = entry.get("target")
        expected = entry.get("managed_block_sha256")
        if not isinstance(rel, str) or not isinstance(expected, str):
            errors.append({"code": "INSTALL_STATE_ENTRYPOINT_INVALID", "entry": entry})
            continue
        path = (root / Path(rel)).resolve(strict=False)
        if not path.is_relative_to(root.resolve()) or not path.is_file():
            errors.append({"code": "MANAGED_ENTRYPOINT_MISSING", "target": rel})
            continue
        data = path.read_bytes()
        begin = data.find(b"<!-- AI-CONSTRAINTS:BEGIN managed")
        end_marker = b"<!-- AI-CONSTRAINTS:END managed -->"
        end = data.find(end_marker, begin)
        if begin < 0 or end < 0:
            errors.append({"code": "MANAGED_ENTRYPOINT_BLOCK_MISSING", "target": rel})
            continue
        block = data[begin:end + len(end_marker)]
        if hashlib.sha256(block).hexdigest() != expected:
            errors.append({"code": "MANAGED_ENTRYPOINT_BLOCK_CHANGED", "target": rel})
    if errors:
        return result(False, "PACKAGE_VERIFY_FAILED", "安装后包文件校验失败", checked=checked, errors=errors)
    return result(True, "PACKAGE_VERIFY_OK", "安装后包文件校验通过", checked=checked)


def git_snapshot(root: Path) -> dict[str, Any]:
    try:
        probe = subprocess.run(
            ["git", "-C", str(root), "status", "--short", "--branch"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=8,
            shell=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"available": False, "error": str(exc)}
    return {
        "available": probe.returncode == 0,
        "exit_code": probe.returncode,
        "status": probe.stdout.splitlines()[:200],
        "error": probe.stderr.strip() or None,
    }


def status_command(root: Path, verify: bool) -> dict[str, Any]:
    state, error = load_install_state(root)
    if error:
        return error
    assert state is not None
    verification = verify_installed(root, state) if verify else None
    legacy = {
        "agents": (root / ".ai" / "AGENTS.md").is_file(),
        "instructions": (root / ".ai" / "AI-INSTRUCTIONS.md").is_file(),
        "rules_index": (root / ".ai" / ".ai-engineering" / "RULES_INDEX.md").is_file(),
        "project_profile": (root / ".ai" / "PROJECT_PROFILE.md").is_file(),
        "storage_map": (root / ".ai" / "COGNITION_STORAGE_MAP.json").is_file(),
    }
    ok = state.get("status") == "INSTALLED" and (verification is None or verification["ok"])
    return result(
        ok,
        "STATUS_OK" if ok else "STATUS_DEGRADED",
        "约束系统状态可用" if ok else "约束系统需要检查",
        project_root=str(root),
        install_status=state.get("status"),
        package=state.get("package"),
        installed_at=state.get("installed_at"),
        package_verification=verification,
        legacy_runtime=legacy,
        phase="phase-2-state-kernel",
        not_implemented=[
            "multi-session-leases",
            "automatic-node-summaries",
            "evidence-validity-automation",
            "full-legacy-field-promotion",
        ],
        git=git_snapshot(root),
    )


def state_command(args: argparse.Namespace, root: Path) -> dict[str, Any]:
    store = StateStore(root)
    try:
        if args.command == "state":
            if args.state_command == "init":
                value = store.initialize(args.project_name, args.project_id)
                return success("STATE_INITIALIZED" if value["created"] else "STATE_ALREADY_INITIALIZED", "统一状态中心已初始化" if value["created"] else "统一状态中心已经存在", **value)
            if args.state_command == "show":
                return success("STATE_CONTEXT_READY", "当前任务和下一步已恢复", **store.context())
            if args.state_command == "verify":
                value = store.verify()
                if not value["healthy"]:
                    return result(False, "STATE_VERIFY_FAILED", "状态中心校验失败", **value)
                return success("STATE_VERIFY_OK", "状态事件链和派生状态校验通过", **value)
            if args.state_command == "rebuild":
                return success("STATE_REBUILT", "派生状态已从权威记录重建", **store.rebuild())
        if args.command == "session" and args.session_command == "start":
            return success("SESSION_STARTED", "会话启动回执已生成", **store.start_session(args.client))
        if args.command == "task":
            if args.task_command == "create":
                value = store.create_task(args.title, args.goal, args.expected_state_revision, args.session_id, args.acceptance)
                return success("TASK_CREATED", "任务已通过状态事务创建", **value)
            if args.task_command == "update":
                value = store.update_task(args.id, args.status, args.expected_entity_revision, args.expected_state_revision, args.session_id, args.completed, args.remaining, args.blocker)
                return success("TASK_UPDATED", "任务已通过状态事务更新", **value)
        if args.command == "next" and args.next_command == "create":
            value = store.create_next(args.task_id, args.action, args.priority, args.expected_state_revision, args.session_id, args.acceptance, args.requires_user_decision)
            return success("NEXT_ACTION_CREATED", "可执行下一步已创建并关联任务", **value)
        if args.command == "view":
            if args.view_command == "render":
                return success("VIEW_RENDERED", "当前状态视图已生成", **store.render_view())
            if args.view_command == "check":
                value = store.check_views()
                if not value["valid"]:
                    return result(False, "VIEW_MODIFIED", "生成视图存在人工修改或缺失", **value)
                return success("VIEW_CHECK_OK", "生成视图校验通过", **value)
        if args.command == "legacy":
            if args.legacy_command == "scan":
                return success("LEGACY_SCAN_READY", "旧 Markdown/CSV 扫描完成", **store.scan_legacy())
            if args.legacy_command == "import":
                value = store.import_legacy(args.expected_state_revision, args.session_id)
                return success("LEGACY_REFERENCES_IMPORTED", "旧资料已作为带哈希引用导入", **value)
    except StateError as exc:
        return error_result(exc)
    return result(False, "INPUT_UNSUPPORTED_COMMAND", "不支持的状态命令")


def main() -> int:
    configure_stdio()
    parser = argparse.ArgumentParser(description="AI engineering constraint system")
    parser.add_argument("--json", action="store_true", help="emit structured JSON")
    sub = parser.add_subparsers(dest="command", required=True)
    status = sub.add_parser("status", help="show installed status")
    status.add_argument("--verify", action="store_true", help="verify package-owned file hashes")
    status.add_argument("--json", action="store_true")
    package = sub.add_parser("package", help="package operations")
    package_sub = package.add_subparsers(dest="package_command", required=True)
    verify = package_sub.add_parser("verify", help="verify installed package files")
    verify.add_argument("--json", action="store_true")
    reconcile = sub.add_parser("reconcile", help="read-only phase-1 reconciliation")
    reconcile.add_argument("--json", action="store_true")

    state = sub.add_parser("state", help="unified structured state")
    state_sub = state.add_subparsers(dest="state_command", required=True)
    state_init = state_sub.add_parser("init", help="initialize state kernel")
    state_init.add_argument("--project-name", required=True)
    state_init.add_argument("--project-id")
    state_init.add_argument("--json", action="store_true")
    for name in ("show", "verify", "rebuild"):
        state_leaf = state_sub.add_parser(name)
        state_leaf.add_argument("--json", action="store_true")

    session = sub.add_parser("session", help="local session receipts")
    session_sub = session.add_subparsers(dest="session_command", required=True)
    session_start = session_sub.add_parser("start")
    session_start.add_argument("--client", required=True)
    session_start.add_argument("--json", action="store_true")

    task = sub.add_parser("task", help="task state operations")
    task_sub = task.add_subparsers(dest="task_command", required=True)
    task_create = task_sub.add_parser("create")
    task_create.add_argument("--title", required=True)
    task_create.add_argument("--goal", required=True)
    task_create.add_argument("--session-id", required=True)
    task_create.add_argument("--expected-state-revision", required=True, type=int)
    task_create.add_argument("--acceptance", action="append", default=[])
    task_create.add_argument("--json", action="store_true")
    task_update = task_sub.add_parser("update")
    task_update.add_argument("--id", required=True)
    task_update.add_argument("--session-id", required=True)
    task_update.add_argument("--expected-state-revision", required=True, type=int)
    task_update.add_argument("--expected-entity-revision", required=True, type=int)
    task_update.add_argument("--status")
    task_update.add_argument("--completed", action="append", default=[])
    task_update.add_argument("--remaining", action="append", default=[])
    task_update.add_argument("--blocker", action="append", default=[])
    task_update.add_argument("--json", action="store_true")

    next_parser = sub.add_parser("next", help="next-action operations")
    next_sub = next_parser.add_subparsers(dest="next_command", required=True)
    next_create = next_sub.add_parser("create")
    next_create.add_argument("--task-id", required=True)
    next_create.add_argument("--action", required=True)
    next_create.add_argument("--priority", type=int, default=1)
    next_create.add_argument("--session-id", required=True)
    next_create.add_argument("--expected-state-revision", required=True, type=int)
    next_create.add_argument("--acceptance", action="append", default=[])
    next_create.add_argument("--requires-user-decision", action="store_true")
    next_create.add_argument("--json", action="store_true")

    view = sub.add_parser("view", help="derived Markdown views")
    view_sub = view.add_subparsers(dest="view_command", required=True)
    for name in ("render", "check"):
        view_leaf = view_sub.add_parser(name)
        view_leaf.add_argument("--json", action="store_true")

    legacy = sub.add_parser("legacy", help="legacy Markdown/CSV migration")
    legacy_sub = legacy.add_subparsers(dest="legacy_command", required=True)
    legacy_scan = legacy_sub.add_parser("scan")
    legacy_scan.add_argument("--json", action="store_true")
    legacy_import = legacy_sub.add_parser("import")
    legacy_import.add_argument("--session-id", required=True)
    legacy_import.add_argument("--expected-state-revision", required=True, type=int)
    legacy_import.add_argument("--json", action="store_true")
    args = parser.parse_args()
    as_json = bool(getattr(args, "json", False))
    root = project_root()
    if args.command in {"status", "reconcile"}:
        return emit(status_command(root, verify=args.command == "reconcile" or args.verify), as_json)
    if args.command == "package" and args.package_command == "verify":
        state, error = load_install_state(root)
        return emit(error or verify_installed(root, state or {}), as_json)
    if args.command in {"state", "session", "task", "next", "view", "legacy"}:
        return emit(state_command(args, root), as_json)
    return emit(result(False, "INPUT_UNSUPPORTED_COMMAND", "不支持的命令"), as_json)


if __name__ == "__main__":
    raise SystemExit(main())
