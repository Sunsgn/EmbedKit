# AI 工程约束系统统一入口

本文件是安装后各 AI 客户端的统一薄入口。

## 会话启动

1. 从项目根目录运行 `python .ai/system/aic.py status --json`，核对安装状态和包完整性。
2. 若状态中心尚未初始化，运行 `python .ai/system/aic.py state init --project-name "<项目名>" --json`；不得直接创建或编辑状态文件。
3. 运行 `python .ai/system/aic.py session start --client "<客户端>" --json`，保存会话 ID 和启动时读取的状态修订号。
4. 运行 `python .ai/system/aic.py state show --json`，以其中的活动任务和推荐下一步作为续做依据；不得用聊天记忆覆盖结构化状态。
5. 读取 `.ai/AGENTS.md`、`.ai/AI-INSTRUCTIONS.md` 和 `.ai/.ai-engineering/RULES_INDEX.md`，继续使用已保留的 V6 规则与专业规范。
6. 修改前检查 Git 和用户已有改动。状态写入必须使用 `task`、`next`、`legacy` 等统一命令，并携带刚读取的 `expected-state-revision`；冲突后重新读取，禁止直接覆盖。
7. 节点结束前更新任务事实，运行 `state verify` 和 `view render`，再报告真实验证结果和剩余下一步。

## 当前能力边界

这是 7.0.0-alpha.2 阶段 2 候选包，已经实现统一结构化状态、稳定 ID、只追加事件链、状态与实体修订冲突、可恢复事务封套、派生快照、状态校验、旧 Markdown/CSV 引用迁移以及生成视图人工修改冲突检测。

完整任务状态机门禁、证据有效性联动、自动研发节点总结、范围锁、租约、异常会话接管和损坏事件链修复仍属于后续阶段。当前本机状态写锁只阻止同一工作副本同时写入，不得声称可以协调不同计算机或仓库副本。

不得把本阶段候选包描述为已经满足最终目标基线。
