#!/usr/bin/env python3
"""Deterministic project state kernel for AIC phase 2.

The event chain and committed transaction envelopes are authoritative. Entity
snapshots, CURRENT.json, indexes and Markdown views are derived records.
"""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import secrets
import tempfile
from typing import Any, Iterator


SCHEMA_VERSION = "1.0.0"
TASK_STATUSES = {
    "NEW", "DISCOVERING", "PLANNED", "READY", "EXECUTING", "VERIFYING",
    "PAUSED", "BLOCKED", "FAILED", "COMPLETED", "CANCELLED", "STALE", "REOPENED",
}
NEXT_STATUSES = {"PLANNED", "READY", "IN_PROGRESS", "BLOCKED", "DONE", "CANCELLED", "STALE"}
ENTITY_PREFIXES = {
    "project": "PRJ", "requirement": "REQ", "task": "TASK", "next_action": "NEXT",
    "session": "SES", "evidence": "EVD", "decision": "DEC", "issue": "ISS",
    "checkpoint": "CP", "summary": "SUM",
}
MAX_LEGACY_FILES = 200
MAX_LEGACY_FILE_BYTES = 2 * 1024 * 1024


class StateError(Exception):
    def __init__(self, code: str, message: str, **details: Any) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def new_id(prefix: str) -> str:
    milliseconds = int(datetime.now(timezone.utc).timestamp() * 1000)
    return f"{prefix}-{milliseconds:013X}{secrets.token_hex(6).upper()}"


def canonical_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def pretty_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return "sha256:" + h.hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise StateError("STATE_FILE_MISSING", "状态文件不存在", path=str(path)) from exc
    except (OSError, json.JSONDecodeError) as exc:
        raise StateError("STATE_FILE_INVALID", "状态文件无法读取", path=str(path), error=str(exc)) from exc
    if not isinstance(value, dict):
        raise StateError("STATE_FILE_INVALID", "状态文件根节点必须是对象", path=str(path))
    return value


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    temp_path = Path(temporary)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
        try:
            directory_fd = os.open(path.parent, os.O_RDONLY)
        except OSError:
            directory_fd = None
        if directory_fd is not None:
            try:
                os.fsync(directory_fd)
            except OSError:
                pass
            finally:
                os.close(directory_fd)
    finally:
        if temp_path.exists():
            temp_path.unlink()


def require_id(value: str, prefix: str, field: str) -> None:
    if not value.startswith(prefix + "-") or len(value) <= len(prefix) + 1:
        raise StateError("INPUT_INVALID_ID", f"{field} 不是有效的 {prefix} ID", field=field, value=value)


class StateStore:
    def __init__(self, project_root: Path) -> None:
        self.root = project_root.resolve()
        self.ai = self.root / ".ai"
        self.state = self.ai / "state"
        self.run = self.ai / "run"
        self.entities = self.state / "entities"
        self.events = self.state / "events"
        self.committed = self.state / "committed-transactions"
        self.head_path = self.state / "HEAD.json"
        self.current_path = self.state / "CURRENT.json"
        self.lock_path = self.run / "locks" / "state-write.lock"

    @property
    def initialized(self) -> bool:
        return self.head_path.is_file() and self.current_path.is_file()

    def _ensure_directories(self) -> None:
        for path in (
            self.entities, self.events, self.committed, self.state / "indexes",
            self.state / "checkpoints", self.run / "sessions", self.run / "locks",
            self.run / "transactions", self.run / "health", self.run / "cache",
            self.ai / "tasks", self.ai / "evidence", self.ai / "summaries",
            self.ai / "views", self.ai / "audit", self.ai / "legacy", self.ai / "project",
        ):
            path.mkdir(parents=True, exist_ok=True)

    def _entity_path(self, entity_type: str, entity_id: str) -> Path:
        return self.entities / entity_type / f"{entity_id}.json"

    def _load_entity(self, entity_type: str, entity_id: str) -> dict[str, Any] | None:
        path = self._entity_path(entity_type, entity_id)
        return read_json(path) if path.is_file() else None

    def _all_entities(self) -> list[dict[str, Any]]:
        values: list[dict[str, Any]] = []
        if not self.entities.is_dir():
            return values
        for path in sorted(self.entities.glob("*/*.json")):
            values.append(read_json(path))
        return values

    @contextmanager
    def _write_lock(self, session_id: str) -> Iterator[None]:
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        token = secrets.token_hex(16)
        payload = pretty_bytes({
            "schema": "aic.local-write-lock", "schema_version": SCHEMA_VERSION,
            "owner_session_id": session_id, "pid": os.getpid(), "token": token,
            "acquired_at": utc_now(),
        })
        try:
            descriptor = os.open(self.lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError as exc:
            owner: dict[str, Any] | None = None
            try:
                owner = read_json(self.lock_path)
            except StateError:
                pass
            raise StateError("STATE_WRITE_LOCKED", "状态写锁已被占用；不得直接删除锁文件", owner=owner) from exc
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            yield
        finally:
            try:
                current = read_json(self.lock_path)
                if current.get("token") == token:
                    self.lock_path.unlink()
            except (StateError, OSError):
                pass

    def initialize(self, project_name: str, project_id: str | None = None) -> dict[str, Any]:
        if not project_name.strip():
            raise StateError("INPUT_PROJECT_NAME_REQUIRED", "项目名称不能为空")
        if self.initialized:
            return {"created": False, "context": self.context()}
        self._ensure_directories()
        pid = project_id or new_id("PRJ")
        require_id(pid, "PRJ", "project_id")
        created = utc_now()
        head = {
            "schema": "aic.state-head", "schema_version": SCHEMA_VERSION,
            "project_id": pid, "state_revision": 0, "last_event_id": None,
            "last_event_hash": None, "last_transaction_id": None, "updated_at": created,
        }
        current = {
            "schema": "aic.current-state", "schema_version": SCHEMA_VERSION,
            "project_id": pid, "state_revision": 0, "last_event_id": None,
            "last_event_hash": None, "package_version": "7.0.0-alpha.2",
            "project_profile_revision": 0, "active_tasks": [], "ready_next_actions": [],
            "active_sessions": [], "active_locks": [], "open_blockers": [],
            "latest_checkpoint_id": None, "latest_summary_ids": [], "health": "HEALTHY",
            "updated_at": created,
        }
        atomic_write(self.head_path, pretty_bytes(head))
        atomic_write(self.current_path, pretty_bytes(current))
        project = {
            "schema": "aic.project", "schema_version": SCHEMA_VERSION, "id": pid,
            "project_id": pid, "revision": 1, "status": "ACTIVE", "name": project_name.strip(),
            "created_at": created, "updated_at": created, "created_by": "SES-BOOTSTRAP",
            "updated_by": "SES-BOOTSTRAP", "confirmed_facts": [], "legacy_imports": [],
            "extensions": {},
        }
        self.commit(
            [self._change("project", project, 0, "project.created")],
            expected_state_revision=0, session_id="SES-BOOTSTRAP",
        )
        return {"created": True, "context": self.context()}

    def _require_initialized(self) -> None:
        if not self.initialized:
            raise StateError("STATE_NOT_INITIALIZED", "统一状态中心尚未初始化；先执行 state init")

    @staticmethod
    def _change(entity_type: str, entity: dict[str, Any], expected_revision: int, event_type: str) -> dict[str, Any]:
        return {
            "entity_type": entity_type, "entity_id": entity["id"], "entity": entity,
            "expected_entity_revision": expected_revision, "event_type": event_type,
        }

    def commit(self, changes: list[dict[str, Any]], expected_state_revision: int, session_id: str) -> dict[str, Any]:
        self._require_initialized()
        require_id(session_id, "SES", "session_id")
        transaction_id = new_id("TXN")
        run_tx = self.run / "transactions" / f"{transaction_id}.json"
        with self._write_lock(session_id):
            head = read_json(self.head_path)
            actual_revision = head.get("state_revision")
            if actual_revision != expected_state_revision:
                raise StateError(
                    "STATE_REVISION_CONFLICT", "状态修订已变化，必须重新读取后再修改",
                    expected=expected_state_revision, actual=actual_revision,
                )
            now = utc_now()
            events: list[dict[str, Any]] = []
            sequence = int(actual_revision)
            previous_hash = head.get("last_event_hash")
            for change in changes:
                current = self._load_entity(change["entity_type"], change["entity_id"])
                current_revision = int(current.get("revision", 0)) if current else 0
                expected_entity = int(change["expected_entity_revision"])
                if current_revision != expected_entity:
                    raise StateError(
                        "ENTITY_REVISION_CONFLICT", "实体修订已变化，必须重新读取后再修改",
                        entity_id=change["entity_id"], expected=expected_entity, actual=current_revision,
                    )
                entity = change["entity"]
                if entity.get("revision") != expected_entity + 1:
                    raise StateError("ENTITY_REVISION_INVALID", "新实体修订必须恰好加一", entity_id=entity.get("id"))
                sequence += 1
                event = {
                    "schema": "aic.event", "schema_version": SCHEMA_VERSION,
                    "event_id": new_id("EVT"), "project_id": head["project_id"],
                    "sequence": sequence, "previous_sequence": sequence - 1,
                    "previous_event_hash": previous_hash, "event_type": change["event_type"],
                    "entity_type": change["entity_type"], "entity_id": change["entity_id"],
                    "expected_entity_revision": expected_entity,
                    "new_entity_revision": entity["revision"], "session_id": session_id,
                    "transaction_id": transaction_id, "occurred_at": now,
                    "payload": {"entity_sha256": sha256_bytes(canonical_bytes(entity))},
                    "references": [],
                }
                event["event_hash"] = sha256_bytes(canonical_bytes(event))
                previous_hash = event["event_hash"]
                events.append(event)
            envelope = {
                "schema": "aic.committed-transaction", "schema_version": SCHEMA_VERSION,
                "transaction_id": transaction_id, "project_id": head["project_id"],
                "expected_state_revision": expected_state_revision, "new_state_revision": sequence,
                "session_id": session_id, "created_at": now, "changes": changes, "events": events,
            }
            envelope["envelope_hash"] = sha256_bytes(canonical_bytes(envelope))
            prepared = dict(envelope)
            prepared["phase"] = "PREPARED"
            atomic_write(run_tx, pretty_bytes(prepared))
            committed_path = self.committed / f"{transaction_id}.json"
            if committed_path.exists():
                raise StateError("TRANSACTION_ID_COLLISION", "事务 ID 已存在", transaction_id=transaction_id)
            atomic_write(committed_path, pretty_bytes(envelope))
            event_path = self.events / (datetime.now(timezone.utc).strftime("%Y-%m") + ".jsonl")
            event_path.parent.mkdir(parents=True, exist_ok=True)
            with event_path.open("ab") as handle:
                for event in events:
                    handle.write(canonical_bytes(event))
                handle.flush()
                os.fsync(handle.fileno())
            new_head = {
                "schema": "aic.state-head", "schema_version": SCHEMA_VERSION,
                "project_id": head["project_id"], "state_revision": sequence,
                "last_event_id": events[-1]["event_id"], "last_event_hash": events[-1]["event_hash"],
                "last_transaction_id": transaction_id, "updated_at": now,
            }
            atomic_write(self.head_path, pretty_bytes(new_head))
            for change in changes:
                atomic_write(self._entity_path(change["entity_type"], change["entity_id"]), pretty_bytes(change["entity"]))
            self._write_derived(new_head)
            committed_run = dict(prepared)
            committed_run["phase"] = "COMMITTED"
            committed_run["committed_at"] = utc_now()
            atomic_write(run_tx, pretty_bytes(committed_run))
        return {
            "transaction_id": transaction_id, "state_revision": sequence,
            "event_ids": [event["event_id"] for event in events],
        }

    def _write_derived(self, head: dict[str, Any]) -> None:
        entities = self._all_entities()
        tasks = [item for item in entities if item.get("schema") == "aic.task"]
        actions = [item for item in entities if item.get("schema") == "aic.next-action"]
        active_task_statuses = {"NEW", "DISCOVERING", "PLANNED", "READY", "EXECUTING", "VERIFYING", "PAUSED", "BLOCKED", "REOPENED"}
        active_tasks = sorted(item["id"] for item in tasks if item.get("status") in active_task_statuses)
        ready = sorted(
            (item for item in actions if item.get("status") == "READY" and not item.get("blocked_by")),
            key=lambda item: (int(item.get("priority", 9999)), item["id"]),
        )
        current = {
            "schema": "aic.current-state", "schema_version": SCHEMA_VERSION,
            "project_id": head["project_id"], "state_revision": head["state_revision"],
            "last_event_id": head["last_event_id"], "last_event_hash": head["last_event_hash"],
            "package_version": "7.0.0-alpha.2", "project_profile_revision": 0,
            "active_tasks": active_tasks, "ready_next_actions": [item["id"] for item in ready],
            "active_sessions": self._active_session_ids(), "active_locks": [],
            "open_blockers": sorted(item["id"] for item in entities if item.get("schema") == "aic.issue" and item.get("status") == "OPEN"),
            "latest_checkpoint_id": self._latest_id(entities, "aic.checkpoint"),
            "latest_summary_ids": self._latest_ids(entities, "aic.summary", 10),
            "health": "HEALTHY", "updated_at": utc_now(),
        }
        atomic_write(self.current_path, pretty_bytes(current))
        entity_index = {
            "schema": "aic.entity-index", "schema_version": SCHEMA_VERSION,
            "state_revision": head["state_revision"],
            "entities": [{"id": item["id"], "schema": item["schema"], "revision": item["revision"], "status": item.get("status")} for item in sorted(entities, key=lambda item: item["id"])],
        }
        atomic_write(self.state / "indexes" / "entities.json", pretty_bytes(entity_index))

    def _active_session_ids(self) -> list[str]:
        ids: list[str] = []
        for path in sorted((self.run / "sessions").glob("SES-*.json")):
            try:
                value = read_json(path)
            except StateError:
                continue
            if value.get("status") == "ACTIVE":
                ids.append(str(value.get("id")))
        return ids

    @staticmethod
    def _latest_id(entities: list[dict[str, Any]], schema: str) -> str | None:
        values = StateStore._latest_ids(entities, schema, 1)
        return values[0] if values else None

    @staticmethod
    def _latest_ids(entities: list[dict[str, Any]], schema: str, limit: int) -> list[str]:
        matching = [item for item in entities if item.get("schema") == schema]
        matching.sort(key=lambda item: (str(item.get("updated_at", "")), item["id"]), reverse=True)
        return [item["id"] for item in matching[:limit]]

    def start_session(self, client: str) -> dict[str, Any]:
        self._require_initialized()
        if not client.strip():
            raise StateError("INPUT_CLIENT_REQUIRED", "客户端名称不能为空")
        session_id = new_id("SES")
        current = read_json(self.current_path)
        started = utc_now()
        receipt = {
            "schema": "aic.session", "schema_version": SCHEMA_VERSION, "id": session_id,
            "project_id": current["project_id"], "revision": 1, "status": "ACTIVE",
            "client": client.strip(), "started_at": started, "created_at": started, "updated_at": started,
            "base_state_revision": current["state_revision"], "created_by": session_id,
            "updated_by": session_id, "extensions": {},
        }
        session_path = self.run / "sessions" / f"{session_id}.json"
        atomic_write(session_path, pretty_bytes(receipt))
        try:
            with self._write_lock(session_id):
                self._write_derived(read_json(self.head_path))
        except StateError:
            session_path.unlink(missing_ok=True)
            raise
        return {"session": receipt, "context": self.context()}

    def create_task(self, title: str, goal: str, expected_state_revision: int, session_id: str, acceptance: list[str]) -> dict[str, Any]:
        if not title.strip() or not goal.strip():
            raise StateError("INPUT_TASK_FIELDS_REQUIRED", "任务标题和目标不能为空")
        now = utc_now()
        task_id = new_id("TASK")
        task = {
            "schema": "aic.task", "schema_version": SCHEMA_VERSION, "id": task_id,
            "project_id": read_json(self.head_path)["project_id"], "revision": 1, "status": "NEW",
            "title": title.strip(), "original_goal": goal.strip(), "normalized_goal": goal.strip(),
            "level": "STANDARD", "scope": [], "exclusions": [], "requirement_refs": [],
            "acceptance_criteria": acceptance, "completed_work": [], "remaining_work": [],
            "blockers": [], "next_action_refs": [], "created_at": now, "updated_at": now,
            "created_by": session_id, "updated_by": session_id, "extensions": {},
        }
        committed = self.commit([self._change("task", task, 0, "task.created")], expected_state_revision, session_id)
        return {"task": task, **committed}

    def update_task(self, task_id: str, status: str | None, expected_entity_revision: int, expected_state_revision: int, session_id: str, completed: list[str], remaining: list[str], blockers: list[str]) -> dict[str, Any]:
        require_id(task_id, "TASK", "task_id")
        task = self._load_entity("task", task_id)
        if task is None:
            raise StateError("TASK_NOT_FOUND", "任务不存在", task_id=task_id)
        if status and status not in TASK_STATUSES:
            raise StateError("INPUT_TASK_STATUS_INVALID", "任务状态无效", status=status)
        updated = dict(task)
        updated["revision"] = expected_entity_revision + 1
        updated["updated_at"] = utc_now()
        updated["updated_by"] = session_id
        if status:
            updated["status"] = status
        for key, values in (("completed_work", completed), ("remaining_work", remaining), ("blockers", blockers)):
            if values:
                updated[key] = list(dict.fromkeys([*updated.get(key, []), *values]))
        committed = self.commit([self._change("task", updated, expected_entity_revision, "task.updated")], expected_state_revision, session_id)
        return {"task": updated, **committed}

    def create_next(self, task_id: str, action: str, priority: int, expected_state_revision: int, session_id: str, acceptance: list[str], requires_user_decision: bool) -> dict[str, Any]:
        require_id(task_id, "TASK", "task_id")
        task = self._load_entity("task", task_id)
        if task is None:
            raise StateError("TASK_NOT_FOUND", "任务不存在", task_id=task_id)
        if not action.strip() or priority < 1:
            raise StateError("INPUT_NEXT_INVALID", "下一步必须有动作且优先级大于零")
        now = utc_now()
        action_id = new_id("NEXT")
        next_action = {
            "schema": "aic.next-action", "schema_version": SCHEMA_VERSION, "id": action_id,
            "project_id": task["project_id"], "revision": 1, "status": "READY",
            "task_id": task_id, "action": action.strip(), "priority": priority,
            "prerequisite_refs": [], "target_refs": [], "acceptance_criteria": acceptance,
            "required_evidence_types": [], "requires_user_decision": requires_user_decision,
            "decision_prompt": None, "blocked_by": [], "created_at": now, "updated_at": now,
            "created_by": session_id, "updated_by": session_id, "extensions": {},
        }
        updated_task = dict(task)
        updated_task["revision"] = task["revision"] + 1
        updated_task["updated_at"] = now
        updated_task["updated_by"] = session_id
        updated_task["next_action_refs"] = list(dict.fromkeys([*task.get("next_action_refs", []), action_id]))
        changes = [
            self._change("next_action", next_action, 0, "next-action.created"),
            self._change("task", updated_task, task["revision"], "task.next-action-linked"),
        ]
        committed = self.commit(changes, expected_state_revision, session_id)
        return {"next_action": next_action, "task_revision": updated_task["revision"], **committed}

    def context(self) -> dict[str, Any]:
        self._require_initialized()
        head = read_json(self.head_path)
        current = read_json(self.current_path)
        if head.get("state_revision") != current.get("state_revision") or head.get("last_event_hash") != current.get("last_event_hash"):
            raise StateError("STATE_DERIVED_STALE", "当前快照与 HEAD 不一致，需要执行 state rebuild")
        tasks = []
        for task_id in current.get("active_tasks", []):
            task = self._load_entity("task", task_id)
            if task:
                tasks.append(task)
        actions = []
        for action_id in current.get("ready_next_actions", []):
            action = self._load_entity("next_action", action_id)
            if action:
                actions.append(action)
        return {
            "head": head, "current": current, "active_tasks": tasks,
            "ready_next_actions": actions, "recommended_next_action": actions[0] if actions else None,
        }

    def verify(self) -> dict[str, Any]:
        self._require_initialized()
        head = read_json(self.head_path)
        errors: list[dict[str, Any]] = []
        sequence = 0
        previous_hash: str | None = None
        last_event_id: str | None = None
        transaction_ids: set[str] = set()
        for path in sorted(self.events.glob("*.jsonl")):
            for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
                if not line.strip():
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError as exc:
                    errors.append({"code": "EVENT_JSON_INVALID", "path": str(path), "line": line_number, "error": str(exc)})
                    continue
                supplied_hash = event.get("event_hash")
                unhashed = dict(event)
                unhashed.pop("event_hash", None)
                computed = sha256_bytes(canonical_bytes(unhashed))
                if event.get("sequence") != sequence + 1:
                    errors.append({"code": "EVENT_SEQUENCE_INVALID", "event_id": event.get("event_id")})
                if event.get("previous_event_hash") != previous_hash:
                    errors.append({"code": "EVENT_CHAIN_INVALID", "event_id": event.get("event_id")})
                if supplied_hash != computed:
                    errors.append({"code": "EVENT_HASH_INVALID", "event_id": event.get("event_id")})
                sequence = int(event.get("sequence", sequence))
                previous_hash = supplied_hash
                last_event_id = event.get("event_id")
                transaction_ids.add(str(event.get("transaction_id")))
        if sequence != head.get("state_revision") or previous_hash != head.get("last_event_hash") or last_event_id != head.get("last_event_id"):
            errors.append({"code": "HEAD_EVENT_MISMATCH", "event_sequence": sequence, "head_revision": head.get("state_revision")})
        for transaction_id in transaction_ids:
            path = self.committed / f"{transaction_id}.json"
            if not path.is_file():
                errors.append({"code": "COMMITTED_TRANSACTION_MISSING", "transaction_id": transaction_id})
        try:
            self.context()
        except StateError as exc:
            errors.append({"code": exc.code, **exc.details})
        return {"healthy": not errors, "state_revision": head.get("state_revision"), "events_checked": sequence, "errors": errors}

    def rebuild(self) -> dict[str, Any]:
        self._require_initialized()
        verification = self.verify()
        chain_errors = [item for item in verification["errors"] if item["code"] not in {"STATE_DERIVED_STALE"}]
        if chain_errors:
            raise StateError("STATE_REBUILD_UNSAFE", "事件链或事务记录损坏，禁止自动重建", errors=chain_errors)
        head = read_json(self.head_path)
        self._write_derived(head)
        return {"rebuilt": True, "state_revision": head["state_revision"], "context": self.context()}

    def render_view(self) -> dict[str, Any]:
        context = self.context()
        view_path = self.ai / "views" / "CURRENT.md"
        manifest_path = self.ai / "views" / ".manifest.json"
        manifest = read_json(manifest_path) if manifest_path.is_file() else {"views": {}}
        prior = manifest.get("views", {}).get("CURRENT.md")
        if view_path.is_file() and prior and file_sha256(view_path) != prior.get("content_sha256"):
            raise StateError("VIEW_MANUAL_EDIT_CONFLICT", "生成视图已被人工修改，禁止静默覆盖", path=str(view_path))
        current = context["current"]
        lines = [
            "# AI 工程当前状态", "", f"> 生成自状态修订 `{current['state_revision']}`；本文件不是权威状态源。", "",
            "## 当前任务", "",
        ]
        if context["active_tasks"]:
            for task in context["active_tasks"]:
                lines.append(f"- `{task['id']}` [{task['status']}] {task['title']}")
        else:
            lines.append("- 无活动任务")
        lines.extend(["", "## 下一步", ""])
        if context["ready_next_actions"]:
            for action in context["ready_next_actions"]:
                lines.append(f"- P{action['priority']} `{action['id']}`：{action['action']}")
        else:
            lines.append("- 无可执行下一步")
        content = ("\n".join(lines) + "\n").encode("utf-8")
        atomic_write(view_path, content)
        output_manifest = {
            "schema": "aic.view-manifest", "schema_version": SCHEMA_VERSION,
            "views": {"CURRENT.md": {"source_state_revision": current["state_revision"], "content_sha256": sha256_bytes(content), "generated_at": utc_now()}},
        }
        atomic_write(manifest_path, pretty_bytes(output_manifest))
        return {"path": str(view_path), "state_revision": current["state_revision"], "content_sha256": sha256_bytes(content)}

    def check_views(self) -> dict[str, Any]:
        manifest_path = self.ai / "views" / ".manifest.json"
        if not manifest_path.is_file():
            return {"valid": True, "views": [], "message": "尚未生成视图"}
        manifest = read_json(manifest_path)
        results = []
        valid = True
        for relative, metadata in manifest.get("views", {}).items():
            path = self.ai / "views" / relative
            actual = file_sha256(path) if path.is_file() else None
            matched = actual == metadata.get("content_sha256")
            valid = valid and matched
            results.append({"path": relative, "matched": matched, "expected": metadata.get("content_sha256"), "actual": actual})
        return {"valid": valid, "views": results}

    def scan_legacy(self) -> dict[str, Any]:
        candidates: list[dict[str, Any]] = []
        excluded = {self.state.resolve(), self.run.resolve(), (self.ai / "system").resolve(), (self.ai / "views").resolve()}
        if not self.ai.is_dir():
            return {"files": [], "truncated": False}
        for path in sorted(self.ai.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in {".md", ".csv"}:
                continue
            resolved = path.resolve()
            if any(resolved == base or base in resolved.parents for base in excluded):
                continue
            size = path.stat().st_size
            relative = path.relative_to(self.root).as_posix()
            if size > MAX_LEGACY_FILE_BYTES:
                candidates.append({"path": relative, "size": size, "status": "TOO_LARGE"})
            else:
                candidates.append({"path": relative, "size": size, "sha256": file_sha256(path), "format": path.suffix.lower()[1:], "status": "MAPPABLE"})
            if len(candidates) >= MAX_LEGACY_FILES:
                return {"files": candidates, "truncated": True, "limit": MAX_LEGACY_FILES}
        return {"files": candidates, "truncated": False, "limit": MAX_LEGACY_FILES}

    def import_legacy(self, expected_state_revision: int, session_id: str) -> dict[str, Any]:
        scan = self.scan_legacy()
        if scan["truncated"]:
            raise StateError("LEGACY_SCAN_LIMIT", "旧资料超过单次迁移上限，需缩小范围", limit=MAX_LEGACY_FILES)
        project_id = read_json(self.head_path)["project_id"]
        project = self._load_entity("project", project_id)
        if project is None:
            raise StateError("PROJECT_ENTITY_MISSING", "项目实体不存在")
        imports = [item for item in scan["files"] if item.get("status") == "MAPPABLE"]
        updated = dict(project)
        updated["revision"] = project["revision"] + 1
        updated["updated_at"] = utc_now()
        updated["updated_by"] = session_id
        batch_id = new_id("MIG")
        updated["legacy_imports"] = [*project.get("legacy_imports", []), {"batch_id": batch_id, "imported_at": utc_now(), "files": imports}]
        audit = {
            "schema": "aic.legacy-import-report", "schema_version": SCHEMA_VERSION,
            "batch_id": batch_id, "project_id": project_id, "created_at": utc_now(),
            "source_files": scan["files"], "authority": "reference-only",
            "message": "旧 Markdown/CSV 作为带哈希的迁移引用导入；不会成为第二套权威状态。",
        }
        atomic_write(self.ai / "audit" / f"{batch_id}.json", pretty_bytes(audit))
        committed = self.commit([self._change("project", updated, project["revision"], "legacy.references.imported")], expected_state_revision, session_id)
        return {"batch_id": batch_id, "imported": len(imports), "report": str(self.ai / "audit" / f"{batch_id}.json"), **committed}


def error_result(exc: StateError) -> dict[str, Any]:
    return {
        "ok": False, "code": exc.code, "message": exc.message, "retryable": False,
        "requires_user_action": True, "details": exc.details,
    }


def success(code: str, message: str, **details: Any) -> dict[str, Any]:
    return {
        "ok": True, "code": code, "message": message, "retryable": False,
        "requires_user_action": False, "details": details,
    }
