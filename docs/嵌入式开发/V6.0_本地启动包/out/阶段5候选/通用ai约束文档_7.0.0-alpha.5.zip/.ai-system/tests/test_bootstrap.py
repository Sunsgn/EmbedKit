#!/usr/bin/env python3
"""Phase-1 clean-room integration and failure-path tests."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile


SOURCE_ROOT = Path(__file__).resolve().parents[2]


class BootstrapIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.temp = tempfile.TemporaryDirectory(prefix="aic-bootstrap-tests-")
        cls.root = Path(cls.temp.name)
        cls.package_root = cls.root / "package"
        shutil.copytree(SOURCE_ROOT, cls.package_root, ignore=shutil.ignore_patterns("__pycache__", "PACKAGE_MANIFEST.json"))
        cls.zip_path = cls.root / "candidate.zip"
        repack = cls.package_root / ".ai-system" / "maintenance" / "repack.py"
        process = subprocess.run(
            [sys.executable, str(repack), "--package-root", str(cls.package_root), "--output", str(cls.zip_path)],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60,
        )
        if process.returncode != 0:
            raise RuntimeError(process.stdout + process.stderr)
        cls.zip_hash = hashlib.sha256(cls.zip_path.read_bytes()).hexdigest()
        cls.bootstrap = cls.package_root / "bootstrap.py"

    @classmethod
    def tearDownClass(cls) -> None:
        cls.temp.cleanup()

    def run_bootstrap(self, *args: str, env: dict[str, str] | None = None, expected: int = 0) -> dict:
        process = subprocess.run(
            [sys.executable, str(self.bootstrap), *args, "--json"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=90, env=env,
        )
        self.assertEqual(process.returncode, expected, process.stdout + process.stderr)
        return json.loads(process.stdout)

    def new_case(self, name: str) -> tuple[Path, Path]:
        project = self.root / (name + "-project")
        work = self.root / (name + "-work")
        project.mkdir()
        work.mkdir()
        return project, work

    def create_plan(self, project: Path, work: Path) -> Path:
        plan = work / "plan.json"
        result = self.run_bootstrap(
            "plan", "--zip", str(self.zip_path), "--target", str(project),
            "--output", str(plan), "--expected-sha256", self.zip_hash,
        )
        self.assertEqual(result["code"], "PLAN_READY")
        return plan

    def transaction_from(self, work: Path) -> Path:
        transactions = list((work / "transactions").glob("*/transaction.json"))
        self.assertEqual(len(transactions), 1)
        return transactions[0]

    def test_01_preflight_and_manifest(self) -> None:
        project, _ = self.new_case("inspect")
        result = self.run_bootstrap(
            "inspect", "--zip", str(self.zip_path), "--target", str(project),
            "--expected-sha256", self.zip_hash,
        )
        self.assertEqual(result["code"], "INSPECT_OK")
        self.assertEqual(result["details"]["package"]["package_version"], "7.0.0-alpha.5")

    def test_02_fresh_install_verify_and_rollback(self) -> None:
        project, work = self.new_case("fresh")
        plan = self.create_plan(project, work)
        result = self.run_bootstrap("apply", "--plan", str(plan))
        self.assertEqual(result["code"], "INSTALL_COMMITTED")
        installed = project / ".ai" / "system" / "aic.py"
        process = subprocess.run(
            [sys.executable, str(installed), "status", "--verify", "--json"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30,
        )
        self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
        self.assertEqual(json.loads(process.stdout)["code"], "STATUS_OK")
        tx = self.transaction_from(work)
        rolled = self.run_bootstrap("rollback", "--transaction", str(tx))
        self.assertEqual(rolled["code"], "INSTALL_ROLLED_BACK")
        self.assertEqual(list(project.iterdir()), [])

    def test_03_existing_entrypoint_preserved(self) -> None:
        project, work = self.new_case("existing-entry")
        original = b"# User instructions\n\nKeep this exact text.\n"
        (project / "AGENTS.md").write_bytes(original)
        before = hashlib.sha256(original).hexdigest()
        plan = self.create_plan(project, work)
        self.run_bootstrap("apply", "--plan", str(plan))
        merged = (project / "AGENTS.md").read_bytes()
        self.assertTrue(merged.startswith(original))
        self.assertIn(b"AI-CONSTRAINTS:BEGIN", merged)
        tx = self.transaction_from(work)
        self.run_bootstrap("rollback", "--transaction", str(tx))
        restored = (project / "AGENTS.md").read_bytes()
        self.assertEqual(hashlib.sha256(restored).hexdigest(), before)
        self.assertEqual(restored, original)

    def test_04_unknown_payload_conflict_blocks_apply(self) -> None:
        project, work = self.new_case("payload-conflict")
        target = project / ".ai" / "AGENTS.md"
        target.parent.mkdir()
        target.write_text("project-specific content\n", encoding="utf-8")
        plan = work / "plan.json"
        result = self.run_bootstrap(
            "plan", "--zip", str(self.zip_path), "--target", str(project), "--output", str(plan),
        )
        self.assertEqual(result["code"], "PLAN_CREATED_WITH_CONFLICTS")
        self.assertFalse(result["details"]["can_apply"])
        failed = self.run_bootstrap("apply", "--plan", str(plan), expected=2)
        self.assertEqual(failed["code"], "INSTALL_PLAN_HAS_CONFLICTS")
        self.assertEqual(target.read_text(encoding="utf-8"), "project-specific content\n")

    def test_05_failure_resume(self) -> None:
        project, work = self.new_case("resume")
        plan = self.create_plan(project, work)
        env = os.environ.copy()
        env["AIC_TEST_MODE"] = "1"
        env["AIC_TEST_FAIL_AFTER"] = "3"
        failed = self.run_bootstrap("apply", "--plan", str(plan), env=env, expected=2)
        self.assertEqual(failed["code"], "INSTALL_EXECUTION_FAILED")
        tx = Path(failed["details"]["transaction"])
        resumed = self.run_bootstrap("resume", "--transaction", str(tx))
        self.assertEqual(resumed["code"], "INSTALL_COMMITTED")

    def test_06_expected_hash_mismatch(self) -> None:
        project, _ = self.new_case("hash-mismatch")
        result = self.run_bootstrap(
            "inspect", "--zip", str(self.zip_path), "--target", str(project),
            "--expected-sha256", "0" * 64, expected=2,
        )
        self.assertEqual(result["code"], "PACKAGE_EXPECTED_HASH_MISMATCH")

    def test_07_malicious_zip_path_rejected(self) -> None:
        bad = self.root / "bad-path.zip"
        with zipfile.ZipFile(bad, "w") as archive:
            archive.writestr("../escape.txt", b"bad")
        project, _ = self.new_case("bad-path")
        result = self.run_bootstrap("inspect", "--zip", str(bad), "--target", str(project), expected=2)
        self.assertEqual(result["code"], "PACKAGE_UNSAFE_PATH")
        self.assertFalse((self.root / "escape.txt").exists())

    def test_08_plan_must_be_outside_project(self) -> None:
        project, _ = self.new_case("plan-boundary")
        result = self.run_bootstrap(
            "plan", "--zip", str(self.zip_path), "--target", str(project),
            "--output", str(project / "plan.json"), expected=2,
        )
        self.assertEqual(result["code"], "INSTALL_PLAN_INSIDE_PROJECT")

    def test_09_repeat_install_is_idempotent(self) -> None:
        project, work1 = self.new_case("repeat")
        plan1 = self.create_plan(project, work1)
        self.run_bootstrap("apply", "--plan", str(plan1))
        first_state = json.loads((project / ".ai" / "INSTALL_STATE.json").read_text(encoding="utf-8"))
        work2 = self.root / "repeat-work-2"
        work2.mkdir()
        plan2 = self.create_plan(project, work2)
        plan_data = json.loads(plan2.read_text(encoding="utf-8"))
        self.assertTrue(all(op["kind"] == "KEEP" for op in plan_data["operations"]))
        self.run_bootstrap("apply", "--plan", str(plan2))
        second_state = json.loads((project / ".ai" / "INSTALL_STATE.json").read_text(encoding="utf-8"))
        self.assertEqual(first_state["package"], second_state["package"])

    def test_10_existing_v6_payload_is_preserved(self) -> None:
        project, work = self.new_case("legacy-v6")
        shutil.copytree(self.package_root / "payload" / ".ai", project / ".ai")
        legacy_hash = hashlib.sha256((project / ".ai" / "AGENTS.md").read_bytes()).hexdigest()
        (project / "CLAUDE.md").write_text("# Existing Claude instructions\n", encoding="utf-8")
        plan = self.create_plan(project, work)
        data = json.loads(plan.read_text(encoding="utf-8"))
        self.assertFalse(data["conflicts"])
        self.assertTrue(data["legacy_package_verified"])
        self.run_bootstrap("apply", "--plan", str(plan))
        self.assertEqual(hashlib.sha256((project / ".ai" / "AGENTS.md").read_bytes()).hexdigest(), legacy_hash)
        self.assertTrue((project / "CLAUDE.md").read_text(encoding="utf-8").startswith("# Existing Claude instructions\n"))

    def test_11_plan_drift_is_rejected(self) -> None:
        project, work = self.new_case("plan-drift")
        plan = self.create_plan(project, work)
        (project / "AGENTS.md").write_text("created after plan\n", encoding="utf-8")
        result = self.run_bootstrap("apply", "--plan", str(plan), expected=2)
        self.assertEqual(result["code"], "INSTALL_PLAN_STALE")
        self.assertEqual((project / "AGENTS.md").read_text(encoding="utf-8"), "created after plan\n")

    def test_12_manifest_tamper_is_rejected(self) -> None:
        tampered = self.root / "tampered.zip"
        with zipfile.ZipFile(self.zip_path) as source, zipfile.ZipFile(tampered, "w", zipfile.ZIP_DEFLATED) as output:
            for info in source.infolist():
                data = source.read(info.filename)
                if info.filename == "PACKAGE.json":
                    data += b"\n"
                output.writestr(info.filename, data)
        project, _ = self.new_case("tampered")
        result = self.run_bootstrap("inspect", "--zip", str(tampered), "--target", str(project), expected=2)
        self.assertEqual(result["code"], "PACKAGE_MANIFEST_HASH_MISMATCH")

    def test_13_rollback_never_overwrites_external_change(self) -> None:
        project, work = self.new_case("rollback-conflict")
        plan = self.create_plan(project, work)
        self.run_bootstrap("apply", "--plan", str(plan))
        protected = project / ".ai" / "system" / "aic.py"
        protected.write_text("external change after install\n", encoding="utf-8")
        tx = self.transaction_from(work)
        result = self.run_bootstrap("rollback", "--transaction", str(tx), expected=2)
        self.assertEqual(result["code"], "INSTALL_ROLLBACK_CONFLICT")
        self.assertEqual(protected.read_text(encoding="utf-8"), "external change after install\n")

    def test_14_casefold_duplicate_zip_path_rejected(self) -> None:
        bad = self.root / "bad-duplicate.zip"
        with zipfile.ZipFile(bad, "w") as archive:
            archive.writestr("File.txt", b"one")
            archive.writestr("file.txt", b"two")
        project, _ = self.new_case("bad-duplicate")
        result = self.run_bootstrap("inspect", "--zip", str(bad), "--target", str(project), expected=2)
        self.assertEqual(result["code"], "PACKAGE_DUPLICATE_PATH")

    def test_15_zip_symlink_rejected(self) -> None:
        bad = self.root / "bad-symlink.zip"
        info = zipfile.ZipInfo("link")
        info.create_system = 3
        info.external_attr = 0o120777 << 16
        with zipfile.ZipFile(bad, "w") as archive:
            archive.writestr(info, b"target")
        project, _ = self.new_case("bad-symlink")
        result = self.run_bootstrap("inspect", "--zip", str(bad), "--target", str(project), expected=2)
        self.assertEqual(result["code"], "PACKAGE_SPECIAL_FILE")

    def test_16_abnormal_compression_ratio_rejected(self) -> None:
        bad = self.root / "bad-ratio.zip"
        with zipfile.ZipFile(bad, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr("zeros.bin", b"0" * (2 * 1024 * 1024))
        project, _ = self.new_case("bad-ratio")
        result = self.run_bootstrap("inspect", "--zip", str(bad), "--target", str(project), expected=2)
        self.assertEqual(result["code"], "PACKAGE_COMPRESSION_RATIO_LIMIT")

    def test_17_target_symlink_boundary_when_supported(self) -> None:
        project, work = self.new_case("target-symlink")
        outside = self.root / "outside-target"
        outside.mkdir()
        try:
            os.symlink(outside, project / ".ai", target_is_directory=True)
        except (OSError, NotImplementedError):
            if os.name == "nt":
                junction = subprocess.run(
                    ["cmd", "/c", "mklink", "/J", str(project / ".ai"), str(outside)],
                    capture_output=True, text=True, encoding="utf-8", errors="replace",
                )
                if junction.returncode != 0:
                    self.skipTest("symlink and junction creation unavailable on this host")
            else:
                self.skipTest("symlink creation unavailable on this host")
        plan = work / "plan.json"
        result = self.run_bootstrap(
            "plan", "--zip", str(self.zip_path), "--target", str(project), "--output", str(plan),
            expected=2,
        )
        self.assertIn(result["code"], {"PATH_REPARSE_POINT", "PATH_ESCAPE"})
        self.assertEqual(list(outside.iterdir()), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
