from __future__ import annotations

import os
from pathlib import Path
import sys
import tempfile
import unittest


SYSTEM_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SYSTEM_ROOT))

from project_scan import adapter_list, inspect_project, workflow_profile  # noqa: E402
from state_core import StateStore  # noqa: E402


class ProjectScanTests(unittest.TestCase):
    def new_store(self) -> tuple[tempfile.TemporaryDirectory, Path, StateStore]:
        temporary = tempfile.TemporaryDirectory(prefix="aic-project-scan-")
        root = Path(temporary.name)
        store = StateStore(root)
        store.initialize("scan-test")
        return temporary, root, store

    def test_embedded_sample_is_generic_and_evidence_backed(self) -> None:
        temporary, root, store = self.new_store()
        try:
            (root / "firmware").mkdir()
            (root / "firmware" / "main.c").write_text("int main(void){}\n", encoding="utf-8")
            (root / "firmware" / "board.h").write_text("#pragma once\n", encoding="utf-8")
            (root / "CMakeLists.txt").write_text("project(firmware C)\n", encoding="utf-8")
            result = inspect_project(store, "LIGHT")
            self.assertEqual(result["primary"]["category"], "embedded")
            self.assertTrue(result["primary"]["evidence"])
            self.assertIn("firmware/main.c", json_paths(result))
        finally:
            temporary.cleanup()

    def test_web_desktop_sample_and_monorepo_subprojects(self) -> None:
        temporary, root, store = self.new_store()
        try:
            (root / "apps" / "web").mkdir(parents=True)
            (root / "apps" / "desktop").mkdir(parents=True)
            (root / "apps" / "web" / "package.json").write_text("{}", encoding="utf-8")
            (root / "apps" / "web" / "App.tsx").write_text("export default 1", encoding="utf-8")
            (root / "apps" / "desktop" / "package.json").write_text("{}", encoding="utf-8")
            result = inspect_project(store, "STANDARD")
            self.assertEqual(result["primary"]["category"], "web-desktop")
            self.assertEqual(result["subprojects"], ["apps/desktop", "apps/web"])
        finally:
            temporary.cleanup()

    def test_unknown_sample_degrades_without_guessing(self) -> None:
        temporary, root, store = self.new_store()
        try:
            (root / "说明资料.unknown").write_text("未知格式", encoding="utf-8")
            result = inspect_project(store, "LIGHT")
            self.assertEqual(result["primary"]["adapter_id"], "project.unknown")
            self.assertEqual(result["unknown_items"], ["project-framework"])
        finally:
            temporary.cleanup()

    def test_budget_and_cancel_stop_safely(self) -> None:
        temporary, root, store = self.new_store()
        try:
            for index in range(20):
                (root / f"file-{index}.c").write_text("x", encoding="utf-8")
            limited = inspect_project(store, "LIGHT", max_files=3)
            self.assertFalse(limited["complete"])
            self.assertEqual(limited["stop_reason"], "FILE_BUDGET")
            cancel = root / "cancel.scan"
            cancel.write_text("stop", encoding="utf-8")
            cancelled = inspect_project(store, "LIGHT", cancel_file="cancel.scan")
            self.assertEqual(cancelled["stop_reason"], "CANCELLED")
        finally:
            temporary.cleanup()

    def test_unicode_and_symlink_boundary(self) -> None:
        temporary, root, store = self.new_store()
        try:
            (root / "源码").mkdir()
            (root / "源码" / "主程序.c").write_text("int x;", encoding="utf-8")
            outside = root.parent / (root.name + "-outside")
            outside.mkdir()
            link = root / "源码" / "external-link"
            try:
                os.symlink(outside, link, target_is_directory=True)
            except (OSError, NotImplementedError):
                link = None
            result = inspect_project(store, "LIGHT")
            self.assertEqual(result["primary"]["category"], "embedded")
            if link is not None:
                self.assertIn("源码/external-link", result["symlinks_skipped"])
            outside.rmdir()
        finally:
            temporary.cleanup()

    def test_profiles_and_adapter_registry_are_versioned(self) -> None:
        self.assertLess(workflow_profile("LIGHT")["max_files"], workflow_profile("FULL")["max_files"])
        registry = adapter_list()
        self.assertEqual(registry["registry_version"], "1.0.0")
        self.assertIn("client.generic", {item["id"] for item in registry["client_adapters"]})


def json_paths(result: dict) -> list[str]:
    cache = Path(result["root"]) / ".ai" / "run" / "cache" / "project-scan.json"
    import json
    return json.loads(cache.read_text(encoding="utf-8"))["sampled_paths"]


if __name__ == "__main__":
    unittest.main()
