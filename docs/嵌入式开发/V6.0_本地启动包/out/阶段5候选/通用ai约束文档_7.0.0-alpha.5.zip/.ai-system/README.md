# AI 工程约束系统 7.0.0-alpha.5

本目录是最终 ZIP 内可直接运行、检查和由 AI 维护的系统文件，不依赖单独源码工程。

当前阶段增加版本化项目/客户端适配器、嵌入式/Web/未知项目安全识别、Monorepo 发现、Unicode/链接边界、可取消预算扫描和三级实际流程。V6 规则、模板和工具继续作为兼容载荷安装。

运行边界和命令见 `ENTRYPOINT.md`、顶层 `bootstrap.py` 以及 `python .ai/system/aic.py --help`。

状态只能通过 `aic.py` 命令更新。不要直接编辑 `.ai/state/`、`.ai/run/` 或 `.ai/views/`。本机锁不是跨计算机分布式锁；权威事件历史损坏时只允许只读导出和人工恢复。
