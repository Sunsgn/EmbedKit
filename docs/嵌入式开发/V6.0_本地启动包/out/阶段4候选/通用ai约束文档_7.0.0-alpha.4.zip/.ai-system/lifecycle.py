#!/usr/bin/env python3
"""Evidence, lifecycle gates and deterministic engineering summaries."""

from __future__ import annotations

import json
from pathlib import Path
import subprocess
from typing import Any

from state_core import (
    NEXT_STATUSES,
    SCHEMA_VERSION,
    StateError,
    StateStore,
    file_sha256,
    new_id,
    utc_now,
)


MAX_EVIDENCE_BYTES = 20 * 1024 * 1024
SUMMARY_TYPES = {
    "INITIALIZATION", "STAGE", "TECHNICAL", "ISSUE_CLOSURE", "CHANGE",
    "MILESTONE", "RETROSPECTIVE", "HANDOFF", "RECOVERY", "MAINTENANCE",
}


def load_registry() -> dict[str, Any]:
    path = Path(__file__).resolve().parent / "rules" / "lifecycle-registry.json"
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise StateError("RULE_REGISTRY_INVALID", "生命周期规则注册表无法读取", path=str(path), error=str(exc)) from exc
    if value.get("schema") != "aic.rule-registry" or value.get("schema_version") != SCHEMA_VERSION:
        raise StateError("RULE_REGISTRY_UNSUPPORTED", "生命周期规则注册表版本不兼容")
    return value


def list_rules() -> dict[str, Any]:
    registry = load_registry()
    return {
        "registry_version": registry["registry_version"],
        "rules": registry["rules"],
        "task_transitions": registry["task_transitions"],
        "next_transitions": registry["next_transitions"],
    }


def _project_relative_file(store: StateStore, supplied: str) -> tuple[Path, str]:
    path = Path(supplied)
    if not path.is_absolute():
        path = store.root / path
    resolved = path.resolve(strict=False)
    if not resolved.is_relative_to(store.root):
        raise StateError("PATH_OUTSIDE_PROJECT", "证据文件必须位于项目根目录内", path=str(resolved))
    if not resolved.is_file():
        raise StateError("EVIDENCE_ARTIFACT_MISSING", "证据文件不存在", path=str(resolved))
    if resolved.is_symlink():
        raise StateError("PATH_SYMLINK_UNSUPPORTED", "证据文件不能是符号链接", path=str(resolved))
    size = resolved.stat().st_size
    if size > MAX_EVIDENCE_BYTES:
        raise StateError("EVIDENCE_SIZE_LIMIT", "证据文件超过阶段 3 单文件上限", size=size, limit=MAX_EVIDENCE_BYTES)
    return resolved, resolved.relative_to(store.root).as_posix()


def add_evidence(
    store: StateStore,
    task_id: str,
    evidence_type: str,
    result: str,
    artifact: str,
    expected_state_revision: int,
    session_id: str,
    limitations: list[str],
) -> dict[str, Any]:
    task = store._load_entity("task", task_id)
    if task is None:
        raise StateError("TASK_NOT_FOUND", "任务不存在", task_id=task_id)
    if not evidence_type.strip() or not result.strip():
        raise StateError("INPUT_EVIDENCE_FIELDS_REQUIRED", "证据类型和结果不能为空")
    path, relative = _project_relative_file(store, artifact)
    now = utc_now()
    evidence_id = new_id("EVD")
    normalized_result = result.strip().upper()
    status = "VALID" if normalized_result in {"PASS", "SUCCESS", "OK", "VERIFIED"} else "FAILED"
    evidence = {
        "schema": "aic.evidence", "schema_version": SCHEMA_VERSION, "id": evidence_id,
        "project_id": task["project_id"], "revision": 1, "status": status,
        "evidence_type": evidence_type.strip(), "type": evidence_type.strip(),
        "source": relative, "producer": session_id, "captured_at": now,
        "project_revision": expected_state_revision, "git_commit": git_baseline(store.root).get("commit"),
        "input_refs": [task_id], "artifact_path": relative,
        "content_sha256": file_sha256(path), "sha256": file_sha256(path), "size": path.stat().st_size,
        "result": normalized_result, "validity": "VALID" if status == "VALID" else "UNKNOWN",
        "limitations": limitations, "invalidated_by": [], "created_at": now, "updated_at": now,
        "created_by": session_id, "updated_by": session_id, "extensions": {},
    }
    updated_task = dict(task)
    updated_task["revision"] = task["revision"] + 1
    updated_task["updated_at"] = now
    updated_task["updated_by"] = session_id
    updated_task["evidence_refs"] = list(dict.fromkeys([*task.get("evidence_refs", []), evidence_id]))
    changes = [
        store._change("evidence", evidence, 0, "evidence.captured"),
        store._change("task", updated_task, task["revision"], "task.evidence-linked"),
    ]
    committed = store.commit(changes, expected_state_revision, session_id)
    return {"evidence": evidence, "task_revision": updated_task["revision"], **committed}


def verify_evidence(
    store: StateStore,
    evidence_id: str,
    expected_state_revision: int,
    expected_entity_revision: int,
    session_id: str,
) -> dict[str, Any]:
    evidence = store._load_entity("evidence", evidence_id)
    if evidence is None:
        raise StateError("EVIDENCE_NOT_FOUND", "证据不存在", evidence_id=evidence_id)
    if evidence.get("revision") != expected_entity_revision:
        raise StateError("ENTITY_REVISION_CONFLICT", "证据实体修订已变化", expected=expected_entity_revision, actual=evidence.get("revision"))
    path = (store.root / evidence["artifact_path"]).resolve(strict=False)
    observed = "VALID"
    reason = None
    actual_hash = None
    if not path.is_relative_to(store.root) or not path.is_file():
        observed = "UNAVAILABLE"
        reason = "artifact-missing"
    else:
        actual_hash = file_sha256(path)
        if actual_hash != evidence.get("content_sha256"):
            observed = "CORRUPT"
            reason = "artifact-hash-changed"
    if observed == "VALID":
        return {"changed": False, "evidence": evidence, "observed": observed, "actual_sha256": actual_hash}
    return invalidate_evidence(
        store, evidence_id, reason or "verification-failed", expected_state_revision,
        expected_entity_revision, session_id, forced_status=observed,
    )


def invalidate_evidence(
    store: StateStore,
    evidence_id: str,
    reason: str,
    expected_state_revision: int,
    expected_entity_revision: int,
    session_id: str,
    forced_status: str = "STALE",
) -> dict[str, Any]:
    evidence = store._load_entity("evidence", evidence_id)
    if evidence is None:
        raise StateError("EVIDENCE_NOT_FOUND", "证据不存在", evidence_id=evidence_id)
    if not reason.strip():
        raise StateError("INPUT_INVALIDATION_REASON_REQUIRED", "证据失效原因不能为空")
    now = utc_now()
    updated = dict(evidence)
    updated["revision"] = expected_entity_revision + 1
    updated["status"] = forced_status
    updated["validity"] = "STALE" if forced_status == "STALE" else forced_status
    updated["invalidated_by"] = [*evidence.get("invalidated_by", []), {"reason": reason.strip(), "at": now, "session_id": session_id}]
    updated["updated_at"] = now
    updated["updated_by"] = session_id
    changes = [store._change("evidence", updated, expected_entity_revision, "evidence.invalidated")]
    affected_tasks: list[str] = []
    affected_summaries: list[str] = []
    for entity in store._all_entities():
        if evidence_id not in entity.get("evidence_refs", []):
            continue
        if entity.get("schema") == "aic.task" and entity.get("status") in {"VERIFYING", "COMPLETED"}:
            changed = dict(entity)
            changed["revision"] = entity["revision"] + 1
            changed["status"] = "STALE"
            changed["updated_at"] = now
            changed["updated_by"] = session_id
            changes.append(store._change("task", changed, entity["revision"], "task.evidence-stale"))
            affected_tasks.append(entity["id"])
        if entity.get("schema") == "aic.summary" and entity.get("status") == "VERIFIED":
            changed = dict(entity)
            changed["revision"] = entity["revision"] + 1
            changed["status"] = "STALE"
            changed["updated_at"] = now
            changed["updated_by"] = session_id
            changes.append(store._change("summary", changed, entity["revision"], "summary.evidence-stale"))
            affected_summaries.append(entity["id"])
    committed = store.commit(changes, expected_state_revision, session_id)
    return {"changed": True, "evidence": updated, "affected_tasks": affected_tasks, "affected_summaries": affected_summaries, **committed}


def transition_task(
    store: StateStore,
    task_id: str,
    to_status: str,
    expected_entity_revision: int,
    expected_state_revision: int,
    session_id: str,
    completed: list[str],
    remaining: list[str],
    blockers: list[str],
    resolved_blockers: list[str],
    failed_attempts: list[str],
    unknowns: list[str],
    resume_condition: str | None,
    resolution_condition: str | None,
) -> dict[str, Any]:
    task = store._load_entity("task", task_id)
    if task is None:
        raise StateError("TASK_NOT_FOUND", "任务不存在", task_id=task_id)
    registry = load_registry()
    allowed = registry["task_transitions"].get(task["status"], [])
    if to_status not in allowed:
        raise StateError("TASK_TRANSITION_INVALID", "任务状态转换不允许", current=task["status"], requested=to_status, allowed=allowed)
    if to_status == "PAUSED" and not resume_condition:
        raise StateError("TASK_RESUME_CONDITION_REQUIRED", "暂停任务必须提供恢复条件")
    if to_status == "BLOCKED" and not resolution_condition:
        raise StateError("TASK_RESOLUTION_CONDITION_REQUIRED", "阻断任务必须提供解除条件")
    if to_status == "FAILED" and not failed_attempts:
        raise StateError("TASK_FAILURE_EVIDENCE_REQUIRED", "失败任务必须记录失败方案或原因")
    now = utc_now()
    updated = dict(task)
    updated["revision"] = expected_entity_revision + 1
    updated["status"] = to_status
    updated["updated_at"] = now
    updated["updated_by"] = session_id
    for key, values in (
        ("completed_work", completed), ("remaining_work", remaining), ("blockers", blockers),
        ("failed_attempts", failed_attempts), ("unknowns", unknowns),
    ):
        if values:
            updated[key] = list(dict.fromkeys([*task.get(key, []), *values]))
    if completed:
        updated["remaining_work"] = [item for item in updated.get("remaining_work", []) if item not in set(completed)]
    if resolved_blockers:
        updated["blockers"] = [item for item in updated.get("blockers", []) if item not in set(resolved_blockers)]
    if resume_condition:
        updated["resume_condition"] = resume_condition
    if resolution_condition:
        updated["resolution_condition"] = resolution_condition
    if to_status == "COMPLETED":
        _completion_gate(store, updated)
    committed = store.commit(
        [store._change("task", updated, expected_entity_revision, "task.status.changed")],
        expected_state_revision, session_id,
    )
    return {"task": updated, **committed}


def _completion_gate(store: StateStore, task: dict[str, Any]) -> None:
    failures: list[dict[str, Any]] = []
    if not task.get("acceptance_criteria"):
        failures.append({"code": "ACCEPTANCE_CRITERIA_MISSING"})
    if task.get("remaining_work"):
        failures.append({"code": "REMAINING_WORK_EXISTS", "items": task["remaining_work"]})
    if task.get("blockers"):
        failures.append({"code": "BLOCKERS_EXIST", "items": task["blockers"]})
    evidence = [store._load_entity("evidence", item) for item in task.get("evidence_refs", [])]
    valid_evidence = [item for item in evidence if item and item.get("status") == "VALID" and item.get("validity") == "VALID"]
    if not valid_evidence:
        failures.append({"code": "VALID_EVIDENCE_MISSING"})
    summaries = [store._load_entity("summary", item) for item in task.get("summary_refs", [])]
    if not any(item and item.get("status") == "VERIFIED" for item in summaries):
        failures.append({"code": "VERIFIED_SUMMARY_MISSING"})
    active_next = []
    for action_id in task.get("next_action_refs", []):
        action = store._load_entity("next_action", action_id)
        if action and action.get("status") not in {"DONE", "CANCELLED", "STALE"}:
            active_next.append(action_id)
    if active_next:
        failures.append({"code": "ACTIVE_NEXT_ACTIONS_EXIST", "items": active_next})
    if failures:
        raise StateError("TASK_COMPLETION_GATE_FAILED", "任务不满足完成门禁", failures=failures)


def update_next(
    store: StateStore,
    action_id: str,
    to_status: str,
    expected_entity_revision: int,
    expected_state_revision: int,
    session_id: str,
) -> dict[str, Any]:
    action = store._load_entity("next_action", action_id)
    if action is None:
        raise StateError("NEXT_ACTION_NOT_FOUND", "下一步不存在", next_action_id=action_id)
    if to_status not in NEXT_STATUSES:
        raise StateError("INPUT_NEXT_STATUS_INVALID", "下一步状态无效", status=to_status)
    allowed = load_registry()["next_transitions"].get(action["status"], [])
    if to_status not in allowed:
        raise StateError("NEXT_TRANSITION_INVALID", "下一步状态转换不允许", current=action["status"], requested=to_status, allowed=allowed)
    updated = dict(action)
    updated["revision"] = expected_entity_revision + 1
    updated["status"] = to_status
    updated["updated_at"] = utc_now()
    updated["updated_by"] = session_id
    committed = store.commit([store._change("next_action", updated, expected_entity_revision, "next-action.status.changed")], expected_state_revision, session_id)
    return {"next_action": updated, **committed}


def git_baseline(root: Path) -> dict[str, Any]:
    try:
        process = subprocess.run(
            ["git", "-C", str(root), "status", "--porcelain=v1", "--branch"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=8, shell=False,
        )
        commit = subprocess.run(
            ["git", "-C", str(root), "rev-parse", "HEAD"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=8, shell=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"available": False, "error": str(exc), "commit": None, "status": []}
    return {
        "available": process.returncode == 0, "commit": commit.stdout.strip() if commit.returncode == 0 else None,
        "status": process.stdout.splitlines()[:200], "truncated": len(process.stdout.splitlines()) > 200,
    }


def generate_summary(
    store: StateStore,
    task_id: str,
    summary_type: str,
    trigger: str,
    expected_state_revision: int,
    session_id: str,
) -> dict[str, Any]:
    if summary_type not in SUMMARY_TYPES:
        raise StateError("INPUT_SUMMARY_TYPE_INVALID", "总结类型无效", summary_type=summary_type)
    task = store._load_entity("task", task_id)
    if task is None:
        raise StateError("TASK_NOT_FOUND", "任务不存在", task_id=task_id)
    if not trigger.strip():
        raise StateError("INPUT_SUMMARY_TRIGGER_REQUIRED", "总结触发原因不能为空")
    for item in store._all_entities():
        if item.get("schema") == "aic.summary" and item.get("task_id") == task_id and item.get("summary_type") == summary_type and item.get("source_state_revision") == expected_state_revision:
            return {"created": False, "duplicate_of": item["id"], "summary": item}
    evidence = [store._load_entity("evidence", item) for item in task.get("evidence_refs", [])]
    evidence = [item for item in evidence if item]
    next_actions = [store._load_entity("next_action", item) for item in task.get("next_action_refs", [])]
    next_actions = [item for item in next_actions if item]
    now = utc_now()
    summary_id = new_id("SUM")
    summary = {
        "schema": "aic.summary", "schema_version": SCHEMA_VERSION, "id": summary_id,
        "project_id": task["project_id"], "revision": 1, "status": "DRAFT",
        "summary_type": summary_type, "task_id": task_id, "session_id": session_id,
        "source_state_revision": expected_state_revision, "trigger": trigger.strip(),
        "git_baseline": git_baseline(store.root), "goal": task.get("normalized_goal"),
        "completed_work": task.get("completed_work", []), "remaining_work": task.get("remaining_work", []),
        "evidence_refs": [item["id"] for item in evidence],
        "evidence_status": [{"id": item["id"], "status": item["status"], "result": item.get("result")} for item in evidence],
        "facts": [
            {"kind": "task-status", "value": task.get("status")},
            {"kind": "completed-count", "value": len(task.get("completed_work", []))},
            {"kind": "evidence-count", "value": len(evidence)},
        ],
        "inferences": [], "unknowns": task.get("unknowns", []),
        "failed_attempts": task.get("failed_attempts", []), "risks": task.get("blockers", []),
        "recovery": task.get("resume_condition") or task.get("resolution_condition"),
        "next_action_refs": [item["id"] for item in sorted(next_actions, key=lambda value: (value.get("priority", 999), value["id"])) if item.get("status") not in {"DONE", "CANCELLED", "STALE"}],
        "created_at": now, "updated_at": now, "created_by": session_id, "updated_by": session_id,
        "extensions": {},
    }
    updated_task = dict(task)
    updated_task["revision"] = task["revision"] + 1
    updated_task["updated_at"] = now
    updated_task["updated_by"] = session_id
    updated_task["summary_refs"] = list(dict.fromkeys([*task.get("summary_refs", []), summary_id]))
    changes = [
        store._change("summary", summary, 0, "summary.generated"),
        store._change("task", updated_task, task["revision"], "task.summary-linked"),
    ]
    committed = store.commit(changes, expected_state_revision, session_id)
    return {"created": True, "summary": summary, "task_revision": updated_task["revision"], **committed}


def verify_summary(
    store: StateStore,
    summary_id: str,
    expected_entity_revision: int,
    expected_state_revision: int,
    session_id: str,
) -> dict[str, Any]:
    summary = store._load_entity("summary", summary_id)
    if summary is None:
        raise StateError("SUMMARY_NOT_FOUND", "总结不存在", summary_id=summary_id)
    if summary.get("source_state_revision", -1) > expected_state_revision:
        raise StateError("SUMMARY_SOURCE_REVISION_INVALID", "总结来源修订晚于当前状态")
    invalid = [item for item in summary.get("evidence_status", []) if item.get("status") not in {"VALID"}]
    if invalid:
        raise StateError("SUMMARY_EVIDENCE_INVALID", "总结包含无效证据，不能验证", evidence=invalid)
    updated = dict(summary)
    updated["revision"] = expected_entity_revision + 1
    updated["status"] = "VERIFIED"
    updated["verified_at"] = utc_now()
    updated["updated_at"] = updated["verified_at"]
    updated["updated_by"] = session_id
    committed = store.commit([store._change("summary", updated, expected_entity_revision, "summary.verified")], expected_state_revision, session_id)
    return {"summary": updated, **committed}
