# AI 工程约束系统

使用入口见 `ENTRYPOINT.md`，命令见 `python .ai/system/aic.py --help`。状态只能通过 `aic.py` 更新，不得直接编辑权威状态、运行锁或派生视图。

默认工作流回执采用有边界的紧凑结构；完整实体通过 `--full`、`task show`、`summary show`、`evidence show` 按需读取。维护通用核心时从受信任最终 ZIP 创建项目外工作区，完整回归通过后才能重打包。
