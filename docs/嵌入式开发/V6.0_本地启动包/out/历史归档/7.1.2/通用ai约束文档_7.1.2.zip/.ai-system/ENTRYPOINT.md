# AI 工程约束系统统一入口

## 每次会话

1. 在项目根运行 `python .ai/system/aic.py status --verify --json`。未初始化时只执行一次 `state init`。
2. 运行 `python .ai/system/aic.py workflow resume --client "<客户端>" --json`。默认回执是有数量和截断标记的紧凑快照；仅排障时追加 `--full`。
3. 读取 `.ai/AGENTS.md` 和 `.ai/.ai-engineering/RULES_INDEX.md`，再按任务路由精确读取规则、项目事实和专业规范；不要无差别加载全部文件。客户端未自动加载通用说明时再读取 `.ai/AI-INSTRUCTIONS.md`。
4. 续做活动任务时执行回执中的 `recommended_command`。新任务直接执行 `workflow begin`；若已经 resume，传入其 `--session-id`，不得再创建会话。
5. 使用 `workflow advance` 推进任务，使用 `evidence add` 将真实证据绑定到每个 `ACPT-*`，最后使用 `workflow finish`。默认均返回紧凑回执，需要完整实体时才追加 `--full` 或调用对应 `show`。
6. 修改前检查 Git 和用户改动，取得覆盖目标的锁；长任务续租。冲突、过期锁、包损坏或权威状态异常时停止写入。
7. 结束时执行 `workflow close-session`。仅在容量告警、健康异常、恢复操作或里程碑验收时运行完整 `state capacity`、`doctor diagnose` 和 `state verify`。

结构化状态优先于聊天记忆。不得直接编辑 `.ai/state/`、`.ai/run/`、`.ai/views/`，不得把未运行的测试、未核验证据或未执行步骤描述为完成。本机锁不代表跨计算机强锁。
