#!/usr/bin/env python3
"""Phase-1 clean-room integration and failure-path tests."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile


SOURCE_ROOT = Path(__file__).resolve().parents[2]


class BootstrapIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.temp = tempfile.TemporaryDirectory(prefix="aic-bootstrap-tests-")
        cls.root = Path(cls.temp.name)
        cls.package_root = cls.root / "package"
        shutil.copytree(SOURCE_ROOT, cls.package_root, ignore=shutil.ignore_patterns("__pycache__", "PACKAGE_MANIFEST.json"))
        cls.zip_path = cls.root / "candidate.zip"
        repack = cls.package_root / ".ai-system" / "maintenance" / "repack.py"
        process = subprocess.run(
            [sys.executable, str(repack), "--package-root", str(cls.package_root), "--output", str(cls.zip_path)],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60,
        )
        if process.returncode != 0:
            raise RuntimeError(process.stdout + process.stderr)
        cls.zip_hash = hashlib.sha256(cls.zip_path.read_bytes()).hexdigest()
        cls.bootstrap = cls.package_root / "bootstrap.py"

    @classmethod
    def tearDownClass(cls) -> None:
        cls.temp.cleanup()

    def run_bootstrap(self, *args: str, env: dict[str, str] | None = None, expected: int = 0) -> dict:
        process = subprocess.run(
            [sys.executable, str(self.bootstrap), *args, "--json"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=90, env=env,
        )
        self.assertEqual(process.returncode, expected, process.stdout + process.stderr)
        return json.loads(process.stdout)

    def run_aic(self, project: Path, *args: str, expected: int = 0) -> dict:
        process = subprocess.run(
            [sys.executable, str(project / ".ai" / "system" / "aic.py"), *args, "--json"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=90,
        )
        self.assertEqual(process.returncode, expected, process.stdout + process.stderr)
        return json.loads(process.stdout)

    def new_case(self, name: str) -> tuple[Path, Path]:
        project = self.root / (name + "-project")
        work = self.root / (name + "-work")
        project.mkdir()
        work.mkdir()
        return project, work

    def create_plan(self, project: Path, work: Path) -> Path:
        plan = work / "plan.json"
        result = self.run_bootstrap(
            "plan", "--zip", str(self.zip_path), "--target", str(project),
            "--output", str(plan), "--expected-sha256", self.zip_hash,
        )
        self.assertEqual(result["code"], "PLAN_READY")
        return plan

    def create_variant_package(self, name: str, marker: str) -> Path:
        package_root = self.root / (name + "-package")
        shutil.copytree(self.package_root, package_root, ignore=shutil.ignore_patterns("__pycache__", "PACKAGE_MANIFEST.json"))
        entrypoint = package_root / "entrypoints" / "AGENTS.md"
        entrypoint.write_text(entrypoint.read_text(encoding="utf-8").replace(
            "## AI 工程约束系统入口", f"## AI 工程约束系统入口 {marker}",
        ), encoding="utf-8")
        package = json.loads((package_root / "PACKAGE.json").read_text(encoding="utf-8"))
        package["package_version"] = "7.1.1-test"
        (package_root / "PACKAGE.json").write_text(
            json.dumps(package, ensure_ascii=False, indent=2) + "\n", encoding="utf-8",
        )
        output = self.root / (name + ".zip")
        process = subprocess.run(
            [sys.executable, str(package_root / ".ai-system" / "maintenance" / "repack.py"),
             "--package-root", str(package_root), "--output", str(output)],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60,
        )
        self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
        return output

    def transaction_from(self, work: Path) -> Path:
        transactions = list((work / "transactions").glob("*/transaction.json"))
        self.assertEqual(len(transactions), 1)
        return transactions[0]

    def test_01_preflight_and_manifest(self) -> None:
        project, _ = self.new_case("inspect")
        result = self.run_bootstrap(
            "inspect", "--zip", str(self.zip_path), "--target", str(project),
            "--expected-sha256", self.zip_hash,
        )
        self.assertEqual(result["code"], "INSPECT_OK")
        expected = json.loads((self.package_root / "PACKAGE.json").read_text(encoding="utf-8"))["package_version"]
        self.assertEqual(result["details"]["package"]["package_version"], expected)

    def test_02_fresh_install_verify_and_rollback(self) -> None:
        project, work = self.new_case("fresh")
        plan = self.create_plan(project, work)
        result = self.run_bootstrap("apply", "--plan", str(plan))
        self.assertEqual(result["code"], "INSTALL_COMMITTED")
        installed = project / ".ai" / "system" / "aic.py"
        process = subprocess.run(
            [sys.executable, str(installed), "status", "--verify", "--json"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30,
        )
        self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
        self.assertEqual(json.loads(process.stdout)["code"], "STATUS_OK")
        tx = self.transaction_from(work)
        rolled = self.run_bootstrap("rollback", "--transaction", str(tx))
        self.assertEqual(rolled["code"], "INSTALL_ROLLED_BACK")
        self.assertEqual(list(project.iterdir()), [])

    def test_03_existing_entrypoint_preserved(self) -> None:
        project, work = self.new_case("existing-entry")
        original = b"# User instructions\n\nKeep this exact text.\n"
        (project / "AGENTS.md").write_bytes(original)
        before = hashlib.sha256(original).hexdigest()
        plan = self.create_plan(project, work)
        self.run_bootstrap("apply", "--plan", str(plan))
        merged = (project / "AGENTS.md").read_bytes()
        self.assertTrue(merged.startswith(original))
        self.assertIn(b"AI-CONSTRAINTS:BEGIN", merged)
        tx = self.transaction_from(work)
        self.run_bootstrap("rollback", "--transaction", str(tx))
        restored = (project / "AGENTS.md").read_bytes()
        self.assertEqual(hashlib.sha256(restored).hexdigest(), before)
        self.assertEqual(restored, original)

    def test_04_unknown_payload_conflict_blocks_apply(self) -> None:
        project, work = self.new_case("payload-conflict")
        target = project / ".ai" / "AGENTS.md"
        target.parent.mkdir()
        target.write_text("project-specific content\n", encoding="utf-8")
        plan = work / "plan.json"
        result = self.run_bootstrap(
            "plan", "--zip", str(self.zip_path), "--target", str(project), "--output", str(plan),
        )
        self.assertEqual(result["code"], "PLAN_CREATED_WITH_CONFLICTS")
        self.assertFalse(result["details"]["can_apply"])
        failed = self.run_bootstrap("apply", "--plan", str(plan), expected=2)
        self.assertEqual(failed["code"], "INSTALL_PLAN_HAS_CONFLICTS")
        self.assertEqual(target.read_text(encoding="utf-8"), "project-specific content\n")

    def test_05_failure_resume(self) -> None:
        project, work = self.new_case("resume")
        plan = self.create_plan(project, work)
        env = os.environ.copy()
        env["AIC_TEST_MODE"] = "1"
        env["AIC_TEST_FAIL_AFTER"] = "3"
        failed = self.run_bootstrap("apply", "--plan", str(plan), env=env, expected=2)
        self.assertEqual(failed["code"], "INSTALL_EXECUTION_FAILED")
        tx = Path(failed["details"]["transaction"])
        resumed = self.run_bootstrap("resume", "--transaction", str(tx))
        self.assertEqual(resumed["code"], "INSTALL_COMMITTED")

    def test_06_expected_hash_mismatch(self) -> None:
        project, _ = self.new_case("hash-mismatch")
        result = self.run_bootstrap(
            "inspect", "--zip", str(self.zip_path), "--target", str(project),
            "--expected-sha256", "0" * 64, expected=2,
        )
        self.assertEqual(result["code"], "PACKAGE_EXPECTED_HASH_MISMATCH")

    def test_07_malicious_zip_path_rejected(self) -> None:
        bad = self.root / "bad-path.zip"
        with zipfile.ZipFile(bad, "w") as archive:
            archive.writestr("../escape.txt", b"bad")
        project, _ = self.new_case("bad-path")
        result = self.run_bootstrap("inspect", "--zip", str(bad), "--target", str(project), expected=2)
        self.assertEqual(result["code"], "PACKAGE_UNSAFE_PATH")
        self.assertFalse((self.root / "escape.txt").exists())

    def test_08_plan_must_be_outside_project(self) -> None:
        project, _ = self.new_case("plan-boundary")
        result = self.run_bootstrap(
            "plan", "--zip", str(self.zip_path), "--target", str(project),
            "--output", str(project / "plan.json"), expected=2,
        )
        self.assertEqual(result["code"], "INSTALL_PLAN_INSIDE_PROJECT")

    def test_09_repeat_install_is_idempotent(self) -> None:
        project, work1 = self.new_case("repeat")
        plan1 = self.create_plan(project, work1)
        self.run_bootstrap("apply", "--plan", str(plan1))
        first_state = json.loads((project / ".ai" / "INSTALL_STATE.json").read_text(encoding="utf-8"))
        work2 = self.root / "repeat-work-2"
        work2.mkdir()
        plan2 = self.create_plan(project, work2)
        plan_data = json.loads(plan2.read_text(encoding="utf-8"))
        self.assertTrue(all(op["kind"] == "KEEP" for op in plan_data["operations"]))
        self.run_bootstrap("apply", "--plan", str(plan2))
        second_state = json.loads((project / ".ai" / "INSTALL_STATE.json").read_text(encoding="utf-8"))
        self.assertEqual(first_state["package"], second_state["package"])

    def test_10_existing_v6_payload_is_preserved(self) -> None:
        project, work = self.new_case("legacy-v6")
        shutil.copytree(self.package_root / "payload" / ".ai", project / ".ai")
        legacy_hash = hashlib.sha256((project / ".ai" / "AGENTS.md").read_bytes()).hexdigest()
        (project / "CLAUDE.md").write_text("# Existing Claude instructions\n", encoding="utf-8")
        plan = self.create_plan(project, work)
        data = json.loads(plan.read_text(encoding="utf-8"))
        self.assertFalse(data["conflicts"])
        self.assertTrue(data["legacy_package_verified"])
        self.run_bootstrap("apply", "--plan", str(plan))
        self.assertEqual(hashlib.sha256((project / ".ai" / "AGENTS.md").read_bytes()).hexdigest(), legacy_hash)
        self.assertTrue((project / "CLAUDE.md").read_text(encoding="utf-8").startswith("# Existing Claude instructions\n"))

    def test_11_plan_drift_is_rejected(self) -> None:
        project, work = self.new_case("plan-drift")
        plan = self.create_plan(project, work)
        (project / "AGENTS.md").write_text("created after plan\n", encoding="utf-8")
        result = self.run_bootstrap("apply", "--plan", str(plan), expected=2)
        self.assertEqual(result["code"], "INSTALL_PLAN_STALE")
        self.assertEqual((project / "AGENTS.md").read_text(encoding="utf-8"), "created after plan\n")

    def test_12_manifest_tamper_is_rejected(self) -> None:
        tampered = self.root / "tampered.zip"
        with zipfile.ZipFile(self.zip_path) as source, zipfile.ZipFile(tampered, "w", zipfile.ZIP_DEFLATED) as output:
            for info in source.infolist():
                data = source.read(info.filename)
                if info.filename == "PACKAGE.json":
                    data += b"\n"
                output.writestr(info.filename, data)
        project, _ = self.new_case("tampered")
        result = self.run_bootstrap("inspect", "--zip", str(tampered), "--target", str(project), expected=2)
        self.assertEqual(result["code"], "PACKAGE_MANIFEST_HASH_MISMATCH")

    def test_13_rollback_never_overwrites_external_change(self) -> None:
        project, work = self.new_case("rollback-conflict")
        plan = self.create_plan(project, work)
        self.run_bootstrap("apply", "--plan", str(plan))
        protected = project / ".ai" / "system" / "aic.py"
        install_state = project / ".ai" / "INSTALL_STATE.json"
        agents = project / "AGENTS.md"
        install_before = install_state.read_bytes()
        agents_before = agents.read_bytes()
        protected.write_text("external change after install\n", encoding="utf-8")
        tx = self.transaction_from(work)
        result = self.run_bootstrap("rollback", "--transaction", str(tx), expected=2)
        self.assertEqual(result["code"], "INSTALL_ROLLBACK_CONFLICT")
        self.assertFalse(result["details"]["project_files_changed"])
        self.assertEqual(protected.read_text(encoding="utf-8"), "external change after install\n")
        self.assertEqual(install_state.read_bytes(), install_before)
        self.assertEqual(agents.read_bytes(), agents_before)

    def test_14_casefold_duplicate_zip_path_rejected(self) -> None:
        bad = self.root / "bad-duplicate.zip"
        with zipfile.ZipFile(bad, "w") as archive:
            archive.writestr("File.txt", b"one")
            archive.writestr("file.txt", b"two")
        project, _ = self.new_case("bad-duplicate")
        result = self.run_bootstrap("inspect", "--zip", str(bad), "--target", str(project), expected=2)
        self.assertEqual(result["code"], "PACKAGE_DUPLICATE_PATH")

    def test_15_zip_symlink_rejected(self) -> None:
        bad = self.root / "bad-symlink.zip"
        info = zipfile.ZipInfo("link")
        info.create_system = 3
        info.external_attr = 0o120777 << 16
        with zipfile.ZipFile(bad, "w") as archive:
            archive.writestr(info, b"target")
        project, _ = self.new_case("bad-symlink")
        result = self.run_bootstrap("inspect", "--zip", str(bad), "--target", str(project), expected=2)
        self.assertEqual(result["code"], "PACKAGE_SPECIAL_FILE")

    def test_16_abnormal_compression_ratio_rejected(self) -> None:
        bad = self.root / "bad-ratio.zip"
        with zipfile.ZipFile(bad, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr("zeros.bin", b"0" * (2 * 1024 * 1024))
        project, _ = self.new_case("bad-ratio")
        result = self.run_bootstrap("inspect", "--zip", str(bad), "--target", str(project), expected=2)
        self.assertEqual(result["code"], "PACKAGE_COMPRESSION_RATIO_LIMIT")

    def test_17_target_symlink_boundary_when_supported(self) -> None:
        project, work = self.new_case("target-symlink")
        outside = self.root / "outside-target"
        outside.mkdir()
        try:
            os.symlink(outside, project / ".ai", target_is_directory=True)
        except (OSError, NotImplementedError):
            if os.name == "nt":
                junction = subprocess.run(
                    ["cmd", "/c", "mklink", "/J", str(project / ".ai"), str(outside)],
                    capture_output=True, text=True, encoding="utf-8", errors="replace",
                )
                if junction.returncode != 0:
                    self.skipTest("symlink and junction creation unavailable on this host")
            else:
                self.skipTest("symlink creation unavailable on this host")
        plan = work / "plan.json"
        result = self.run_bootstrap(
            "plan", "--zip", str(self.zip_path), "--target", str(project), "--output", str(plan),
            expected=2,
        )
        self.assertIn(result["code"], {"PATH_REPARSE_POINT", "PATH_ESCAPE"})
        self.assertEqual(list(outside.iterdir()), [])

    def test_18_trusted_managed_block_is_upgraded_and_user_content_preserved(self) -> None:
        project, work1 = self.new_case("trusted-entry-upgrade")
        user_text = "# User-owned preface\n\n"
        (project / "AGENTS.md").write_text(user_text, encoding="utf-8")
        self.run_bootstrap("apply", "--plan", str(self.create_plan(project, work1)))
        variant = self.create_variant_package("trusted-entry-variant", "upgraded")
        work2 = self.root / "trusted-entry-upgrade-work-2"
        work2.mkdir()
        plan2 = work2 / "plan.json"
        planned = self.run_bootstrap(
            "plan", "--zip", str(variant), "--target", str(project), "--output", str(plan2),
        )
        self.assertEqual(planned["code"], "PLAN_READY")
        data = json.loads(plan2.read_text(encoding="utf-8"))
        agents_op = next(item for item in data["operations"] if item["target"] == "AGENTS.md")
        self.assertEqual(agents_op["kind"], "REPLACE_TRUSTED_MANAGED_BLOCK")
        self.run_bootstrap("apply", "--plan", str(plan2))
        final = (project / "AGENTS.md").read_text(encoding="utf-8")
        self.assertTrue(final.startswith(user_text))
        self.assertIn("入口 upgraded", final)

    def test_19_modified_managed_block_still_blocks_upgrade(self) -> None:
        project, work1 = self.new_case("modified-entry-upgrade")
        self.run_bootstrap("apply", "--plan", str(self.create_plan(project, work1)))
        target = project / "AGENTS.md"
        target.write_text(target.read_text(encoding="utf-8").replace(
            "## AI 工程约束系统入口", "## AI 工程约束系统入口 manually-edited",
        ), encoding="utf-8")
        variant = self.create_variant_package("modified-entry-variant", "upgraded")
        work2 = self.root / "modified-entry-upgrade-work-2"
        work2.mkdir()
        plan2 = work2 / "plan.json"
        planned = self.run_bootstrap(
            "plan", "--zip", str(variant), "--target", str(project), "--output", str(plan2),
        )
        self.assertEqual(planned["code"], "PLAN_CREATED_WITH_CONFLICTS")
        self.assertTrue(any(
            item.get("target") == "AGENTS.md" and item.get("reason") == "ENTRYPOINT_MANAGED_BLOCK_MODIFIED"
            for item in planned["details"]["conflicts"]
        ))

    def test_20_installed_workflow_closes_and_resumes_completed_history(self) -> None:
        project, work = self.new_case("installed-workflow")
        self.run_bootstrap("apply", "--plan", str(self.create_plan(project, work)))
        initialized = self.run_aic(project, "state", "init", "--project-name", "workflow-test")
        self.assertEqual(initialized["code"], "STATE_INITIALIZED")
        begun = self.run_aic(
            project, "workflow", "begin", "--client", "integration-test",
            "--title", "verify installed workflow", "--goal", "finish and resume",
            "--acceptance", "real command evidence passes",
        )
        self.assertEqual(begun["code"], "WORKFLOW_BEGUN")
        session_id = begun["details"]["session"]["id"]
        task = begun["details"]["task"]
        task_id = task["id"]
        acceptance_id = task["acceptance_criteria"][0]["id"]
        self.assertEqual(begun["details"]["next_action"]["status"], "READY")
        executing = self.run_aic(
            project, "workflow", "advance", "--task-id", task_id, "--to", "EXECUTING",
            "--session-id", session_id,
        )
        self.assertEqual(executing["details"]["task"]["status"], "EXECUTING")
        checkpoint = self.run_aic(
            project, "workflow", "checkpoint", "--session-id", session_id,
            "--label", "implementation complete",
        )
        self.assertEqual(checkpoint["code"], "WORKFLOW_CHECKPOINT_CREATED")

        artifact = project / "workflow-evidence.txt"
        artifact.write_text("deterministic integration result\n", encoding="utf-8")
        context = self.run_aic(project, "state", "show")
        evidence = self.run_aic(
            project, "evidence", "add", "--task-id", task_id, "--type", "TEST",
            "--result", "PASS", "--artifact", "workflow-evidence.txt",
            "--session-id", session_id,
            "--expected-state-revision", str(context["details"]["current"]["state_revision"]),
            "--acceptance-id", acceptance_id, "--producer-kind", "COMMAND",
            "--command-arg", "integration-self-test", "--exit-code", "0",
            "--tool-name", "python-unittest", "--tool-version", "stdlib",
            "--result-basis", "process exited zero and artifact was captured",
        )
        self.assertEqual(evidence["details"]["output_mode"], "compact")
        self.assertNotIn("producer", evidence["details"]["evidence"])
        verifying = self.run_aic(
            project, "workflow", "advance", "--task-id", task_id, "--to", "VERIFYING",
            "--session-id", session_id,
            "--completed", "installed workflow exercised",
        )
        self.assertTrue(all(item["status"] == "DONE" for item in verifying["details"]["next_updates"]))
        finished = self.run_aic(
            project, "workflow", "finish", "--task-id", task_id, "--session-id", session_id,
            "--trigger", "integration acceptance",
        )
        self.assertEqual(finished["code"], "WORKFLOW_FINISHED")
        self.assertEqual(finished["details"]["task"]["status"], "COMPLETED")
        completion = finished["details"]["completion_summary"]
        self.assertEqual(completion["summary_type"], "COMPLETION")
        self.assertEqual(completion["status"], "VERIFIED")
        self.assertIn({"kind": "task-status", "value": "COMPLETED"}, completion["facts"])
        repeated = self.run_aic(
            project, "workflow", "finish", "--task-id", task_id, "--session-id", session_id,
            "--trigger", "idempotency acceptance",
        )
        self.assertEqual(repeated["code"], "WORKFLOW_FINISHED")
        self.assertTrue(repeated["details"]["already_completed"])
        self.assertEqual(repeated["details"]["completion_summary"]["id"], completion["id"])
        closed = self.run_aic(project, "workflow", "close-session", "--session-id", session_id)
        self.assertEqual(closed["code"], "WORKFLOW_SESSION_CLOSED")

        resumed = self.run_aic(project, "workflow", "resume", "--client", "integration-resume")
        self.assertEqual(resumed["code"], "WORKFLOW_RESUMED")
        self.assertEqual(resumed["details"]["output_mode"], "compact")
        recent_completed = resumed["details"]["snapshot"]["recent_closed_tasks"]
        self.assertTrue(any(item["id"] == task_id for item in recent_completed))
        self.assertNotIn("recent_evidence", resumed["details"]["snapshot"])
        self.assertEqual(resumed["details"]["snapshot"]["history_counts"]["evidence"], 1)
        self.assertLess(len(json.dumps(resumed, ensure_ascii=False)), 6000)
        resumed_session = resumed["details"]["session"]["id"]
        self.run_aic(project, "workflow", "close-session", "--session-id", resumed_session)

        full = self.run_aic(project, "workflow", "resume", "--client", "integration-full", "--full")
        self.assertEqual(full["details"]["output_mode"], "full")
        self.assertIn("recent_evidence", full["details"]["snapshot"])
        self.assertEqual(full["details"]["snapshot"]["recent_evidence"][0]["id"], evidence["details"]["evidence"]["id"])
        self.run_aic(project, "workflow", "close-session", "--session-id", full["details"]["session"]["id"])

        runtime = project / ".ai" / "system" / "rules" / "lifecycle-registry.json"
        runtime.write_text(runtime.read_text(encoding="utf-8") + "\n", encoding="utf-8")
        refused = self.run_aic(
            project, "workflow", "resume", "--client", "tampered-runtime", expected=2,
        )
        self.assertEqual(refused["code"], "PACKAGE_READ_ONLY_REQUIRED")

    def test_21_explicit_package_owned_repair_preserves_project_state(self) -> None:
        project, work1 = self.new_case("package-repair")
        self.run_bootstrap("apply", "--plan", str(self.create_plan(project, work1)))
        self.run_aic(project, "state", "init", "--project-name", "repair-state")
        head = project / ".ai" / "state" / "HEAD.json"
        head_before = head.read_bytes()
        runtime = project / ".ai" / "system" / "rules" / "lifecycle-registry.json"
        runtime.write_text(runtime.read_text(encoding="utf-8") + "\n", encoding="utf-8")

        work2 = self.root / "package-repair-normal-work"
        work2.mkdir()
        normal_plan = work2 / "plan.json"
        normal = self.run_bootstrap(
            "plan", "--zip", str(self.zip_path), "--target", str(project),
            "--output", str(normal_plan),
        )
        self.assertEqual(normal["code"], "PLAN_CREATED_WITH_CONFLICTS")

        work3 = self.root / "package-repair-explicit-work"
        work3.mkdir()
        repair_plan = work3 / "plan.json"
        repair = self.run_bootstrap(
            "plan", "--zip", str(self.zip_path), "--target", str(project),
            "--output", str(repair_plan), "--repair-package-owned",
        )
        self.assertEqual(repair["code"], "REPAIR_PLAN_READY")
        plan_data = json.loads(repair_plan.read_text(encoding="utf-8"))
        repaired = [item for item in plan_data["operations"] if item["kind"] == "REPAIR_PACKAGE_OWNED"]
        self.assertEqual([item["target"] for item in repaired], [".ai/system/rules/lifecycle-registry.json"])
        self.run_bootstrap("apply", "--plan", str(repair_plan))
        status = self.run_aic(project, "status", "--verify")
        self.assertEqual(status["code"], "STATUS_OK")
        self.assertEqual(head.read_bytes(), head_before)

    def test_22_begin_can_reuse_resumed_session_and_returns_concrete_next(self) -> None:
        project, work = self.new_case("reuse-session")
        self.run_bootstrap("apply", "--plan", str(self.create_plan(project, work)))
        self.run_aic(project, "state", "init", "--project-name", "reuse-session")
        resumed = self.run_aic(project, "workflow", "resume", "--client", "integration")
        session_id = resumed["details"]["session"]["id"]
        begun = self.run_aic(
            project, "workflow", "begin", "--client", "integration", "--session-id", session_id,
            "--title", "reuse existing session", "--goal", "avoid leaked sessions",
            "--acceptance", "one active session", "--next-action", "inspect the real project",
        )
        self.assertTrue(begun["details"]["reused_session"])
        self.assertEqual(begun["details"]["session"]["id"], session_id)
        self.assertEqual(begun["details"]["next_action"]["action"], "inspect the real project")
        context = self.run_aic(project, "state", "show")
        self.assertEqual(context["details"]["current"]["active_sessions"], [session_id])
        snapshot = self.run_aic(project, "session", "resume", "--client", "second-reader")
        recommendation = snapshot["details"]["snapshot"]["recommendation"]
        self.assertEqual(recommendation["kind"], "NEXT_ACTION")
        self.assertIn("workflow advance", recommendation["recommended_command"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
