# AI 工程约束系统统一入口

本文件是安装后各 AI 客户端的统一薄入口。

## 会话启动

1. 从项目根目录运行 `python .ai/system/aic.py status --json`，核对安装状态和包完整性。
2. 若状态中心尚未初始化，运行 `python .ai/system/aic.py state init --project-name "<项目名>" --json`；不得直接创建或编辑状态文件。
3. 运行 `python .ai/system/aic.py session start --client "<客户端>" --json`，保存会话 ID 和启动时读取的状态修订号。
4. 运行 `python .ai/system/aic.py state show --json`，以其中的活动任务和推荐下一步作为续做依据；不得用聊天记忆覆盖结构化状态。
5. 修改任务或文件范围前运行 `lock acquire`；长任务定期执行 `session heartbeat` 和 `lock renew`。重叠或过期锁必须停止写入。
6. 读取 `.ai/AGENTS.md`、`.ai/AI-INSTRUCTIONS.md` 和 `.ai/.ai-engineering/RULES_INDEX.md`，继续使用已保留的 V6 规则与专业规范。
7. 修改前检查 Git 和用户已有改动。状态写入必须使用统一命令并携带刚读取的修订；冲突后重新读取，禁止直接覆盖。
8. 使用 `evidence add` 保存真实测试或产物证据；使用 `task transition` 更新任务，不得绕过完成门禁。
9. 重要节点生成并核验总结；结束前释放锁、结束会话，运行 `state verify`、`doctor diagnose` 和 `view render`。
10. Doctor 报告 Git 基线漂移时重新核验证据和总结；不得继续使用旧结论。

## 当前能力边界

这是 `7.0.0` 正式运行包，已经实现安全安装和升级、统一状态和研发闭环、本机并发与恢复、版本化适配器、受预算项目识别以及从最终 ZIP 创建维护工作区、执行回归和确定性重打包。

锁只协调同一工作副本；不同计算机和仓库副本通过 Git、状态修订或外部协调发现冲突。事件链或已提交事务损坏时强制只读，禁止自动重写权威历史。持续后台监视由外部调度提供，本工具使用每次会话启动和节点结束时的显式校准。

不得把未运行的测试、未核验的证据或未执行的维护步骤描述为已完成。
