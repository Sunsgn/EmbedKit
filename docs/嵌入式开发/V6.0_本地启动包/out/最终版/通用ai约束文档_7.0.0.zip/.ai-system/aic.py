#!/usr/bin/env python3
"""Installed AI constraint system entry point."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Any

sys.dont_write_bytecode = True

from state_core import StateError, StateStore, error_result, success
from lifecycle import (
    add_evidence,
    generate_summary,
    invalidate_evidence,
    list_rules,
    transition_task,
    update_next,
    verify_evidence,
    verify_summary,
)
from concurrency import ConcurrencyManager
from doctor import apply_repair_plan, create_repair_plan, diagnose
from project_scan import adapter_list, inspect_project, workflow_profile
from maintenance_runtime import prepare_workspace, repack_workspace, test_workspace


def configure_stdio() -> None:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def result(ok: bool, code: str, message: str, **details: Any) -> dict[str, Any]:
    return {
        "ok": ok,
        "code": code,
        "message": message,
        "retryable": False,
        "requires_user_action": not ok,
        "details": details,
    }


def emit(data: dict[str, Any], as_json: bool) -> int:
    if as_json:
        print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(("PASS" if data["ok"] else "FAIL") + f" [{data['code']}] {data['message']}")
        if data.get("details"):
            print(json.dumps(data["details"], ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if data["ok"] else 2


def project_root() -> Path:
    # Installed path: <project>/.ai/system/aic.py
    return Path(__file__).resolve().parents[2]


def load_install_state(root: Path) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    state_path = root / ".ai" / "INSTALL_STATE.json"
    if not state_path.is_file():
        return None, result(False, "INSTALL_STATE_MISSING", "安装状态不存在", path=str(state_path))
    try:
        data = json.loads(state_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return None, result(False, "INSTALL_STATE_INVALID", "安装状态无法读取", error=str(exc))
    if data.get("schema") != "aic.install-state" or data.get("schema_version") != "1.0.0":
        return None, result(False, "INSTALL_STATE_SCHEMA_UNSUPPORTED", "安装状态格式不兼容")
    return data, None


def verify_installed(root: Path, state: dict[str, Any]) -> dict[str, Any]:
    errors: list[dict[str, Any]] = []
    checked = 0
    for entry in state.get("package_files", []):
        rel = entry.get("target")
        expected = entry.get("sha256")
        if not isinstance(rel, str) or not isinstance(expected, str):
            errors.append({"code": "INSTALL_STATE_FILE_ENTRY_INVALID", "entry": entry})
            continue
        path = (root / Path(rel)).resolve(strict=False)
        if not path.is_relative_to(root.resolve()):
            errors.append({"code": "PATH_ESCAPE", "target": rel})
            continue
        if not path.is_file():
            errors.append({"code": "PACKAGE_FILE_MISSING", "target": rel})
            continue
        actual = digest(path)
        checked += 1
        if actual != expected:
            errors.append({"code": "PACKAGE_FILE_HASH_MISMATCH", "target": rel, "expected": expected, "actual": actual})
    for entry in state.get("managed_entrypoints", []):
        rel = entry.get("target")
        expected = entry.get("managed_block_sha256")
        if not isinstance(rel, str) or not isinstance(expected, str):
            errors.append({"code": "INSTALL_STATE_ENTRYPOINT_INVALID", "entry": entry})
            continue
        path = (root / Path(rel)).resolve(strict=False)
        if not path.is_relative_to(root.resolve()) or not path.is_file():
            errors.append({"code": "MANAGED_ENTRYPOINT_MISSING", "target": rel})
            continue
        data = path.read_bytes()
        begin = data.find(b"<!-- AI-CONSTRAINTS:BEGIN managed")
        end_marker = b"<!-- AI-CONSTRAINTS:END managed -->"
        end = data.find(end_marker, begin)
        if begin < 0 or end < 0:
            errors.append({"code": "MANAGED_ENTRYPOINT_BLOCK_MISSING", "target": rel})
            continue
        block = data[begin:end + len(end_marker)]
        if hashlib.sha256(block).hexdigest() != expected:
            errors.append({"code": "MANAGED_ENTRYPOINT_BLOCK_CHANGED", "target": rel})
    if errors:
        return result(False, "PACKAGE_VERIFY_FAILED", "安装后包文件校验失败", checked=checked, errors=errors)
    return result(True, "PACKAGE_VERIFY_OK", "安装后包文件校验通过", checked=checked)


def git_snapshot(root: Path) -> dict[str, Any]:
    try:
        probe = subprocess.run(
            ["git", "-C", str(root), "status", "--short", "--branch"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=8,
            shell=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"available": False, "error": str(exc)}
    return {
        "available": probe.returncode == 0,
        "exit_code": probe.returncode,
        "status": probe.stdout.splitlines()[:200],
        "error": probe.stderr.strip() or None,
    }


def status_command(root: Path, verify: bool) -> dict[str, Any]:
    state, error = load_install_state(root)
    if error:
        return error
    assert state is not None
    verification = verify_installed(root, state) if verify else None
    legacy = {
        "agents": (root / ".ai" / "AGENTS.md").is_file(),
        "instructions": (root / ".ai" / "AI-INSTRUCTIONS.md").is_file(),
        "rules_index": (root / ".ai" / ".ai-engineering" / "RULES_INDEX.md").is_file(),
        "project_profile": (root / ".ai" / "PROJECT_PROFILE.md").is_file(),
        "storage_map": (root / ".ai" / "COGNITION_STORAGE_MAP.json").is_file(),
    }
    ok = state.get("status") == "INSTALLED" and (verification is None or verification["ok"])
    return result(
        ok,
        "STATUS_OK" if ok else "STATUS_DEGRADED",
        "约束系统状态可用" if ok else "约束系统需要检查",
        project_root=str(root),
        install_status=state.get("status"),
        package=state.get("package"),
        installed_at=state.get("installed_at"),
        package_verification=verification,
        legacy_runtime=legacy,
        phase="release-7.0.0",
        not_implemented=[
            "cross-machine-strong-locks-use-git-or-external-coordination",
            "authoritative-history-auto-rewrite-requires-manual-recovery",
            "continuous-background-environment-watchers-use-explicit-verify",
        ],
        git=git_snapshot(root),
    )


def state_command(args: argparse.Namespace, root: Path) -> dict[str, Any]:
    store = StateStore(root)
    try:
        if args.command == "state":
            if args.state_command == "init":
                value = store.initialize(args.project_name, args.project_id)
                return success("STATE_INITIALIZED" if value["created"] else "STATE_ALREADY_INITIALIZED", "统一状态中心已初始化" if value["created"] else "统一状态中心已经存在", **value)
            if args.state_command == "show":
                return success("STATE_CONTEXT_READY", "当前任务和下一步已恢复", **store.context())
            if args.state_command == "verify":
                value = store.verify()
                if not value["healthy"]:
                    return result(False, "STATE_VERIFY_FAILED", "状态中心校验失败", **value)
                return success("STATE_VERIFY_OK", "状态事件链和派生状态校验通过", **value)
            if args.state_command == "rebuild":
                return success("STATE_REBUILT", "派生状态已从权威记录重建", **store.rebuild())
        if args.command == "session":
            if args.session_command == "start":
                return success("SESSION_STARTED", "会话启动回执已生成", **store.start_session(args.client))
            manager = ConcurrencyManager(store)
            if args.session_command == "heartbeat":
                return success("SESSION_HEARTBEAT_OK", "会话心跳和租约已更新", **manager.heartbeat(args.session_id, args.ttl_seconds))
            if args.session_command == "end":
                return success("SESSION_ENDED", "会话已结束", **manager.end_session(args.session_id))
        if args.command == "lock":
            manager = ConcurrencyManager(store)
            if args.lock_command == "acquire":
                return success("LOCK_ACQUIRED", "范围锁已获取", **manager.acquire(args.session_id, args.scope, args.lease_seconds))
            if args.lock_command == "renew":
                return success("LOCK_RENEWED", "范围锁租约已续期", **manager.renew(args.id, args.session_id, args.lease_seconds))
            if args.lock_command == "release":
                return success("LOCK_RELEASED", "范围锁已释放", **manager.release(args.id, args.session_id))
            if args.lock_command == "recover-expired":
                return success("LOCK_RECOVERED", "过期锁已完成受控恢复", **manager.recover_expired(args.id, args.session_id, args.acknowledge_reviewed))
        if args.command == "doctor":
            if args.doctor_command == "diagnose":
                value = diagnose(store)
                if value["read_only_required"]:
                    return result(False, "DOCTOR_READ_ONLY_REQUIRED", "发现权威历史或锁重叠问题，必须保持只读", **value)
                return success("DOCTOR_DIAGNOSIS_READY", "健康诊断完成", **value)
            if args.doctor_command == "repair-plan":
                return success("DOCTOR_REPAIR_PLAN_READY", "候选修复计划已生成", **create_repair_plan(store))
            if args.doctor_command == "apply":
                return success("DOCTOR_REPAIR_APPLIED", "修复计划已应用并复检", **apply_repair_plan(store, args.plan, args.session_id, args.acknowledge))
        if args.command == "task":
            if args.task_command == "create":
                value = store.create_task(args.title, args.goal, args.expected_state_revision, args.session_id, args.acceptance, args.level, args.level_reason)
                return success("TASK_CREATED", "任务已通过状态事务创建", **value)
            if args.task_command == "transition":
                ConcurrencyManager(store).assert_write_allowed(args.session_id, [f"task:{args.id}"])
                value = transition_task(
                    store, args.id, args.to, args.expected_entity_revision,
                    args.expected_state_revision, args.session_id, args.completed,
                    args.remaining, args.blocker, args.resolved_blocker, args.failed_attempt, args.unknown,
                    args.resume_condition, args.resolution_condition,
                )
                return success("TASK_TRANSITIONED", "任务状态已按注册表和门禁更新", **value)
        if args.command == "next":
            if args.next_command == "create":
                ConcurrencyManager(store).assert_write_allowed(args.session_id, [f"task:{args.task_id}"])
                value = store.create_next(args.task_id, args.action, args.priority, args.expected_state_revision, args.session_id, args.acceptance, args.requires_user_decision)
                return success("NEXT_ACTION_CREATED", "可执行下一步已创建并关联任务", **value)
            if args.next_command == "transition":
                next_entity = store._load_entity("next_action", args.id)
                if next_entity is None:
                    raise StateError("NEXT_ACTION_NOT_FOUND", "下一步不存在", next_action_id=args.id)
                ConcurrencyManager(store).assert_write_allowed(args.session_id, [f"task:{next_entity['task_id']}"])
                value = update_next(store, args.id, args.to, args.expected_entity_revision, args.expected_state_revision, args.session_id)
                return success("NEXT_ACTION_TRANSITIONED", "下一步状态已按注册表更新", **value)
        if args.command == "evidence":
            if args.evidence_command == "add":
                ConcurrencyManager(store).assert_write_allowed(args.session_id, [f"task:{args.task_id}"])
                value = add_evidence(store, args.task_id, args.type, args.result, args.artifact, args.expected_state_revision, args.session_id, args.limitation)
                return success("EVIDENCE_CAPTURED", "证据已校验、哈希并关联任务", **value)
            if args.evidence_command == "verify":
                evidence_entity = store._load_entity("evidence", args.id)
                if evidence_entity is None:
                    raise StateError("EVIDENCE_NOT_FOUND", "证据不存在", evidence_id=args.id)
                task_scopes = [f"task:{item}" for item in evidence_entity.get("input_refs", []) if str(item).startswith("TASK-")]
                ConcurrencyManager(store).assert_write_allowed(args.session_id, task_scopes)
                value = verify_evidence(store, args.id, args.expected_state_revision, args.expected_entity_revision, args.session_id)
                return success("EVIDENCE_VERIFIED", "证据文件已重新核验", **value)
            if args.evidence_command == "invalidate":
                evidence_entity = store._load_entity("evidence", args.id)
                if evidence_entity is None:
                    raise StateError("EVIDENCE_NOT_FOUND", "证据不存在", evidence_id=args.id)
                task_scopes = [f"task:{item}" for item in evidence_entity.get("input_refs", []) if str(item).startswith("TASK-")]
                ConcurrencyManager(store).assert_write_allowed(args.session_id, task_scopes)
                value = invalidate_evidence(store, args.id, args.reason, args.expected_state_revision, args.expected_entity_revision, args.session_id)
                return success("EVIDENCE_INVALIDATED", "证据已保留并标记过期", **value)
        if args.command == "summary":
            if args.summary_command == "generate":
                ConcurrencyManager(store).assert_write_allowed(args.session_id, [f"task:{args.task_id}"])
                value = generate_summary(store, args.task_id, args.type, args.trigger, args.expected_state_revision, args.session_id)
                return success("SUMMARY_GENERATED" if value.get("created") else "SUMMARY_DUPLICATE", "研发节点总结已生成" if value.get("created") else "同一节点总结已经存在", **value)
            if args.summary_command == "verify":
                summary_entity = store._load_entity("summary", args.id)
                if summary_entity is None:
                    raise StateError("SUMMARY_NOT_FOUND", "总结不存在", summary_id=args.id)
                ConcurrencyManager(store).assert_write_allowed(args.session_id, [f"task:{summary_entity['task_id']}"])
                value = verify_summary(store, args.id, args.expected_entity_revision, args.expected_state_revision, args.session_id)
                return success("SUMMARY_VERIFIED", "研发节点总结已验证", **value)
        if args.command == "rules" and args.rules_command == "list":
            return success("RULE_REGISTRY_READY", "生命周期规则注册表可用", **list_rules())
        if args.command == "adapters" and args.adapters_command == "list":
            return success("ADAPTER_REGISTRY_READY", "项目和客户端适配器注册表可用", **adapter_list())
        if args.command == "workflow" and args.workflow_command == "profile":
            return success("WORKFLOW_PROFILE_READY", "流程等级预算和门禁可用", **workflow_profile(args.level))
        if args.command == "project" and args.project_command == "inspect":
            value = inspect_project(store, args.profile, args.max_files, args.max_bytes, args.timeout_seconds, args.cancel_file)
            code = "PROJECT_SCAN_COMPLETE" if value["complete"] else "PROJECT_SCAN_PARTIAL"
            return success(code, "项目识别完成" if value["complete"] else "项目识别按预算安全停止", **value)
        if args.command == "maintenance":
            if args.maintenance_command == "prepare":
                value = prepare_workspace(root, args.zip, args.workspace, args.expected_sha256)
                return success("MAINTENANCE_WORKSPACE_READY", "最终 ZIP 已安全展开到项目外维护工作区", **value)
            if args.maintenance_command == "test":
                value = test_workspace(root, args.workspace, args.pattern)
                return success("MAINTENANCE_TESTS_PASSED", "维护工作区回归测试通过", **value)
            if args.maintenance_command == "repack":
                value = repack_workspace(root, args.workspace, args.output, args.test_report)
                return success("MAINTENANCE_REPACKED", "维护工作区已确定性重打包并验证", **value)
        if args.command == "view":
            if args.view_command == "render":
                return success("VIEW_RENDERED", "当前状态视图已生成", **store.render_view())
            if args.view_command == "check":
                value = store.check_views()
                if not value["valid"]:
                    return result(False, "VIEW_MODIFIED", "生成视图存在人工修改或缺失", **value)
                return success("VIEW_CHECK_OK", "生成视图校验通过", **value)
        if args.command == "legacy":
            if args.legacy_command == "scan":
                return success("LEGACY_SCAN_READY", "旧 Markdown/CSV 扫描完成", **store.scan_legacy())
            if args.legacy_command == "import":
                value = store.import_legacy(args.expected_state_revision, args.session_id)
                return success("LEGACY_REFERENCES_IMPORTED", "旧资料已作为带哈希引用导入", **value)
    except StateError as exc:
        return error_result(exc)
    return result(False, "INPUT_UNSUPPORTED_COMMAND", "不支持的状态命令")


def main() -> int:
    configure_stdio()
    parser = argparse.ArgumentParser(description="AI engineering constraint system")
    parser.add_argument("--json", action="store_true", help="emit structured JSON")
    sub = parser.add_subparsers(dest="command", required=True)
    status = sub.add_parser("status", help="show installed status")
    status.add_argument("--verify", action="store_true", help="verify package-owned file hashes")
    status.add_argument("--json", action="store_true")
    package = sub.add_parser("package", help="package operations")
    package_sub = package.add_subparsers(dest="package_command", required=True)
    verify = package_sub.add_parser("verify", help="verify installed package files")
    verify.add_argument("--json", action="store_true")
    reconcile = sub.add_parser("reconcile", help="read-only phase-1 reconciliation")
    reconcile.add_argument("--json", action="store_true")

    state = sub.add_parser("state", help="unified structured state")
    state_sub = state.add_subparsers(dest="state_command", required=True)
    state_init = state_sub.add_parser("init", help="initialize state kernel")
    state_init.add_argument("--project-name", required=True)
    state_init.add_argument("--project-id")
    state_init.add_argument("--json", action="store_true")
    for name in ("show", "verify", "rebuild"):
        state_leaf = state_sub.add_parser(name)
        state_leaf.add_argument("--json", action="store_true")

    session = sub.add_parser("session", help="local session receipts")
    session_sub = session.add_subparsers(dest="session_command", required=True)
    session_start = session_sub.add_parser("start")
    session_start.add_argument("--client", required=True)
    session_start.add_argument("--json", action="store_true")
    session_heartbeat = session_sub.add_parser("heartbeat")
    session_heartbeat.add_argument("--session-id", required=True)
    session_heartbeat.add_argument("--ttl-seconds", type=int, default=300)
    session_heartbeat.add_argument("--json", action="store_true")
    session_end = session_sub.add_parser("end")
    session_end.add_argument("--session-id", required=True)
    session_end.add_argument("--json", action="store_true")

    lock = sub.add_parser("lock", help="local scope locks and leases")
    lock_sub = lock.add_subparsers(dest="lock_command", required=True)
    lock_acquire = lock_sub.add_parser("acquire")
    lock_acquire.add_argument("--session-id", required=True)
    lock_acquire.add_argument("--scope", action="append", required=True)
    lock_acquire.add_argument("--lease-seconds", type=int, default=300)
    lock_acquire.add_argument("--json", action="store_true")
    lock_renew = lock_sub.add_parser("renew")
    lock_renew.add_argument("--id", required=True)
    lock_renew.add_argument("--session-id", required=True)
    lock_renew.add_argument("--lease-seconds", type=int, default=300)
    lock_renew.add_argument("--json", action="store_true")
    lock_release = lock_sub.add_parser("release")
    lock_release.add_argument("--id", required=True)
    lock_release.add_argument("--session-id", required=True)
    lock_release.add_argument("--json", action="store_true")
    lock_recover = lock_sub.add_parser("recover-expired")
    lock_recover.add_argument("--id", required=True)
    lock_recover.add_argument("--session-id", required=True)
    lock_recover.add_argument("--acknowledge-reviewed", action="store_true")
    lock_recover.add_argument("--json", action="store_true")

    doctor = sub.add_parser("doctor", help="health diagnosis and conservative repair")
    doctor_sub = doctor.add_subparsers(dest="doctor_command", required=True)
    doctor_diagnose = doctor_sub.add_parser("diagnose")
    doctor_diagnose.add_argument("--json", action="store_true")
    doctor_plan = doctor_sub.add_parser("repair-plan")
    doctor_plan.add_argument("--json", action="store_true")
    doctor_apply = doctor_sub.add_parser("apply")
    doctor_apply.add_argument("--plan", required=True)
    doctor_apply.add_argument("--session-id", required=True)
    doctor_apply.add_argument("--acknowledge", action="store_true")
    doctor_apply.add_argument("--json", action="store_true")

    task = sub.add_parser("task", help="task state operations")
    task_sub = task.add_subparsers(dest="task_command", required=True)
    task_create = task_sub.add_parser("create")
    task_create.add_argument("--title", required=True)
    task_create.add_argument("--goal", required=True)
    task_create.add_argument("--session-id", required=True)
    task_create.add_argument("--expected-state-revision", required=True, type=int)
    task_create.add_argument("--acceptance", action="append", default=[])
    task_create.add_argument("--level", choices=["LIGHT", "STANDARD", "FULL"], default="STANDARD")
    task_create.add_argument("--level-reason", default="default")
    task_create.add_argument("--json", action="store_true")
    task_transition = task_sub.add_parser("transition")
    task_transition.add_argument("--id", required=True)
    task_transition.add_argument("--to", required=True)
    task_transition.add_argument("--session-id", required=True)
    task_transition.add_argument("--expected-state-revision", required=True, type=int)
    task_transition.add_argument("--expected-entity-revision", required=True, type=int)
    task_transition.add_argument("--completed", action="append", default=[])
    task_transition.add_argument("--remaining", action="append", default=[])
    task_transition.add_argument("--blocker", action="append", default=[])
    task_transition.add_argument("--resolved-blocker", action="append", default=[])
    task_transition.add_argument("--failed-attempt", action="append", default=[])
    task_transition.add_argument("--unknown", action="append", default=[])
    task_transition.add_argument("--resume-condition")
    task_transition.add_argument("--resolution-condition")
    task_transition.add_argument("--json", action="store_true")

    next_parser = sub.add_parser("next", help="next-action operations")
    next_sub = next_parser.add_subparsers(dest="next_command", required=True)
    next_create = next_sub.add_parser("create")
    next_create.add_argument("--task-id", required=True)
    next_create.add_argument("--action", required=True)
    next_create.add_argument("--priority", type=int, default=1)
    next_create.add_argument("--session-id", required=True)
    next_create.add_argument("--expected-state-revision", required=True, type=int)
    next_create.add_argument("--acceptance", action="append", default=[])
    next_create.add_argument("--requires-user-decision", action="store_true")
    next_create.add_argument("--json", action="store_true")
    next_transition = next_sub.add_parser("transition")
    next_transition.add_argument("--id", required=True)
    next_transition.add_argument("--to", required=True)
    next_transition.add_argument("--session-id", required=True)
    next_transition.add_argument("--expected-state-revision", required=True, type=int)
    next_transition.add_argument("--expected-entity-revision", required=True, type=int)
    next_transition.add_argument("--json", action="store_true")

    evidence = sub.add_parser("evidence", help="evidence capture and validity")
    evidence_sub = evidence.add_subparsers(dest="evidence_command", required=True)
    evidence_add = evidence_sub.add_parser("add")
    evidence_add.add_argument("--task-id", required=True)
    evidence_add.add_argument("--type", required=True)
    evidence_add.add_argument("--result", required=True)
    evidence_add.add_argument("--artifact", required=True)
    evidence_add.add_argument("--session-id", required=True)
    evidence_add.add_argument("--expected-state-revision", required=True, type=int)
    evidence_add.add_argument("--limitation", action="append", default=[])
    evidence_add.add_argument("--json", action="store_true")
    for name in ("verify", "invalidate"):
        leaf = evidence_sub.add_parser(name)
        leaf.add_argument("--id", required=True)
        leaf.add_argument("--session-id", required=True)
        leaf.add_argument("--expected-state-revision", required=True, type=int)
        leaf.add_argument("--expected-entity-revision", required=True, type=int)
        if name == "invalidate":
            leaf.add_argument("--reason", required=True)
        leaf.add_argument("--json", action="store_true")

    summary = sub.add_parser("summary", help="engineering node summaries")
    summary_sub = summary.add_subparsers(dest="summary_command", required=True)
    summary_generate = summary_sub.add_parser("generate")
    summary_generate.add_argument("--task-id", required=True)
    summary_generate.add_argument("--type", required=True)
    summary_generate.add_argument("--trigger", required=True)
    summary_generate.add_argument("--session-id", required=True)
    summary_generate.add_argument("--expected-state-revision", required=True, type=int)
    summary_generate.add_argument("--json", action="store_true")
    summary_verify = summary_sub.add_parser("verify")
    summary_verify.add_argument("--id", required=True)
    summary_verify.add_argument("--session-id", required=True)
    summary_verify.add_argument("--expected-state-revision", required=True, type=int)
    summary_verify.add_argument("--expected-entity-revision", required=True, type=int)
    summary_verify.add_argument("--json", action="store_true")

    rules = sub.add_parser("rules", help="registered deterministic rules")
    rules_sub = rules.add_subparsers(dest="rules_command", required=True)
    rules_list = rules_sub.add_parser("list")
    rules_list.add_argument("--json", action="store_true")

    adapters = sub.add_parser("adapters", help="versioned project and client adapters")
    adapters_sub = adapters.add_subparsers(dest="adapters_command", required=True)
    adapters_list_parser = adapters_sub.add_parser("list")
    adapters_list_parser.add_argument("--json", action="store_true")

    workflow = sub.add_parser("workflow", help="LIGHT/STANDARD/FULL budgets")
    workflow_sub = workflow.add_subparsers(dest="workflow_command", required=True)
    workflow_profile_parser = workflow_sub.add_parser("profile")
    workflow_profile_parser.add_argument("--level", choices=["LIGHT", "STANDARD", "FULL"], required=True)
    workflow_profile_parser.add_argument("--json", action="store_true")

    project = sub.add_parser("project", help="budgeted project inspection")
    project_sub = project.add_subparsers(dest="project_command", required=True)
    project_inspect = project_sub.add_parser("inspect")
    project_inspect.add_argument("--profile", choices=["LIGHT", "STANDARD", "FULL"], default="STANDARD")
    project_inspect.add_argument("--max-files", type=int)
    project_inspect.add_argument("--max-bytes", type=int)
    project_inspect.add_argument("--timeout-seconds", type=int)
    project_inspect.add_argument("--cancel-file")
    project_inspect.add_argument("--json", action="store_true")

    maintenance = sub.add_parser("maintenance", help="safe final-ZIP self-maintenance")
    maintenance_sub = maintenance.add_subparsers(dest="maintenance_command", required=True)
    maintenance_prepare = maintenance_sub.add_parser("prepare")
    maintenance_prepare.add_argument("--zip", required=True)
    maintenance_prepare.add_argument("--workspace", required=True)
    maintenance_prepare.add_argument("--expected-sha256", required=True)
    maintenance_prepare.add_argument("--json", action="store_true")
    maintenance_test = maintenance_sub.add_parser("test")
    maintenance_test.add_argument("--workspace", required=True)
    maintenance_test.add_argument("--pattern", default="test_*.py")
    maintenance_test.add_argument("--json", action="store_true")
    maintenance_repack = maintenance_sub.add_parser("repack")
    maintenance_repack.add_argument("--workspace", required=True)
    maintenance_repack.add_argument("--output", required=True)
    maintenance_repack.add_argument("--test-report", required=True)
    maintenance_repack.add_argument("--json", action="store_true")

    view = sub.add_parser("view", help="derived Markdown views")
    view_sub = view.add_subparsers(dest="view_command", required=True)
    for name in ("render", "check"):
        view_leaf = view_sub.add_parser(name)
        view_leaf.add_argument("--json", action="store_true")

    legacy = sub.add_parser("legacy", help="legacy Markdown/CSV migration")
    legacy_sub = legacy.add_subparsers(dest="legacy_command", required=True)
    legacy_scan = legacy_sub.add_parser("scan")
    legacy_scan.add_argument("--json", action="store_true")
    legacy_import = legacy_sub.add_parser("import")
    legacy_import.add_argument("--session-id", required=True)
    legacy_import.add_argument("--expected-state-revision", required=True, type=int)
    legacy_import.add_argument("--json", action="store_true")
    args = parser.parse_args()
    as_json = bool(getattr(args, "json", False))
    root = project_root()
    if args.command in {"status", "reconcile"}:
        return emit(status_command(root, verify=args.command == "reconcile" or args.verify), as_json)
    if args.command == "package" and args.package_command == "verify":
        state, error = load_install_state(root)
        return emit(error or verify_installed(root, state or {}), as_json)
    if args.command in {"state", "session", "lock", "doctor", "task", "next", "evidence", "summary", "rules", "adapters", "workflow", "project", "maintenance", "view", "legacy"}:
        return emit(state_command(args, root), as_json)
    return emit(result(False, "INPUT_UNSUPPORTED_COMMAND", "不支持的命令"), as_json)


if __name__ == "__main__":
    raise SystemExit(main())
