#!/usr/bin/env python3
"""Safe final-ZIP maintenance workspace, tests and deterministic repack."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile
from typing import Any

try:
    import bootstrap
except ModuleNotFoundError:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    import bootstrap
from state_core import StateError, atomic_write, pretty_bytes, utc_now


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _outside_project(project_root: Path, path: Path, label: str) -> None:
    project = project_root.resolve()
    resolved = path.resolve(strict=False)
    if resolved == project or resolved.is_relative_to(project):
        raise StateError("PATH_MAINTENANCE_INSIDE_PROJECT", f"{label} 必须位于项目根之外", path=str(resolved))


def prepare_workspace(project_root: Path, zip_path: str, workspace: str, expected_sha256: str) -> dict[str, Any]:
    source = Path(zip_path).resolve(strict=False)
    target = Path(workspace).resolve(strict=False)
    _outside_project(project_root, target, "维护工作区")
    if not source.is_file():
        raise StateError("PACKAGE_FILE_MISSING", "维护源 ZIP 不存在", path=str(source))
    actual = sha256_file(source)
    if actual.lower() != expected_sha256.lower():
        raise StateError("PACKAGE_HASH_MISMATCH", "维护源 ZIP 哈希不匹配", expected=expected_sha256, actual=actual)
    try:
        verified = bootstrap.verify_package(source)
    except bootstrap.AICError as exc:
        raise StateError(exc.code, exc.message, **exc.details) from exc
    if target.exists() and any(target.iterdir()):
        raise StateError("PATH_MAINTENANCE_WORKSPACE_NOT_EMPTY", "维护工作区必须不存在或为空", path=str(target))
    target.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(source) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            destination = (target / Path(info.filename)).resolve(strict=False)
            if not destination.is_relative_to(target):
                raise StateError("PACKAGE_PATH_ESCAPE", "ZIP 成员逃逸维护工作区", member=info.filename)
            atomic_write(destination, archive.read(info))
    metadata = {
        "schema": "aic.maintenance-workspace", "schema_version": "1.0.0",
        "source_zip": str(source), "source_sha256": actual,
        "workspace": str(target), "package_id": verified["package"]["package_id"],
        "package_version": verified["package"]["package_version"], "prepared_at": utc_now(),
    }
    metadata_path = target.parent / f".{target.name}.aic-maintenance.json"
    atomic_write(metadata_path, pretty_bytes(metadata))
    return {"workspace": str(target), "metadata": str(metadata_path), "source_sha256": actual, "package": verified["package"]}


def test_workspace(project_root: Path, workspace: str, pattern: str = "test_*.py") -> dict[str, Any]:
    root = Path(workspace).resolve(strict=False)
    _outside_project(project_root, root, "维护工作区")
    tests = root / ".ai-system" / "tests"
    if not tests.is_dir() or not (root / "PACKAGE.json").is_file():
        raise StateError("MAINTENANCE_WORKSPACE_INVALID", "维护工作区缺少包结构", workspace=str(root))
    if "/" in pattern or "\\" in pattern or ".." in pattern:
        raise StateError("INPUT_TEST_PATTERN_INVALID", "测试匹配模式只能是文件名模式", pattern=pattern)
    try:
        environment = os.environ.copy()
        environment["AIC_MAINTENANCE_NESTED"] = "1"
        process = subprocess.run(
            [sys.executable, "-m", "unittest", "discover", "-s", str(tests), "-p", pattern, "-v"],
            cwd=str(root), capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=600, shell=False, env=environment,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise StateError("TOOL_MAINTENANCE_TEST_FAILED", "维护测试无法完成", error=str(exc)) from exc
    report = {
        "schema": "aic.maintenance-test-report", "schema_version": "1.0.0",
        "workspace": str(root), "pattern": pattern, "passed": process.returncode == 0,
        "exit_code": process.returncode, "stdout_tail": process.stdout[-20000:],
        "stderr_tail": process.stderr[-20000:], "tested_at": utc_now(),
    }
    report_path = root.parent / f".{root.name}.aic-test-report.json"
    atomic_write(report_path, pretty_bytes(report))
    if process.returncode != 0:
        raise StateError("MAINTENANCE_TESTS_FAILED", "维护工作区测试失败，禁止重打包", report=str(report_path), stderr_tail=process.stderr[-4000:])
    return {"report": str(report_path), "exit_code": process.returncode, "passed": True}


def repack_workspace(project_root: Path, workspace: str, output: str, test_report: str) -> dict[str, Any]:
    root = Path(workspace).resolve(strict=False)
    destination = Path(output).resolve(strict=False)
    report_path = Path(test_report).resolve(strict=False)
    _outside_project(project_root, root, "维护工作区")
    _outside_project(project_root, destination, "候选 ZIP")
    if destination.exists():
        raise StateError("PATH_OUTPUT_EXISTS", "候选 ZIP 已存在，禁止覆盖", path=str(destination))
    report = json.loads(report_path.read_text(encoding="utf-8")) if report_path.is_file() else None
    if not report or not report.get("passed") or Path(report.get("workspace", "")).resolve(strict=False) != root:
        raise StateError("MAINTENANCE_TEST_REPORT_INVALID", "缺少该维护工作区的通过测试报告")
    if report.get("pattern") != "test_*.py":
        raise StateError("MAINTENANCE_FULL_TESTS_REQUIRED", "正式重打包必须使用完整 test_*.py 回归报告", pattern=report.get("pattern"))
    script = root / ".ai-system" / "maintenance" / "repack.py"
    if not script.is_file():
        raise StateError("MAINTENANCE_REPACK_TOOL_MISSING", "维护工作区缺少重打包工具")
    process = subprocess.run(
        [sys.executable, str(script), "--package-root", str(root), "--output", str(destination)],
        cwd=str(root), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300, shell=False,
    )
    if process.returncode != 0:
        raise StateError("MAINTENANCE_REPACK_FAILED", "候选 ZIP 重打包失败", stderr=process.stderr[-4000:], stdout=process.stdout[-4000:])
    try:
        verified = bootstrap.verify_package(destination)
    except bootstrap.AICError as exc:
        raise StateError(exc.code, exc.message, **exc.details) from exc
    return {
        "output": str(destination), "sha256": sha256_file(destination),
        "package": verified["package"], "members": verified["preflight"]["members"],
        "test_report": str(report_path),
    }
