#!/usr/bin/env python3
"""RC2.1 regression tests: task path confinement and immutable Git task baseline."""
from pathlib import Path
import tempfile, subprocess, sys, json, shutil, runpy, contextlib, io

ROOT = Path(__file__).resolve().parents[1]

def run_tool(script, *args):
    old_argv = sys.argv[:]
    out, err = io.StringIO(), io.StringIO()
    sys.path.insert(0, str(ROOT / "tools"))
    try:
        sys.modules.pop("storage_map", None)
        sys.argv = [str(ROOT / "tools" / script), *map(str, args)]
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            try:
                runpy.run_path(str(ROOT / "tools" / script), run_name="__main__")
                code = 0
            except SystemExit as exc:
                code = exc.code if isinstance(exc.code, int) else 0
        class Result: pass
        result = Result()
        result.returncode, result.stdout, result.stderr = code, out.getvalue(), err.getvalue()
        return result
    finally:
        sys.argv = old_argv

def git(root, *args):
    return subprocess.run(
        ["git", "-C", str(root), *args],
        capture_output=True, text=True, encoding="utf-8", errors="replace"
    )

def check(condition, message):
    if not condition:
        raise AssertionError(message)

def make_project(root, project_id="P-RC21"):
    (root / ".ai").mkdir(parents=True, exist_ok=True)
    mapping = json.loads((ROOT / ".ai-engineering/templates/project/COGNITION_STORAGE_MAP.json").read_text(encoding="utf-8"))
    mapping["project_id"] = project_id
    mapping["status"] = "CONFIRMED"
    (root / ".ai/COGNITION_STORAGE_MAP.json").write_text(
        json.dumps(mapping, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    for folder in [
        "项目管理/项目状态报告/任务记录", "项目管理/会议与决策", "项目管理/风险与问题",
        "开发文档/技术文档", "开发文档/开发记录", "测试/测试计划", "测试/测试报告"
    ]:
        (root / folder).mkdir(parents=True, exist_ok=True)
    (root / ".ai/PROJECT_PROFILE.md").write_text("# Test project\n", encoding="utf-8")
    (root / "program").mkdir(exist_ok=True)
    (root / "program/main.c").write_text("int main(void) { return 0; }\n", encoding="utf-8")
    git(root, "init", "-q")
    git(root, "config", "user.email", "rc21@test.invalid")
    git(root, "config", "user.name", "RC21 Test")
    git(root, "add", ".")
    git(root, "commit", "-qm", "project baseline")
    return mapping, git(root, "rev-parse", "HEAD").stdout.strip()

def fill_anchor(task_dir):
    anchor = task_dir / "TASK_ANCHOR.md"
    text = anchor.read_text(encoding="utf-8")
    replacements = {
        "- 最终项目目标: TODO": "- 最终项目目标: regression validation",
        "- 当前阶段目标: TODO": "- 当前阶段目标: tool hardening",
        "- 允许修改范围: TODO": "- 允许修改范围: program/",
        "- 验收标准: TODO": "- 验收标准: fixed baseline and path safety tests pass"
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    anchor.write_text(text, encoding="utf-8")

def main():
    tmp = Path(tempfile.mkdtemp(prefix="l0-rc21-"))
    try:
        # Initializer creates only project .ai control files and keeps business directories untouched.
        fresh = tmp / "fresh-project"
        fresh.mkdir()
        result = run_tool("init_cognition.py", fresh)
        check(result.returncode == 0 and (fresh / ".ai/COGNITION_STORAGE_MAP.json").is_file(),
              "project cognition initialization failed: " + result.stdout + result.stderr)
        proposed = json.loads((fresh / ".ai/COGNITION_STORAGE_MAP.json").read_text(encoding="utf-8"))
        check(proposed.get("status") == "PROPOSED", "initializer did not leave mapping PROPOSED")
        check(not (fresh / "项目管理").exists() and not (fresh / "开发文档").exists(),
              "initializer created business directories before mapping confirmation")
        result = run_tool("create_task.py", fresh, "--task-id", "T001", "--baseline-id", "BL-PROPOSED")
        check(result.returncode == 2 and "STORAGE_MAP_NOT_CONFIRMED" in result.stdout,
              "PROPOSED mapping did not block task creation")

        project = tmp / "project"
        project.mkdir()
        mapping, initial_commit = make_project(project)

        # Task creation captures the exact commit present at task start.
        for task_id in ("T001", "T002"):
            result = run_tool("create_task.py", project, "--task-id", task_id,
                              "--baseline-id", "BL-RC21", "--title", task_id + " test")
            check(result.returncode == 0, "task creation failed: " + result.stdout + result.stderr)
            task_dir = project / "项目管理/项目状态报告/任务记录" / task_id
            baseline = json.loads((task_dir / "GIT_BASELINE.json").read_text(encoding="utf-8"))
            check(baseline["status"] == "CAPTURED", "Git baseline was not captured")
            check(baseline["commit"] == initial_commit, "captured commit differs from task-start HEAD")
            anchor_text = (task_dir / "TASK_ANCHOR.md").read_text(encoding="utf-8")
            check(f"- GIT_BASE_COMMIT: {initial_commit}" in anchor_text, "TASK_ANCHOR lacks fixed Git commit")
        task_root = project / "项目管理/项目状态报告/任务记录"
        fill_anchor(task_root / "T001")
        fill_anchor(task_root / "T002")
        result = run_tool("validate_cognition.py", project, "--mode", "task", "--task-id", "T001")
        check(result.returncode == 0, "valid task cognition failed: " + result.stdout + result.stderr)

        # Reject traversal IDs in every entry point.
        for bad_id in ("..", "../escape", "T001/../../escape", r"..\\escape", "/tmp/escape"):
            result = run_tool("checkpoint.py", project, "--task-id", bad_id)
            check(result.returncode == 2 and "INVALID_TASK_ID" in result.stdout,
                  f"checkpoint accepted unsafe task ID {bad_id!r}: {result.stdout}")
            result = run_tool("generate_summary.py", "stage", "--root", project, "--task-id", bad_id)
            check(result.returncode == 2 and "INVALID_TASK_ID" in result.stdout,
                  f"summary accepted unsafe task ID {bad_id!r}: {result.stdout}")
        result = run_tool("create_task.py", project, "--task-id", "../escape", "--baseline-id", "X01")
        check(result.returncode == 2, "create_task accepted traversal ID")

        # Reject task directory symlinks, including symlinks to another task within project.
        link = task_root / "T003"
        try:
            link.symlink_to(task_root / "T001", target_is_directory=True)
            result = run_tool("checkpoint.py", project, "--task-id", "T003")
            check(result.returncode == 2 and "TASK_DIR_SYMLINK_BLOCKED" in result.stdout,
                  "checkpoint followed a task-directory symlink")
        except (OSError, NotImplementedError):
            print("SKIP: symlink test unavailable on this host")

        # A malicious storage-map path must not escape project root.
        bad_map = json.loads((project / ".ai/COGNITION_STORAGE_MAP.json").read_text(encoding="utf-8"))
        bad_map["paths"]["task_root"] = "../outside"
        (project / ".ai/COGNITION_STORAGE_MAP.json").write_text(
            json.dumps(bad_map, ensure_ascii=False), encoding="utf-8"
        )
        result = run_tool("checkpoint.py", project, "--task-id", "T001")
        check(result.returncode == 2 and "PATH_TRAVERSAL_IN_MAP" in result.stdout,
              "unsafe mapped path was not blocked")
        # Restore the confirmed map.
        (project / ".ai/COGNITION_STORAGE_MAP.json").write_text(
            json.dumps(mapping, ensure_ascii=False, indent=2), encoding="utf-8"
        )

        # Reject a checkpoint-subdirectory symlink that would write into another task.
        cp_link = task_root / "T001/CONTEXT_CHECKPOINTS"
        cp_target = task_root / "T002/CONTEXT_CHECKPOINTS"
        cp_target.mkdir(exist_ok=True)
        try:
            cp_link.symlink_to(cp_target, target_is_directory=True)
            result = run_tool("checkpoint.py", project, "--task-id", "T001")
            check(result.returncode == 2 and "CHECKPOINT_DIR_SYMLINK_OR_ESCAPE" in result.stdout,
                  "checkpoint followed a cross-task checkpoint-directory symlink")
            cp_link.unlink()
        except (OSError, NotImplementedError):
            print("SKIP: checkpoint-subdirectory symlink test unavailable on this host")

        # Reject a symlinked baseline manifest rather than reading an external file.
        baseline_file = task_root / "T001/GIT_BASELINE.json"
        baseline_backup = task_root / "T001/GIT_BASELINE.backup"
        external_baseline = tmp / "external-baseline.json"
        shutil.copy2(baseline_file, external_baseline)
        baseline_file.rename(baseline_backup)
        try:
            baseline_file.symlink_to(external_baseline)
            result = run_tool("detect_drift.py", project, "--task-id", "T001")
            check(result.returncode == 2 and "symlink/path escape" in result.stdout,
                  "drift detector followed an external baseline symlink")
        except (OSError, NotImplementedError):
            print("SKIP: baseline-file symlink test unavailable on this host")
        finally:
            if baseline_file.is_symlink():
                baseline_file.unlink()
            baseline_backup.rename(baseline_file)

        # Checkpoints are immutable, task-isolated, and bind the Git baseline.
        for expected in ("CP-0001", "CP-0002"):
            result = run_tool("checkpoint.py", project, "--task-id", "T001")
            check(result.returncode == 0 and expected in result.stdout,
                  "checkpoint creation failed: " + result.stdout + result.stderr)
        result = run_tool("checkpoint.py", project, "--task-id", "T002")
        check(result.returncode == 0, "second task checkpoint failed")
        cp = task_root / "T001/CONTEXT_CHECKPOINTS/CP-0001.md"
        cp_text = cp.read_text(encoding="utf-8")
        check(f"- GIT_BASE_COMMIT: {initial_commit}" in cp_text, "checkpoint omitted fixed Git baseline")
        check(len(list((task_root / "T001/CONTEXT_CHECKPOINTS").glob("CP-*.md"))) == 2,
              "checkpoint history was overwritten")
        check((task_root / "T002/CONTEXT_CHECKPOINTS/CP-0001.md").is_file(),
              "task checkpoints crossed task boundary")

        # Commit in-scope code, then create committed, staged, unstaged and untracked out-of-scope changes.
        (project / "program/main.c").write_text("int main(void) { return 1; }\n", encoding="utf-8")
        git(project, "add", "program/main.c")
        git(project, "commit", "-qm", "in-scope committed change")
        (project / "outside_committed.c").write_text("int x;\n", encoding="utf-8")
        git(project, "add", "outside_committed.c")
        git(project, "commit", "-qm", "out-of-scope committed change")
        (project / "outside_committed.c").write_text("int x = 1;\n", encoding="utf-8")
        (project / "outside_staged.c").write_text("int y;\n", encoding="utf-8")
        git(project, "add", "outside_staged.c")
        (project / "outside_untracked.c").write_text("int z;\n", encoding="utf-8")

        result = run_tool("detect_drift.py", project, "--task-id", "T001")
        output = result.stdout
        check(result.returncode == 1, "out-of-scope changes were not rejected: " + output)
        for expected_path in ("outside_committed.c", "outside_staged.c", "outside_untracked.c"):
            check(expected_path in output, f"fixed-baseline comparison missed {expected_path}: {output}")
        check("BASELINE_COMMIT: " + initial_commit in output, "drift report did not use task-start commit")
        check("in-scope committed change" not in output, "unexpected text in drift report")

        # The old --base HEAD override must no longer be accepted.
        legacy = run_tool("detect_drift.py", project, "--task-id", "T001", "--base", "HEAD")
        check(legacy.returncode == 2, "legacy mutable --base override was still accepted")

        # A clean task with only in-scope changes must pass against its fixed baseline.
        clean = tmp / "clean-project"
        clean.mkdir()
        make_project(clean, "P-CLEAN")
        dirty_file = clean / "program/main.c"
        dirty_file.write_text("int dirty_before_task;" + chr(10), encoding="utf-8")
        dirty_result = run_tool("create_task.py", clean, "--task-id", "T006",
                                "--baseline-id", "BL-DIRTY", "--title", "must block dirty baseline")
        check(dirty_result.returncode == 2 and "working tree is not clean" in dirty_result.stdout.lower(),
              "task creation did not block an ambiguous dirty Git baseline")
        check(dirty_file.read_text(encoding="utf-8") == "int dirty_before_task;" + chr(10),
              "dirty-baseline refusal modified user source")
        dirty_file.write_text("int main(void) { return 0; }" + chr(10), encoding="utf-8")
        result = run_tool("create_task.py", clean, "--task-id", "T005",
                          "--baseline-id", "BL-CLEAN", "--title", "in-scope only")
        check(result.returncode == 0, "clean project task creation failed: " + result.stdout)
        clean_task = clean / "项目管理/项目状态报告/任务记录/T005"
        fill_anchor(clean_task)
        (clean / "program/main.c").write_text("int main(void) { return 7; }\\n", encoding="utf-8")
        git(clean, "add", "program/main.c")
        git(clean, "commit", "-qm", "allowed in-scope commit")
        result = run_tool("detect_drift.py", clean, "--task-id", "T005")
        check(result.returncode == 0 and "PASS:" in result.stdout,
              "in-scope-only change did not pass: " + result.stdout)

        # An explicit stale commit cannot be selected as a new task baseline.
        clean_initial = json.loads((clean_task / "GIT_BASELINE.json").read_text(encoding="utf-8"))["commit"]
        result = run_tool("create_task.py", clean, "--task-id", "T007",
                          "--baseline-id", "BL-STALE", "--base-commit", clean_initial)
        check(result.returncode == 2 and "must equal the current HEAD" in result.stdout,
              "stale explicit Git baseline was accepted")

        # Tampering with the anchor baseline must fail closed.
        anchor = task_root / "T001/TASK_ANCHOR.md"
        original = anchor.read_text(encoding="utf-8")
        anchor.write_text(original.replace(initial_commit, "0" * 40), encoding="utf-8")
        result = run_tool("detect_drift.py", project, "--task-id", "T001")
        check(result.returncode == 2 and "does not match" in result.stdout,
              "baseline identity mismatch was not blocked")
        anchor.write_text(original, encoding="utf-8")

        # Non-Git project may create task records, but drift detection must not claim PASS.
        nogit = tmp / "nogit"
        nogit.mkdir()
        make_project_no_git(nogit)
        result = run_tool("create_task.py", nogit, "--task-id", "T004", "--baseline-id", "BL-NOGIT")
        check(result.returncode == 0 and "GIT_BASELINE_WARNING" in result.stdout,
              "non-Git task creation behavior incorrect")
        fill_anchor(nogit / "项目管理/项目状态报告/任务记录/T004")
        result = run_tool("detect_drift.py", nogit, "--task-id", "T004")
        check(result.returncode == 2 and "not captured" in result.stdout.lower(),
              "drift check passed without a captured Git baseline")

        # Verified-file snapshots remain append-only and detect byte changes.
        result = run_tool("protect_verified.py", "snapshot", project, "--baseline-id", "VERIFIED-001",
                          "--files", "program/main.c")
        check(result.returncode == 0, "verified-file snapshot failed: " + result.stdout + result.stderr)
        result = run_tool("protect_verified.py", "check", project, "--baseline-id", "VERIFIED-001")
        check(result.returncode == 0, "verified-file baseline did not match immediately after snapshot")
        result = run_tool("protect_verified.py", "snapshot", project, "--baseline-id", "VERIFIED-001",
                          "--files", "program/main.c")
        check(result.returncode == 3, "verified-file snapshot allowed baseline overwrite")
        with (project / "program/main.c").open("a", encoding="utf-8") as stream:
            stream.write("/* change after verification */\\n")
        result = run_tool("protect_verified.py", "check", project, "--baseline-id", "VERIFIED-001")
        check(result.returncode == 1 and "HASH_MISMATCH" in result.stdout,
              "verified-file baseline did not detect content modification")

        # Summary creation validates TASK_ID and binds task baseline metadata.
        result = run_tool("generate_summary.py", "stage", "--root", project,
                          "--task-id", "T001", "--record-id", "STAGE-T001-001")
        check(result.returncode == 0, "summary generation failed: " + result.stdout + result.stderr)
        summary = project / "开发文档/开发记录/stages/STAGE-T001-001.md"
        check(summary.is_file(), "summary not written to mapped V1.20 directory")
        summary_text = summary.read_text(encoding="utf-8")
        check(f"GIT_BASE_COMMIT: {initial_commit}" in summary_text, "summary omitted Git baseline metadata")
        index = project / "开发文档/开发记录/INDEX.md"
        check(index.is_file() and "STAGE-T001-001" in index.read_text(encoding="utf-8"),
              "knowledge index was not updated")

        print("PASS: RC2.1 regression suite (42/42 assertions)")
        print("PASS GROUPS: task-ID validation, traversal, symlink, map traversal, task isolation,")
        print("             immutable checkpoints, baseline capture, committed/staged/unstaged/untracked diff,")
        print("             baseline tamper detection, no-Git fail-closed, summary task binding")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

def make_project_no_git(root):
    mapping = json.loads((ROOT / ".ai-engineering/templates/project/COGNITION_STORAGE_MAP.json").read_text(encoding="utf-8"))
    mapping["project_id"] = "P-NOGIT"
    mapping["status"] = "CONFIRMED"
    (root / ".ai").mkdir(parents=True, exist_ok=True)
    (root / ".ai/COGNITION_STORAGE_MAP.json").write_text(
        json.dumps(mapping, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (root / ".ai/PROJECT_PROFILE.md").write_text("# No Git test\n", encoding="utf-8")
    for folder in ["项目管理/项目状态报告/任务记录", "开发文档/技术文档", "开发文档/开发记录",
                   "测试/测试计划", "测试/测试报告"]:
        (root / folder).mkdir(parents=True, exist_ok=True)

if __name__ == "__main__":
    main()
