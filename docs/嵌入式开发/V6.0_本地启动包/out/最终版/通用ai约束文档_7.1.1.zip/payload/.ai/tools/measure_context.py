#!/usr/bin/env python3
"""Estimate loaded rule size. Character/4 is a rough heuristic, not model token telemetry."""
from pathlib import Path
import argparse
p=argparse.ArgumentParser(); p.add_argument("files",nargs="+"); a=p.parse_args()
total=0
for f in a.files:
    n=len(Path(f).read_text(encoding="utf-8"))
    total+=n
    print(f"{f}\tchars={n}\test_tokens_char_div_4={(n+3)//4}")
print(f"TOTAL chars={total}; rough_estimated_tokens={(total+3)//4}")
print("NOTE: tokenizer/model-specific token usage must be measured from the AI provider; this is only a rough estimate.")
