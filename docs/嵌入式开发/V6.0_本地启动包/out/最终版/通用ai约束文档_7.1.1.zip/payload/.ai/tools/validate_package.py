#!/usr/bin/env python3
"""Strictly verify required files, local Markdown links and complete SHA-256 package manifest."""
from pathlib import Path
import hashlib, re, sys
ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / ".ai-engineering/installation/PACKAGE_MANIFEST.md"
REQUIRED = [
    "AGENTS.md", "README.md", ".ai-engineering/VERSION.md", ".ai-engineering/RULES_INDEX.md",
    ".ai-engineering/cognition/COGNITION_CORE.md", ".ai-engineering/workflows/L0认知连续性与研发知识沉淀工作流.md", ".ai-engineering/project-framework/项目目录框架_V1.20.md", ".ai-engineering/project-framework/L0认知记录与研发资料存储映射.md",
    "tools/validate_cognition.py", "tools/detect_drift.py", "tools/protect_verified.py", "tools/storage_map.py", "tools/create_task.py",
    "tools/checkpoint.py", "tools/generate_summary.py", "tools/init_cognition.py", "tools/test_l0_rc2.py", "tools/test_l0_rc22.py", "tools/test_layout_rc23.py", "tools/test_incremental_entrypoints_rc24.py", "docs/V6.2.0-RC2.1_修复与验证报告.md", "docs/V6.2.0-RC2.2_开发者使用修复与验证报告.md", ".ai-engineering/templates/project/COGNITION_STORAGE_MAP.json",
    ".ai-engineering/rules/06_任务生命周期与阶段门禁.md", ".ai-engineering/rules/07_输入锁定与变更检测.md",
    ".ai-engineering/rules/08_停止规则与恢复机制.md", ".ai-engineering/rules/09_无人值守执行权限.md",
    ".ai-engineering/rules/10_跨版本交接与迁移.md", ".ai-engineering/work/README.md",
    ".ai-engineering/workflows/项目识别与事实提取工作流.md", ".ai-engineering/workflows/原理图设计工作流.md",
    ".ai-engineering/workflows/PCB设计工作流.md", ".ai-engineering/workflows/生产校准工作流.md",
    "tools/lock_inputs.py", "tools/task_lock.py", "tools/validate_task.py", "tools/validate_handoff.py"
]
errors=[]
for rel in REQUIRED:
    if not (ROOT/rel).is_file(): errors.append(f"MISSING_REQUIRED: {rel}")
if not MANIFEST.is_file():
    errors.append("MISSING_MANIFEST")
    entries={}
else:
    text=MANIFEST.read_text(encoding="utf-8")
    entries={}
    for rel,digest in re.findall(r'^\| `([^`]+)` \| `([0-9a-f]{64})` \|$', text, re.M):
        if rel in entries: errors.append(f"DUPLICATE_MANIFEST_PATH: {rel}")
        entries[rel]=digest
    if not entries: errors.append("EMPTY_OR_UNPARSEABLE_MANIFEST")
    for rel,expected in entries.items():
        fp=ROOT/rel
        if not fp.is_file(): errors.append(f"MANIFEST_FILE_MISSING: {rel}"); continue
        actual=hashlib.sha256(fp.read_bytes()).hexdigest()
        if actual != expected: errors.append(f"HASH_MISMATCH: {rel} expected={expected} actual={actual}")
    package_owned_roots={".ai-engineering", ".github", "AGENTS.md", "AI-INSTRUCTIONS.md", "README.md", "docs", "tools"}
    actual_files={
        p.relative_to(ROOT).as_posix()
        for p in ROOT.rglob('*')
        if p.is_file() and p != MANIFEST and '__pycache__' not in p.parts
        and p.relative_to(ROOT).parts
        and p.relative_to(ROOT).parts[0] in package_owned_roots
    }
    listed=set(entries)
    for rel in sorted(actual_files-listed): errors.append(f"UNLISTED_FILE: {rel}")
    for rel in sorted(listed-actual_files): errors.append(f"STALE_MANIFEST_ENTRY: {rel}")
for p in ROOT.rglob('*'):
    if p.is_file() and '\\' in p.relative_to(ROOT).as_posix(): errors.append(f"INVALID_PATH: {p.relative_to(ROOT)}")
# Local Markdown links; skip code fences and URLs.
for md in ROOT.rglob('*.md'):
    lines=[]; fenced=False
    for line in md.read_text(encoding='utf-8').splitlines():
        if line.lstrip().startswith('```'): fenced=not fenced; continue
        if not fenced: lines.append(line)
    for target in re.findall(r'\]\(([^)]+)\)', '\n'.join(lines)):
        target=target.strip().split('#',1)[0]
        if not target or '://' in target or target.startswith(('mailto:','tel:')): continue
        if not (md.parent/target).resolve().exists() and not (ROOT/target).resolve().exists():
            errors.append(f"BROKEN_LINK: {md.relative_to(ROOT)} -> {target}")
if errors:
    print("FAIL: package validation found issues")
    print("\n".join(errors)); sys.exit(1)
print(f"PASS: {len(REQUIRED)} required files; {len(entries)} manifest hashes; package-owned file-set match (project runtime records under .ai/ are excluded); local links and path checks passed.")
