#!/usr/bin/env python3
"""Initialize only the V1.20 project root records; never create a parallel project knowledge tree."""
from pathlib import Path
import argparse,json,shutil,hashlib,sys,datetime
p=argparse.ArgumentParser()
p.add_argument("project_root",nargs="?",default=".")
p.add_argument("--framework",default="")
a=p.parse_args()
root=Path(a.project_root).resolve()
pkg=Path(__file__).resolve().parent.parent
framework=Path(a.framework).resolve() if a.framework else pkg/".ai-engineering/project-framework/项目目录框架_V1.20.md"
if not root.is_dir(): print("PROJECT_ROOT_NOT_FOUND"); sys.exit(2)
if not framework.is_file(): print("FRAMEWORK_NOT_FOUND:",framework); sys.exit(2)
ai=root/".ai"; ai.mkdir(exist_ok=True)
created=[]; preserved=[]
def copy_new(src,dst):
    if dst.exists(): preserved.append(str(dst.relative_to(root))); return
    dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst); created.append(str(dst.relative_to(root)))
copy_new(framework,ai/"项目目录框架.md")
profile=ai/"PROJECT_PROFILE.md"
if not profile.exists():
    digest=hashlib.sha256(framework.read_bytes()).hexdigest()
    profile.write_text(f"""# 项目档案
- 目录框架版本：V1.20
- 目录框架 SHA-256：{digest}
- 目录框架完整读取日期：待填写
- 生成/复核日期：{datetime.date.today().isoformat()}

## 项目事实
- 项目ID：待填写
- 名称/产品/范围/阶段：待确认
- 启用目录及用途：待盘点
- 构建入口及恢复方式：待确认
- 存储方案/工作主文件/冻结快照：待确认
- 项目例外与待确认：待确认
""",encoding="utf-8"); created.append(".ai/PROJECT_PROFILE.md")
# Project facts and environment are project-level .ai records, not package-internal records.
for src_rel, dst_name in [
    (".ai-engineering/templates/cognition/PROJECT_FACTS.md","PROJECT_FACTS.md"),
    (".ai-engineering/templates/cognition/ENVIRONMENT_BASELINE.md","ENVIRONMENT_BASELINE.md")
]:
    src=pkg/src_rel
    if src.is_file(): copy_new(src,ai/dst_name)
map_path=ai/"COGNITION_STORAGE_MAP.json"
if not map_path.exists():
    data={"schema_version":"1.0","framework_version":"V1.20","project_id":"待填写","mode":"ORGANIZE","status":"PROPOSED","paths":{
      "profile":".ai/PROJECT_PROFILE.md","project_facts":".ai/PROJECT_FACTS.md","environment_baseline":".ai/ENVIRONMENT_BASELINE.md",
      "task_root":"项目管理/项目状态报告/任务记录","decision_ledger":"项目管理/会议与决策/DECISION_LEDGER.md",
      "failed_approaches":"项目管理/风险与问题/FAILED_APPROACHES.md","risk_register":"项目管理/风险与问题/RISK_REGISTER.md",
      "conflict_register":"项目管理/风险与问题/CONFLICT_REGISTER.md","issue_records":"项目管理/风险与问题/问题闭环",
      "technical_knowledge":"开发文档/技术文档","development_records":"开发文档/开发记录","knowledge_index":"开发文档/开发记录/INDEX.md",
      "verified_features":"测试/测试计划/VERIFIED_FEATURES.md","regression_baseline":"测试/测试计划/REGRESSION_BASELINE.md",
      "test_evidence":"测试/测试报告","change_records":"配置与变更管理/ECO工程变更",
      "change_verification":"配置与变更管理/变更验证","milestones":"项目管理/计划与里程碑",
      "retrospectives":"项目管理/项目状态报告/复盘","stage_reviews":"阶段评审",
      "release_docs":"开发文档/版本发布","release_artifacts":"release"}}
    map_path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"); created.append(".ai/COGNITION_STORAGE_MAP.json")
print("CREATED:",len(created)); print("\n".join(created) if created else "(none)")
print("PRESERVED:",len(preserved)); print("\n".join(preserved) if preserved else "(none)")
print("NEXT: inspect actual directories, fill PROJECT_ID and path mappings, then set status=CONFIRMED. No business directories or project records were created.")
