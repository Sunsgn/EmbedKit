#!/usr/bin/env python3
"""Create a task record and capture its immutable Git starting commit when available."""
from pathlib import Path
import argparse, datetime, json, subprocess, sys, re
sys.dont_write_bytecode = True
from storage_map import task_dir, resolve, validate_task_id, MapError

def git_output(root, *args):
    return subprocess.run(
        ["git", "-C", str(root), *args],
        capture_output=True, text=True, encoding="utf-8", errors="replace"
    )

def capture_git_baseline(root, requested, task_root_path):
    probe = git_output(root, "rev-parse", "--show-toplevel")
    if probe.returncode != 0:
        if requested:
            raise RuntimeError("--base-commit supplied but project is not inside a Git repository")
        return {
            "status": "NOT_CAPTURED",
            "working_tree_clean": None,
            "commit": None,
            "branch": None,
            "reason": "Project is not inside a Git repository; drift detection remains BLOCKED until a valid baseline is recorded."
        }
    if Path(probe.stdout.strip()).resolve() != root:
        # A task root may be nested below the repository root. Record the actual repository root.
        repo_root = Path(probe.stdout.strip()).resolve()
    else:
        repo_root = root
    try:
        # Git is invoked with -C <project_root>, so pathspec exclusions are relative
        # to the project root, not necessarily the repository root.
        task_root_rel = task_root_path.resolve().relative_to(root).as_posix().rstrip("/") + "/"
    except ValueError:
        raise RuntimeError("Mapped task-record root is outside the project root")
    status = git_output(
        root, "-c", "core.quotepath=false", "status", "--porcelain=v1",
        "--untracked-files=all", "--", ".", f":(exclude){task_root_rel}**"
    )
    if status.returncode != 0:
        raise RuntimeError("Cannot determine Git working-tree state; refusing to create an ambiguous baseline")
    if status.stdout.strip():
        dirty = status.stdout.strip().splitlines()
        preview = " | ".join(dirty[:12])
        raise RuntimeError(
            "Git working tree is not clean. Preserve existing changes and establish a clean task baseline "
            "before creating the task. No reset/stash/checkout was performed. Dirty entries: " + preview
        )
    revision = requested or "HEAD"
    resolved = git_output(root, "rev-parse", "--verify", f"{revision}^{{commit}}")
    if resolved.returncode != 0:
        raise RuntimeError(f"Cannot resolve Git base commit {revision!r}: {resolved.stderr.strip()}")
    commit = resolved.stdout.strip().lower()
    if not re.fullmatch(r"[0-9a-f]{40,64}", commit):
        raise RuntimeError(f"Git returned an invalid commit SHA: {commit!r}")
    current_head = git_output(root, "rev-parse", "--verify", "HEAD^{commit}")
    if current_head.returncode != 0:
        raise RuntimeError("Cannot resolve current Git HEAD")
    if commit != current_head.stdout.strip().lower():
        raise RuntimeError(
            "--base-commit must equal the current HEAD at task creation; "
            "an older commit would include pre-task changes in the drift comparison."
        )
    branch_result = git_output(root, "symbolic-ref", "--quiet", "--short", "HEAD")
    branch = branch_result.stdout.strip() if branch_result.returncode == 0 else "DETACHED"
    return {
        "status": "CAPTURED",
        "working_tree_clean": True,
        "commit": commit,
        "branch_at_creation": branch,
        "repository_root": str(repo_root),
        "reason": None
    }

parser = argparse.ArgumentParser()
parser.add_argument("project_root", nargs="?", default=".")
parser.add_argument("--task-id", required=True)
parser.add_argument("--baseline-id", required=True)
parser.add_argument("--title", default="待填写")
parser.add_argument("--base-commit", default="",
                    help="Optional explicit Git commit. Defaults to HEAD at task creation.")
args = parser.parse_args()
root = Path(args.project_root).resolve()
try:
    validate_task_id(args.task_id)
    task_path, mapping = task_dir(root, args.task_id)
    task_root_path, _ = resolve(root, "task_root")
    git_baseline = capture_git_baseline(root, args.base_commit.strip() or None, task_root_path)
except (MapError, RuntimeError) as exc:
    print("BLOCKED:", exc)
    sys.exit(2)

if task_path.exists():
    if task_path.is_symlink() or any(task_path.iterdir()):
        print("REFUSE_EXISTING_TASK_DIR:", task_path)
        sys.exit(3)

package_root = Path(__file__).resolve().parent.parent
templates = package_root / ".ai-engineering/templates"
template_files = {
    "TASK_ANCHOR.md": templates / "cognition/TASK_ANCHOR.md",
    "STATE_CARD.md": templates / "STATE_CARD.md",
    "STARTUP_RECEIPT.md": templates / "STARTUP_RECEIPT.md",
    "PROJECT_DISCOVERY_REPORT.md": templates / "PROJECT_DISCOVERY_REPORT.md",
    "INPUT_LOCK.md": templates / "INPUT_LOCK.md",
    "TASK_PLAN.md": templates / "TASK_PLAN.md",
    "STATUS.md": templates / "STATUS.md",
    "STATE_HISTORY.csv": templates / "STATE_HISTORY.csv",
    "HANDOFF.md": templates / "HANDOFF.md",
    "DECISIONS.md": templates / "DECISIONS.md"
}
for name, src in template_files.items():
    if not src.is_file():
        print("MISSING_TEMPLATE:", src)
        sys.exit(4)

created_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
contents = {}
def set_field(content, label, value):
    lines = content.splitlines()
    pattern = re.compile(r"^([ 	]*[-*][ 	]*" + re.escape(label) + r"[ 	]*[:：])")
    for index, line in enumerate(lines):
        match = pattern.match(line)
        if match:
            lines[index] = match.group(1) + " " + value
            break
    return "\n".join(lines) + "\n"

for name, src in template_files.items():
    content = src.read_text(encoding="utf-8")
    content = content.replace("PROJECT_ID: TODO", f"PROJECT_ID: {mapping['project_id']}")
    content = content.replace("TASK_ID: TODO", f"TASK_ID: {args.task_id}")
    content = content.replace("BASELINE_ID: TODO", f"BASELINE_ID: {args.baseline_id}")
    if name != "DECISIONS.md":
        content = set_field(content, "任务ID", args.task_id)
    if name == "TASK_ANCHOR.md":
        content = content.replace("- GIT_BASE_COMMIT: TODO",
                                  f"- GIT_BASE_COMMIT: {git_baseline['commit'] or 'NOT_CAPTURED'}")
        content = content.replace("- 当前唯一主任务: TODO",
                                  f"- 当前唯一主任务: {args.title}")
    elif name == "STATUS.md":
        content = set_field(content, "最后更新时间", created_at)
    elif name == "STATE_CARD.md":
        content = set_field(content, "项目根目录/工作范围", str(root))
    elif name == "TASK_PLAN.md":
        content = set_field(content, "任务目标", args.title)
    elif name == "STARTUP_RECEIPT.md":
        content = set_field(content, "启动时间", created_at)
        content = set_field(content, "实际工作目录", str(root))
    elif name == "PROJECT_DISCOVERY_REPORT.md":
        content = set_field(content, "项目路径", str(root))
    elif name == "INPUT_LOCK.md":
        content = set_field(content, "锁定ID", args.baseline_id)
        content = set_field(content, "项目根目录", str(root))
        content = set_field(content, "锁定时间", created_at)
        content = set_field(
            content, "Git分支/Commit/工作区状态",
            f"{git_baseline.get('branch_at_creation') or 'NOT_CAPTURED'} / {git_baseline.get('commit') or 'NOT_CAPTURED'} / CLEAN"
            if git_baseline.get("status") == "CAPTURED" else "NOT_CAPTURED"
        )
    elif name == "HANDOFF.md":
        content = set_field(content, "任务ID/目标", f"{args.task_id} / {args.title}")
    contents[name] = content

baseline_record = {
    "schema_version": "1.0",
    "project_id": mapping["project_id"],
    "task_id": args.task_id,
    "baseline_id": args.baseline_id,
    "created_at": created_at,
    **git_baseline,
    "comparison_semantics": "Git changes from captured commit to current working tree, including committed, staged, unstaged, and untracked paths."
}
contents["GIT_BASELINE.json"] = json.dumps(baseline_record, ensure_ascii=False, indent=2) + "\n"

task_path.mkdir(parents=True, exist_ok=True)
for name, content in contents.items():
    dest = task_path / name
    if dest.exists():
        print("REFUSE_OVERWRITE:", dest)
        sys.exit(3)
    dest.write_text(content, encoding="utf-8", newline="\n")
(task_path / "STAGE_GATES").mkdir(exist_ok=True)
(task_path / "evidence").mkdir(exist_ok=True)
print("TASK_CREATED:", task_path)
print("PROJECT_ID:", mapping["project_id"], "TASK_ID:", args.task_id, "BASELINE_ID:", args.baseline_id)
if git_baseline["status"] == "CAPTURED":
    print("GIT_BASE_COMMIT:", git_baseline["commit"])
    print("GIT_BRANCH_AT_CREATION:", git_baseline["branch_at_creation"])
else:
    print("GIT_BASELINE_WARNING:", git_baseline["reason"])
print("STATUS: templates only; fill task facts before execution. Drift check requires CAPTURED Git baseline.")
