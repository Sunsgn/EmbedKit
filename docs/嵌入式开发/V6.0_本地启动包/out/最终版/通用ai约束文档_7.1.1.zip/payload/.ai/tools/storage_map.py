#!/usr/bin/env python3
"""Resolve project record locations from .ai/COGNITION_STORAGE_MAP.json safely.

All write-capable helpers must use these resolvers. The map must be CONFIRMED.
"""
from pathlib import Path
import json
import re

class MapError(RuntimeError):
    pass

_TASK_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{2,99}$")

def validate_task_id(task_id):
    if not isinstance(task_id, str) or not _TASK_ID_RE.fullmatch(task_id):
        raise MapError("INVALID_TASK_ID: expected 3-100 characters [A-Za-z0-9._-], starting with an alphanumeric")
    if task_id in {".", ".."}:
        raise MapError("INVALID_TASK_ID")
    return task_id

def _safe_relative_path(value, label):
    if not isinstance(value, str) or not value.strip():
        raise MapError(f"INVALID_MAPPED_PATH:{label}")
    raw = Path(value)
    # Reject Windows absolute paths even when validating on POSIX.
    if raw.is_absolute() or re.match(r"^[A-Za-z]:[\\/]", value) or value.startswith(("\\\\", "//")):
        raise MapError(f"ABSOLUTE_MAPPED_PATH:{label}")
    normalized = value.replace("\\", "/")
    parts = normalized.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        raise MapError(f"PATH_TRAVERSAL_IN_MAP:{label}")
    return parts

def load_map(root):
    root = Path(root).resolve()
    p = root / ".ai" / "COGNITION_STORAGE_MAP.json"
    if not p.is_file():
        raise MapError(f"STORAGE_MAP_MISSING:{p}")
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        raise MapError(f"STORAGE_MAP_INVALID:{e}")
    if not isinstance(data, dict):
        raise MapError("STORAGE_MAP_INVALID: root must be an object")
    if data.get("status") != "CONFIRMED":
        raise MapError(f"STORAGE_MAP_NOT_CONFIRMED:{data.get('status')}")
    project_id = data.get("project_id")
    if not isinstance(project_id, str) or not project_id.strip() or project_id in {"待填写", "TODO"}:
        raise MapError("PROJECT_ID_MISSING")
    if not isinstance(data.get("paths"), dict):
        raise MapError("STORAGE_MAP_PATHS_INVALID")
    return data

def resolve(root, key, *parts, must_exist=False):
    root = Path(root).resolve()
    data = load_map(root)
    rel = data.get("paths", {}).get(key)
    rel_parts = _safe_relative_path(rel, key)
    for part in parts:
        if not isinstance(part, str) or not part or part in {".", ".."} or "/" in part or "\\" in part:
            raise MapError(f"INVALID_PATH_COMPONENT:{part!r}")
        rel_parts.append(part)
    lexical = root.joinpath(*rel_parts)
    resolved = lexical.resolve(strict=False)
    if not resolved.is_relative_to(root):
        raise MapError(f"PATH_ESCAPE:{resolved}")
    if must_exist and not resolved.exists():
        raise MapError(f"MAPPED_PATH_MISSING:{resolved}")
    return resolved, data

def task_dir(root, task_id):
    validate_task_id(task_id)
    task_root, data = resolve(root, "task_root")
    target = task_root / task_id
    # A task directory must be a direct child of the mapped task root.
    # Reject a symlinked task directory even if it points elsewhere inside the project.
    if target.is_symlink():
        raise MapError(f"TASK_DIR_SYMLINK_BLOCKED:{target}")
    resolved_root = task_root.resolve(strict=False)
    resolved_target = target.resolve(strict=False)
    if resolved_target.parent != resolved_root:
        raise MapError(f"TASK_DIR_ESCAPE:{resolved_target}")
    if not resolved_target.is_relative_to(Path(root).resolve()):
        raise MapError(f"TASK_DIR_OUTSIDE_PROJECT:{resolved_target}")
    return resolved_target, data
