# 环境基线
- PROJECT_ID: TODO
- 适用硬件/软件基线: TODO
- 操作系统及版本: TODO
- IDE/编译器/SDK版本: TODO
- Python及依赖环境: TODO
- EDA工具及版本: 不适用/待确认
- 构建配置与工作目录: TODO
- 来源与采集时间: TODO
- 变更影响及需重验项目: TODO
