# PCB设计与审核报告

- PCB/原理图/网表/板卡版本：
- EDA、DRC及独立查看器版本：
- 层叠、制造能力和规则来源：
- 当前等级：PLAN_ONLY / EDITABLE_LAYOUT / ROUTED / DRC_VERIFIED / FAB_FILES_CHECKED / PHYSICALLY_TESTED
- 最终状态：PASS / FAIL / BLOCKED / BLOCKED_BY_AUTH / NOT_RUN / UNAVAILABLE / NOT_APPLICABLE

| ID | 坐标/网络/层/对象 | 实测 | 限值/依据 | 风险 | 整改 | 复核证据 | 状态 |
|---|---|---|---|---|---|---|---|
| PCB-001 |  |  |  |  |  |  |  |

- DRC及豁免：
- 关键网络人工审核：
- Gerber/钻孔独立回读：
- 制造输出清单及哈希：
- 未验证边界：
