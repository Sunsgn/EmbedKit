# 任务状态卡

- 任务ID：
- 用户需求原文/目标：
- 项目根目录/工作范围：
- 任务等级：LIGHT / STANDARD / FULL
- 主专业及交叉专业：
- 当前生命周期/阶段：
- 已识别工程/版本及证据：
- 输入状态：UNLOCKED / LOCKED / CHANGED / CONFLICT
- 工具能力：AVAILABLE / PARTIAL / UNAVAILABLE / NOT_PROBED
- 当前授权范围：
- 主要风险：
- 未知/冲突事实：
- 本次验收目标：
- 停止条件：
- 预计输出：
