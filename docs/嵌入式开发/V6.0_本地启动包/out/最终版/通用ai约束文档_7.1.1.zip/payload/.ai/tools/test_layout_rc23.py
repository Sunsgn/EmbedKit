#!/usr/bin/env python3
"""Transitional layout regression for the 7.0 phase-1 package."""
from pathlib import Path
import json
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[2]
AI = Path(__file__).resolve().parents[1]
checks = []

def check(ok, label):
    checks.append((label, bool(ok)))

for name in ("AGENTS.md", "CLAUDE.md", "GEMINI.md"):
    check((PROJECT_ROOT / name).is_file(), f"root {name} exists")
check((PROJECT_ROOT / ".github/copilot-instructions.md").is_file(), "standard Copilot entry exists")
check((AI / "system/ENTRYPOINT.md").is_file(), "unified phase-1 entry exists")
check((AI / "system/aic.py").is_file(), "installed runtime entry exists")
check((AI / "system/bootstrap.py").is_file(), "installed bootstrap exists")
check((AI / "system/PACKAGE.json").is_file(), "installed package identity exists")
check((AI / "system/PACKAGE_MANIFEST.json").is_file(), "installed package manifest exists")
check((AI / "INSTALL_STATE.json").is_file(), "install state exists")
check((AI / "AGENTS.md").is_file(), "legacy rule entry preserved")
check((AI / "AI-INSTRUCTIONS.md").is_file(), "legacy AI instructions preserved")
check((AI / ".ai-engineering/RULES_INDEX.md").is_file(), "legacy rules preserved")
check((AI / "tools/init_cognition.py").is_file(), "legacy tools preserved")

for name in ("AGENTS.md", "CLAUDE.md", "GEMINI.md"):
    text = (PROJECT_ROOT / name).read_text(encoding="utf-8")
    check(".ai/system/ENTRYPOINT.md" in text, f"{name} routes to unified entry")

package = json.loads((AI / "system/PACKAGE.json").read_text(encoding="utf-8"))
state = json.loads((AI / "INSTALL_STATE.json").read_text(encoding="utf-8"))
check(package.get("package_version") == "7.0.0-alpha.1", "package version is 7.0.0-alpha.1")
check(state.get("status") == "INSTALLED", "install state is committed")

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(("PASS" if ok else "FAIL") + " | " + label)
if failed:
    print("FAILED:", len(failed), "/", len(checks))
    sys.exit(1)
print(f"PASS: transitional package layout ({len(checks)}/{len(checks)} checks)")
