# 多AI工具接入（V6.2.0-RC2.3）

## 统一规则源

所有AI工具使用项目根目录 `.ai/AGENTS.md` 作为统一工程入口，规则正文位于 `.ai/.ai-engineering/`。工具专属文件只做加载适配，不复制专业规则。

| 工具 | 根目录入口 | 接入方式 |
|---|---|---|
| Codex | 本包不提供根 `AGENTS.md` | 首次/新会话明确要求读取 `.ai/AGENTS.md` 和 `.ai/AI-INSTRUCTIONS.md`；不能假定自动递归发现 |
| Claude Code | `CLAUDE.md` | 根入口引导读取 `.ai/AGENTS.md` |
| Gemini CLI | `GEMINI.md` | 根入口引导读取 `.ai/AGENTS.md` |
| GitHub Copilot | `.ai/.github/copilot-instructions.md` | 不属于默认根级自动发现路径；需在IDE/工作区配置中显式引用，或要求AI显式读取 |
| 其他AI | `.ai/AI-INSTRUCTIONS.md` | 按通用加载顺序显式读取 |

如果工具不支持自动读取引用文件，首次提示中明确要求读取 `.ai/AGENTS.md`、`.ai/AI-INSTRUCTIONS.md`、通用底线、当前专业Profile、工具能力、局部约束和当前专业规范。每次任务保存 AI 加载回执。切换AI工具时，从 V1.20 映射的任务 `STATUS.md`、`HANDOFF.md`、最近检查点和输入哈希继续。

项目真实记录位置以 `.ai/COGNITION_STORAGE_MAP.json` 为准；不得将跨会话任务状态写入约束包内部 `.ai/.ai-engineering/work/`。
