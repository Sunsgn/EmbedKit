# L0规则目录说明

本目录仅保存约束包自身的L0规则正文，不保存任何项目真实运行记录。

- `COGNITION_CORE.md`：L0最高内部优先级规则。
- 项目真实的PROJECT_PROFILE、事实、环境、决策、失败方案、已验证功能和回归基线，必须存放在项目根目录`.ai/`及V1.20映射的项目业务目录。
- 任务锚点、状态、检查点、偏离报告、影响分析和交接，必须按TASK_ID存放在V1.20映射的任务记录目录。
- `.ai/.ai-engineering/templates/cognition/`只保存空白模板。
- `.ai/.ai-engineering/tools/`只保存通用工具。
- 具体存放规则见`.ai/.ai-engineering/project-framework/L0认知记录与研发资料存储映射.md`。
