# 技术决策台账
| DECISION_ID | 决策问题 | 备选方案 | 最终决策 | 依据/证据 | 状态(USER_CONFIRMED/DECIDED/TEST_VERIFIED) | 适用版本 | 重评条件 | 日期 |
|---|---|---|---|---|---|---|---|---|
