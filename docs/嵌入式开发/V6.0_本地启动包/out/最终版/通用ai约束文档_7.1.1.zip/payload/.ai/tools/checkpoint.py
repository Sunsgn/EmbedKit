#!/usr/bin/env python3
"""Create immutable task-scoped checkpoint drafts under the V1.20 mapped task directory."""
from pathlib import Path
import argparse,datetime,sys,re,json
sys.dont_write_bytecode = True
from storage_map import task_dir,MapError
p=argparse.ArgumentParser()
p.add_argument("project_root",nargs="?",default="."); p.add_argument("--task-id",required=True); p.add_argument("--checkpoint-id",default="")
a=p.parse_args(); root=Path(a.project_root).resolve()
try: td,mapping=task_dir(root,a.task_id)
except MapError as e: print("BLOCKED:",e); sys.exit(2)
src=Path(__file__).resolve().parent.parent/".ai-engineering/templates/cognition/CONTEXT_CHECKPOINT.md"
if not src.is_file(): print("MISSING_TEMPLATE"); sys.exit(2)
anchor=td/"TASK_ANCHOR.md"
if anchor.is_symlink() or not anchor.resolve(strict=False).is_relative_to(td.resolve()) or not anchor.is_file():
    print("TASK_ANCHOR_MISSING_OR_UNSAFE:",anchor); sys.exit(2)
anchor_text=anchor.read_text(encoding="utf-8")
bm=re.search(r"^[ \t]*-[ \t]*BASELINE_ID[ \t]*[:：][ \t]*(.*)$",anchor_text,re.M)
baseline=bm.group(1).strip() if bm else "UNKNOWN"
gm=re.search(r"^[ \t]*-[ \t]*GIT_BASE_COMMIT[ \t]*[:：][ \t]*(.*)$",anchor_text,re.M)
git_base=gm.group(1).strip() if gm else "NOT_CAPTURED"
baseline_file=td/"GIT_BASELINE.json"
if baseline_file.is_symlink() or not baseline_file.resolve(strict=False).is_relative_to(td.resolve()) or not baseline_file.is_file():
    print("GIT_BASELINE_MISSING_OR_UNSAFE:",baseline_file); sys.exit(2)
try:
    git_record=json.loads(baseline_file.read_text(encoding="utf-8"))
except Exception as exc:
    print("GIT_BASELINE_INVALID:",exc); sys.exit(2)
if git_record.get("project_id")!=mapping["project_id"] or git_record.get("task_id")!=a.task_id:
    print("GIT_BASELINE_IDENTITY_MISMATCH"); sys.exit(2)
if (git_record.get("commit") or "NOT_CAPTURED")!=git_base:
    print("GIT_BASELINE_COMMIT_MISMATCH"); sys.exit(2)
out=td/"CONTEXT_CHECKPOINTS"
if out.is_symlink() or not out.resolve(strict=False).is_relative_to(td.resolve()):
    print("CHECKPOINT_DIR_SYMLINK_OR_ESCAPE:",out); sys.exit(2)
out.mkdir(parents=True,exist_ok=True)
nums=[]
for f in out.glob("CP-*.md"):
    m=re.fullmatch(r"CP-(\d{4,})\.md",f.name)
    if m: nums.append(int(m.group(1)))
cid=a.checkpoint_id or f"CP-{max(nums,default=0)+1:04d}"
if not re.fullmatch(r"CP-\d{4,}",cid): p.error("invalid checkpoint id")
dest=out/(cid+".md")
if dest.is_symlink(): print("REFUSE_SYMLINK_TARGET:",dest); sys.exit(2)
if dest.exists(): print("REFUSE_OVERWRITE:",dest); sys.exit(3)
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
s=src.read_text(encoding="utf-8")
for old,new in [
    ("- PROJECT_ID: TODO",f"- PROJECT_ID: {mapping['project_id']}"),
    ("- TASK_ID: TODO",f"- TASK_ID: {a.task_id}"),
    ("- BASELINE_ID: TODO",f"- BASELINE_ID: {baseline}"),
    ("- GIT_BASE_COMMIT: TODO",f"- GIT_BASE_COMMIT: {git_base}"),
    ("- CHECKPOINT_ID: TODO",f"- CHECKPOINT_ID: {cid}"),
    ("- 时间: TODO",f"- 时间: {now}")
]: s=s.replace(old,new)
dest.write_text(s,encoding="utf-8",newline="\n")
idx=out/"INDEX.md"
if idx.is_symlink() or not idx.resolve(strict=False).is_relative_to(out.resolve()):
    print("CHECKPOINT_INDEX_SYMLINK_OR_ESCAPE:",idx); sys.exit(2)
if not idx.exists(): idx.write_text("# 检查点索引\n\n| CHECKPOINT_ID | 文件 | 状态 | 创建时间 |\n|---|---|---|---|\n",encoding="utf-8")
with idx.open("a",encoding="utf-8",newline="\n") as f: f.write(f"| {cid} | `{dest.name}` | DRAFT | {now} |\n")
print("CHECKPOINT_DRAFT_CREATED:",dest); print("STATUS: DRAFT; complete facts/evidence before treating as recoverable.")
