# 知识修订记录
- KNOWLEDGE_ID: TODO
- PROJECT_ID: TODO
- 原版本/状态: TODO
- 新版本/状态: TODO
- 修订原因: TODO
- 新证据及来源: TODO
- 受影响结论: TODO
- 旧结论处理: SUPERSEDED / DISPUTED / ARCHIVED
- 审核/确认状态: TODO
