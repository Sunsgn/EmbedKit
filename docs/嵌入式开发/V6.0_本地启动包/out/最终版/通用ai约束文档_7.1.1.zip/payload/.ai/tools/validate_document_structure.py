#!/usr/bin/env python3
"""Check duplicate Markdown heading numbers and basic internal references."""
from pathlib import Path
import argparse,re,sys
p=argparse.ArgumentParser();p.add_argument('paths',nargs='+');a=p.parse_args();errs=[]
for raw in a.paths:
 f=Path(raw)
 if f.is_dir(): files=list(f.rglob('*.md'))
 else: files=[f]
 for md in files:
  seen={}
  for n,line in enumerate(md.read_text(encoding='utf-8').splitlines(),1):
   m=re.match(r'^#{1,6}\s+(\d+(?:\.\d+)*)[.、 ]+(.+)$',line)
   if m:
    key=(len(line)-len(line.lstrip('#')),m.group(1))
    if key in seen:errs.append(f'{md}:{n}:DUPLICATE_HEADING_NUMBER:{m.group(1)} (first line {seen[key]})')
    else:seen[key]=n
if errs:print('FAIL');print('\\n'.join(errs));sys.exit(1)
print('PASS: no duplicate numbered headings detected. This does not validate technical correctness.')
