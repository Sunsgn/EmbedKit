#!/usr/bin/env python3
"""Read-only project discovery. Heuristic results are candidates, not confirmed facts."""
from pathlib import Path
import argparse, json, shutil, subprocess, datetime
p=argparse.ArgumentParser()
p.add_argument("root", nargs="?", default=".")
p.add_argument("--output", default="PROJECT_DISCOVERY_REPORT.json")
a=p.parse_args()
root=Path(a.root).resolve()
patterns={
 "Keil":["*.uvprojx","*.uvoptx"], "IAR":["*.ewp","*.eww"],
 "CMake":["CMakeLists.txt","CMakePresets.json"], "PlatformIO":["platformio.ini"],
 "STM32CubeIDE":[".project",".cproject"], "FreeRTOS":["FreeRTOSConfig.h"],
 "KiCad":["*.kicad_pro","*.kicad_sch","*.kicad_pcb"],
 "Altium":["*.PrjPcb","*.SchDoc","*.PcbDoc"],
 "Linux":["Kconfig","Makefile","meson.build"]
}
found={}
for kind, pats in patterns.items():
    matches=[]
    for pat in pats:
        matches.extend(str(x.relative_to(root)) for x in root.rglob(pat)
                       if len(x.relative_to(root).parts)<=6 and not any(n in {".git","build","dist","node_modules"} for n in x.parts))
    if matches: found[kind]=sorted(set(matches))[:100]
tools={}
for name in ["git","cmake","ninja","make","arm-none-eabi-gcc","gcc","clang","python","kicad-cli"]:
    exe=shutil.which(name)
    if exe:
        try:
            r=subprocess.run([exe,"--version"],capture_output=True,text=True,timeout=5)
            tools[name]={"path":exe,"version":(r.stdout or r.stderr).splitlines()[:2],"probe":"VERSION_ONLY"}
        except Exception as e: tools[name]={"path":exe,"probe_error":str(e)}
result={"root":str(root),"generated_at":datetime.datetime.now().astimezone().isoformat(),
        "discovery_status":"CANDIDATES_ONLY","evidence_patterns":found,"tools":tools,
        "limitations":["File pattern detection is heuristic.","No project files were modified.",
                       "Tool presence does not prove license, project compatibility, or operation capability."]}
Path(a.output).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(result,ensure_ascii=False,indent=2))
