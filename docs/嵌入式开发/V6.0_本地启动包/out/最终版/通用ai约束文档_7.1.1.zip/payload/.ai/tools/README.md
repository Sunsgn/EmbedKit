# 本地辅助工具

建议 Python 3.10+，仅使用标准库。工具是可选辅助，不扩大AI权限，也不替代专业判断。

```bash
python .ai/tools/validate_package.py
python .ai/tools/test_l0_rc22.py
python .ai/tools/test_l0_rc2.py
python .ai/tools/discover_project.py <项目路径> --output PROJECT_DISCOVERY_REPORT.json
python .ai/tools/lock_inputs.py <项目路径> --task-id <TASK_ID> --baseline-id <BASELINE_ID> --output <任务目录>/input-lock.json --include "Core/**" --include "*.uvprojx"
python .ai/tools/lock_inputs.py <项目路径> --task-id <TASK_ID> --output <任务目录>/input-lock.json --verify
python .ai/tools/task_lock.py acquire <任务目录> --session <会话标识>
python .ai/tools/task_lock.py inspect <任务目录>
python .ai/tools/task_lock.py release <任务目录> --session <会话标识>
python .ai/tools/validate_task.py <任务目录>
python .ai/tools/validate_handoff.py <任务目录>/HANDOFF.md --task-root <任务目录>
```

注意：输入锁定只校验显式纳入文件；应选择目录或通配符覆盖任务相关输入，并单独记录未纳入的外部依赖、子模块、环境和工具状态。任务锁是本地协作锁，不能协调不同机器/云端副本；锁文件存在时不得自动删除或接管。

输入清单输出文件自身会自动排除，不会因位于被扫描目录内而造成自变化。清单绑定精确项目根目录、PROJECT_ID；提供`--task-id`时同时绑定TASK_ID、BASELINE_ID和任务创建时Git Commit。复制/移动项目目录后必须重新生成输入锁定清单，禁止在不同工程副本间复用旧清单。RC2.1及更早版本的输入锁定清单不含完整身份绑定，升级后应重新生成Schema 3清单。任务锁属于协作约定和本地文件锁，不是操作系统强制访问控制；所有会话必须遵守锁规则。证据路径必须位于任务目录内，禁止通过 `..` 引用目录外文件。


## V6.1.2 RC2 新增检查
- `python .ai/tools/validate_task.py <task_dir> --mode structure`：检查任务结构与状态字段。
- `python .ai/tools/validate_task.py <task_dir> --mode acceptance`：检查必填任务内容、状态历史及 ACCEPTED/CLOSED 门禁。
- `python .ai/tools/validate_gates.py <task_dir>`：检查阶段门禁记录结构。
- `python .ai/tools/validate_document_structure.py <规范目录或文件...>`：检查重复编号章节。
- `python .ai/tools/validate_discipline.py <专业规范.md>`：检查十个专业维度是否被覆盖；只做结构检查，不授予专业批准状态。
- `python .ai/tools/test_validators.py`：运行本地正反向测试。
`validate_handoff.py`的证据检查仅确认路径在任务目录内且文件非空；不能证明日志真实执行或技术结论正确。



## V6.2.0 RC2.2：开发者工作流修复

先运行 `python .ai/tools/init_cognition.py <项目根目录>`，该命令只初始化项目根目录 `.ai/` 中的V1.20框架、Profile和 `PROPOSED` 映射，不创建业务目录。盘点真实项目目录、确定唯一权威路径并填写 PROJECT_ID 后，人工/项目负责人将映射状态改为 `CONFIRMED`，才允许写入项目记录。

```bash
# 初始化项目 .ai/ 与 PROPOSED 映射（不创建业务目录）
python .ai/tools/init_cognition.py <项目根目录>

# 在映射 CONFIRMED 后创建任务记录，位置由 task_root 决定；创建时要求Git工作区干净（自动排除映射任务记录目录），并捕获当前HEAD到 `GIT_BASELINE.json` 与 `TASK_ANCHOR.md`。可用 `--base-commit <SHA>` 显式指定，但必须等于当前HEAD
python .ai/tools/create_task.py <项目根目录> --task-id <TASK_ID> --baseline-id <BASELINE_ID> --title "当前任务"
python .ai/tools/validate_cognition.py <项目根目录> --mode task --task-id <TASK_ID>

# Git 变更范围检查：始终使用创建任务时固定的 GIT_BASELINE.json，不允许用当前 HEAD 替代
python .ai/tools/detect_drift.py <项目根目录> --task-id <TASK_ID>

# 已验证文件快照：按映射写入测试报告目录下的版本化快照，不覆盖旧基线
python .ai/tools/protect_verified.py snapshot <项目根目录> --baseline-id <BASELINE_ID> --files program/src/a.c
python .ai/tools/protect_verified.py check <项目根目录> --baseline-id <BASELINE_ID>

# 创建不可覆盖的任务级检查点
python .ai/tools/checkpoint.py <项目根目录> --task-id <TASK_ID>
python .ai/tools/validate_cognition.py <项目根目录> --mode checkpoint --task-id <TASK_ID>

# 生成节点总结，按类型写入V1.20映射目录并追加知识索引
python .ai/tools/generate_summary.py stage --root <项目根目录> --task-id <TASK_ID>
python .ai/tools/generate_summary.py technical --root <项目根目录> --task-id <TASK_ID>
python .ai/tools/generate_summary.py issue --root <项目根目录> --task-id <TASK_ID>
python .ai/tools/generate_summary.py change --root <项目根目录> --task-id <TASK_ID>
python .ai/tools/generate_summary.py milestone --root <项目根目录> --task-id <TASK_ID>
python .ai/tools/generate_summary.py retro --root <项目根目录> --task-id <TASK_ID>
```

固定基线规则：`create_task.py`在任务创建时要求Git工作区干净（任务记录根目录除外），并记录完整 Git Commit SHA；若工作区有其他未提交改动，工具会拒绝创建任务且不会修改这些文件。`detect_drift.py`比较该固定提交到当前工作树的所有变化，包括后续提交、暂存、未暂存和未跟踪文件。当前 HEAD 必须是基线提交的后代；基线缺失、被篡改、仓库根目录变化或历史不兼容时必须 BLOCKED/UNAVAILABLE。禁止传入 `--base HEAD` 覆盖任务基线。任务记录根目录中的控制文档不作为产品源码路径偏离项，但仍需按任务ID隔离并保护。Git路径列表使用NUL分隔，避免中文、空格或换行文件名造成路径解析错位。

边界：所有项目记录工具必须使用项目根目录 `.ai/COGNITION_STORAGE_MAP.json` 中 `CONFIRMED` 的实际映射；`PROPOSED`/`NEEDS_REVIEW`、映射缺失或项目ID未确认时必须 BLOCKED，不得回退写入约束包 `.ai/.ai-engineering/`。哈希快照只检测字节变化，不证明功能正确；检查点和总结初始均为DRAFT，必须由AI依据真实项目文件和测试证据补齐后才能验收。任务级记录按TASK_ID隔离，项目级决策/事实/验证基线存放在V1.20对应项目目录。

### RC2.2开发者工作流验收

```bash
python .ai/tools/test_l0_rc22.py
python .ai/tools/test_l0_rc2.py
python .ai/tools/test_validators.py
python .ai/tools/validate_package.py
```

`detect_drift.py`将Git变化分为产品源码/配置路径和V1.20映射研发记录路径；映射记录单独列示，不代替对源码范围的检查。输入锁定验证必须在原项目根目录执行；任务级清单必须同时提供`--task-id`。
