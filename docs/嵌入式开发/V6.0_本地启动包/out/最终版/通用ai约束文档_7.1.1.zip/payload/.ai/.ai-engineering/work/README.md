# 任务记录存放规则（模板与工具说明）

本目录不作为项目任务记录的默认存放位置。项目真实任务记录必须遵循 `.ai/.ai-engineering/project-framework/项目目录框架_V1.20.md` 和 `L0认知记录与研发资料存储映射.md`。

## 权威位置

- 默认任务记录根目录：`项目管理/项目状态报告/任务记录/<TASK_ID>/`
- 已有项目可使用 `.ai/COGNITION_STORAGE_MAP.json` 中经实际盘点确认的等效路径。
- `.ai/.ai-engineering/templates/`只保存空白模板；`.ai/.ai-engineering/tools/`只保存通用工具。
- 不得使用全局单文件 TASK_ANCHOR 或 CONTEXT_CHECKPOINT 承载多个任务。

## 标准任务记录

- `TASK_ANCHOR.md`：本任务目标、范围、验收标准及任务创建时的`GIT_BASE_COMMIT`。
- `GIT_BASELINE.json`：任务创建时固定的Git Commit、项目/任务身份、仓库根目录和干净工作区状态；不可用当前HEAD覆盖。
- `STATE_CARD.md`、`STARTUP_RECEIPT.md`、`PROJECT_DISCOVERY_REPORT.md`：启动与项目识别记录。
- `INPUT_LOCK.md`：输入锁定摘要。
- `TASK_PLAN.md`：任务计划。
- `STATUS.md`、`STATE_HISTORY.csv`：状态和追加历史。
- `STAGE_GATES/`：阶段门禁。
- `CHANGE_IMPACT.md`、`TEST_EVIDENCE.md`：按需创建的影响和验证记录。
- `CONTEXT_CHECKPOINTS/`：不可覆盖的多版本检查点。
- `HANDOFF.md`：本任务交接。
- `evidence/`：任务原始证据索引或按映射目录的相对引用；原始测试报告仍以 `测试/测试报告/<TASK_ID>/` 为权威位置。

## 创建前提

必须先确认项目 `.ai/COGNITION_STORAGE_MAP.json` 为 `CONFIRMED`，且 `project_id` 已填写。`PROPOSED` 或 `NEEDS_REVIEW` 时只允许只读盘点和映射完善，不得写入正式任务记录。
