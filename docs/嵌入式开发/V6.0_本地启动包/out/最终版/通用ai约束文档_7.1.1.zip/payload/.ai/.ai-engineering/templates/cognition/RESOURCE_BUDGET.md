# 任务资源预算
- PROJECT_ID: TODO
- TASK_ID: TODO
- 分析/Token预算: TODO
- 工具调用预算: TODO
- 构建/测试预算: TODO
- 重试阈值: TODO
- 已消耗: TODO
- 超预算处理: 停止重复动作、总结现状、申请调整或缩小范围
