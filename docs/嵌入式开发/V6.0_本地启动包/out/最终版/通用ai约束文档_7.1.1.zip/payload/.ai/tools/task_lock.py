#!/usr/bin/env python3
"""Advisory atomic single-writer lock; inspect requires no session."""
from pathlib import Path
import argparse,json,os,sys,datetime,socket,getpass
p=argparse.ArgumentParser();p.add_argument("action",choices=["acquire","release","inspect"]);p.add_argument("task_dir");p.add_argument("--session");a=p.parse_args();root=Path(a.task_dir).resolve();root.mkdir(parents=True,exist_ok=True);lock=root/"TASK_LOCK.json"
if a.action=="inspect":
 if not lock.exists():print("UNLOCKED");sys.exit(0)
 try:print(json.dumps(json.loads(lock.read_text(encoding="utf-8")),ensure_ascii=False,indent=2))
 except Exception as e:print("LOCK_CORRUPT:",e);sys.exit(4)
 sys.exit(0)
if not a.session:p.error("--session is required for acquire/release")
if a.action=="acquire":
 data={"host":socket.gethostname(),"user":getpass.getuser(),"session":a.session,"pid":os.getpid(),"acquired_at":datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
  with os.fdopen(fd,"w",encoding="utf-8") as f:json.dump(data,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
  print("LOCK_ACQUIRED");sys.exit(0)
 except FileExistsError:print("LOCK_HELD: stale locks require explicit human review");sys.exit(2)
if a.action=="release":
 if not lock.exists():print("ALREADY_UNLOCKED");sys.exit(0)
 try:data=json.loads(lock.read_text(encoding="utf-8"))
 except Exception as e:print("REFUSED: corrupt lock",e);sys.exit(4)
 if data.get("session")!=a.session:print("REFUSED: session does not own lock");sys.exit(3)
 lock.unlink();print("LOCK_RELEASED")
