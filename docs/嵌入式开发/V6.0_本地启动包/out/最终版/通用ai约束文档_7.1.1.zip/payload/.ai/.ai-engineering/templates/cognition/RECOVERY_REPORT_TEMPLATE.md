# 会话/任务恢复报告
- PROJECT_ID/TASK_ID/BASELINE_ID: TODO
- CHECKPOINT_ID/HANDOFF版本: TODO
- 恢复时间与AI工具: TODO

## 重新核验
- 工作区/Git状态: TODO
- 输入哈希: TODO
- 工具链/构建配置: TODO
- 任务锁/并发状态: TODO
- 用户授权边界: TODO
- 关键事实回源结果: TODO

## 过期、冲突或丢失信息
TODO

## 已恢复的有效状态
TODO

## 不得自动重放的动作
TODO

## 下一步最小动作
TODO
