#!/usr/bin/env python3
"""Check gate records for required fields and legal result states."""
from pathlib import Path
import argparse,re,sys
p=argparse.ArgumentParser();p.add_argument('task_dir');a=p.parse_args();r=Path(a.task_dir).resolve();errs=[];g=list((r/'STAGE_GATES').glob('*.md')) if (r/'STAGE_GATES').exists() else []
if not g:errs.append('NO_STAGE_GATE_RECORDS')
for f in g:
 t=f.read_text(encoding='utf-8')
 for label in ['阶段目标','输入及版本','实际执行动作','验证命令/工具版本','原始证据路径','结果']:
  m=re.search(rf'^-[ \t]*{re.escape(label)}[：:][ \t]*(.*)$',t,re.M)
  if not m or m.group(1).strip() in {'','待填写','TODO','-'}:errs.append(f'{f.name}:EMPTY:{label}')
 if not re.search(r'结果[：:]\s*(PASS|FAIL|BLOCKED|BLOCKED_BY_AUTH|NOT_RUN|UNAVAILABLE|NOT_APPLICABLE)',t):errs.append(f'{f.name}:INVALID_RESULT')
if errs:print('FAIL');print('\\n'.join(errs));sys.exit(1)
print(f'PASS: {len(g)} stage gate records structurally valid; technical correctness requires review.')
