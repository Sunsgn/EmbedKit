#!/usr/bin/env python3
"""Static transition checks; real merge behavior is tested by system/tests/test_bootstrap.py."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
AI = Path(__file__).resolve().parents[1]
checks = []

def check(ok, label):
    checks.append((label, bool(ok)))

for name in ("AGENTS.md", "CLAUDE.md", "GEMINI.md"):
    check((ROOT / name).is_file(), f"root {name} is present")
check((ROOT / ".github/copilot-instructions.md").is_file(), "standard Copilot entry is present")

bootstrap = (AI / "system/bootstrap.py").read_text(encoding="utf-8")
entry = (AI / "system/ENTRYPOINT.md").read_text(encoding="utf-8")
state = json.loads((AI / "INSTALL_STATE.json").read_text(encoding="utf-8"))

check("BEGIN_MARKER" in bootstrap and "END_MARKER" in bootstrap, "bootstrap uses managed entrypoint blocks")
check("INSTALL_PLAN_STALE" in bootstrap, "bootstrap detects changes after planning")
check("REPLACE_PACKAGE_OWNED" in bootstrap, "bootstrap replaces only proven package-owned files")
check("TARGET_EXISTS_WITH_UNKNOWN_CONTENT" in bootstrap, "unknown existing content becomes conflict")
check("ROLLING_BACK" in bootstrap and "NEEDS_REVIEW" in bootstrap, "rollback and review states exist")
check("PACKAGE_COMPRESSION_RATIO_LIMIT" in bootstrap, "ZIP resource limits exist")
check("legacy_owned_hashes" in bootstrap, "legacy ownership requires manifest verification")
check("7.0.0-alpha.1" in entry, "entrypoint declares phase and version boundary")
check(state.get("status") == "INSTALLED", "installed transaction committed")
check(len(state.get("managed_entrypoints", [])) == 4, "four client entrypoints are managed")

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(("PASS" if ok else "FAIL") + " | " + label)
if failed:
    print(f"FAILED: {len(failed)}/{len(checks)}")
    sys.exit(1)
print(f"PASS: phase-1 static transition checks ({len(checks)}/{len(checks)} checks)")
