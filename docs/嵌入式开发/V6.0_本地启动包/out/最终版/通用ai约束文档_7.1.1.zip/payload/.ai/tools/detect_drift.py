#!/usr/bin/env python3
"""Compare a task's working tree against its immutable task-creation Git baseline."""
from pathlib import Path
import argparse, json, re, subprocess, sys, fnmatch
sys.dont_write_bytecode = True
from storage_map import task_dir, MapError

def git(root, *args):
    return subprocess.run(
        ["git", "-C", str(root), "-c", "core.quotepath=false", *args],
        capture_output=True, text=True, encoding="utf-8", errors="replace"
    )

def git_paths(root, *args):
    return subprocess.run(
        ["git", "-C", str(root), *args],
        capture_output=True
    )

parser = argparse.ArgumentParser(
    description="Check changed paths against TASK_ANCHOR scope, using GIT_BASELINE.json captured at task creation."
)
parser.add_argument("project_root", nargs="?", default=".")
parser.add_argument("--task-id", required=True)
parser.add_argument("--anchor", default="")
args = parser.parse_args()
root = Path(args.project_root).resolve()

try:
    task_path, mapping = task_dir(root, args.task_id)
except MapError as exc:
    print("BLOCKED:", exc)
    sys.exit(2)

anchor = Path(args.anchor).resolve() if args.anchor else task_path / "TASK_ANCHOR.md"
if not anchor.is_file() or not anchor.resolve().is_relative_to(task_path.resolve()):
    print("BLOCKED: TASK_ANCHOR missing or outside task directory:", anchor)
    sys.exit(2)
anchor_text = anchor.read_text(encoding="utf-8")
scope_match = re.search(r"^[ \t]*-[ \t]*允许修改范围[ \t]*[:：][ \t]*(.*)$", anchor_text, re.M)
if not scope_match or scope_match.group(1).strip() in {"", "TODO", "待填写", "待确认"}:
    print("BLOCKED: allowed modification scope is undefined")
    sys.exit(2)
rules = [
    item.strip().strip("`").strip('"').strip("'")
    for item in re.split(r"[;；,，\n]", scope_match.group(1))
    if item.strip()
]
if not rules:
    print("BLOCKED: no usable allowed-scope rules")
    sys.exit(2)
for rule in rules:
    normalized_rule = rule.replace("\\", "/").strip()
    if (normalized_rule.startswith("/") or re.match(r"^[A-Za-z]:", normalized_rule)
            or any(part == ".." for part in normalized_rule.split("/"))):
        print("BLOCKED: unsafe allowed-scope rule:", rule)
        sys.exit(2)

baseline_file = task_path / "GIT_BASELINE.json"
if baseline_file.is_symlink() or not baseline_file.resolve(strict=False).is_relative_to(task_path.resolve()):
    print("BLOCKED: GIT_BASELINE.json symlink/path escape")
    sys.exit(2)
if not baseline_file.is_file():
    print("BLOCKED: GIT_BASELINE.json missing; recreate/repair task baseline under owner approval")
    sys.exit(2)
try:
    baseline = json.loads(baseline_file.read_text(encoding="utf-8"))
except Exception as exc:
    print("BLOCKED: invalid GIT_BASELINE.json:", exc)
    sys.exit(2)

if baseline.get("project_id") != mapping["project_id"] or baseline.get("task_id") != args.task_id:
    print("BLOCKED: Git baseline identity mismatch")
    sys.exit(2)
if baseline.get("status") != "CAPTURED" or baseline.get("working_tree_clean") is not True:
    print("BLOCKED: Git baseline was not captured from a clean worktree:",
          baseline.get("reason") or baseline.get("status"))
    sys.exit(2)

base_commit = baseline.get("commit")
if not isinstance(base_commit, str) or not re.fullmatch(r"[0-9a-f]{40,64}", base_commit):
    print("BLOCKED: invalid or missing full Git commit SHA in GIT_BASELINE.json")
    sys.exit(2)
anchor_commit = re.search(r"^[ \t]*-[ \t]*GIT_BASE_COMMIT[ \t]*[:：][ \t]*(.*)$", anchor_text, re.M)
if not anchor_commit or anchor_commit.group(1).strip().lower() != base_commit:
    print("BLOCKED: TASK_ANCHOR GIT_BASE_COMMIT does not match GIT_BASELINE.json")
    sys.exit(2)

repo_probe = git(root, "rev-parse", "--show-toplevel")
if repo_probe.returncode != 0:
    print("UNAVAILABLE: current project directory is not inside a Git repository")
    sys.exit(3)
current_repo_root = Path(repo_probe.stdout.strip()).resolve()
recorded_repo_root = baseline.get("repository_root")
if recorded_repo_root and current_repo_root != Path(recorded_repo_root).resolve():
    print("BLOCKED: Git repository root differs from task-creation baseline")
    print("RECORDED:", recorded_repo_root)
    print("CURRENT:", current_repo_root)
    sys.exit(2)

commit_probe = git(root, "cat-file", "-e", f"{base_commit}^{{commit}}")
if commit_probe.returncode != 0:
    print("BLOCKED: recorded Git base commit is unavailable in this repository")
    sys.exit(2)
head_probe = git(root, "rev-parse", "--verify", "HEAD^{commit}")
if head_probe.returncode != 0:
    print("UNAVAILABLE: current Git HEAD cannot be resolved")
    sys.exit(3)
head_commit = head_probe.stdout.strip().lower()
ancestor = git(root, "merge-base", "--is-ancestor", base_commit, head_commit)
if ancestor.returncode != 0:
    print("BLOCKED: current HEAD is not a descendant of the recorded task baseline")
    print("BASELINE:", base_commit)
    print("HEAD:", head_commit)
    sys.exit(2)

# `git diff <base> --` compares the captured commit with the current working tree,
# including later commits, staged changes, and unstaged tracked changes.
# Run path-list commands from the repository root so every returned path uses
# the same coordinate system as mapped V1.20 paths and project_rel.
diff = git_paths(current_repo_root, "diff", "--name-only", "-z", "--diff-filter=ACDMRTUXB", base_commit, "--")
cached = git_paths(current_repo_root, "diff", "--cached", "--name-only", "-z", "--diff-filter=ACDMRTUXB", base_commit, "--")
untracked = git_paths(current_repo_root, "ls-files", "--others", "--exclude-standard", "-z")
if diff.returncode != 0 or cached.returncode != 0 or untracked.returncode != 0:
    print("UNAVAILABLE: Git change comparison failed")
    detail = (diff.stderr or cached.stderr or untracked.stderr).decode("utf-8", "replace").strip()
    print(detail)
    sys.exit(3)

raw_paths = diff.stdout.split(b"\0") + cached.stdout.split(b"\0") + untracked.stdout.split(b"\0")
changed = sorted(set(
    item.decode("utf-8", "surrogateescape").replace("\\", "/")
    for item in raw_paths if item
))
# V1.20 mapped records are metadata, not product-source changes. Keep them
# visible in the report, but do not compare them against the code-only scope.
# Only exact mapped files and mapped directory roots are classified as metadata.
from storage_map import resolve
DIRECTORY_KEYS = {
    "task_root", "issue_records", "technical_knowledge", "development_records",
    "test_evidence", "change_records", "change_verification", "milestones",
    "retrospectives", "stage_reviews", "release_docs", "release_artifacts"
}
METADATA_KEYS = [
    "profile", "project_facts", "environment_baseline", "task_root",
    "decision_ledger", "failed_approaches", "risk_register", "conflict_register",
    "issue_records", "technical_knowledge", "development_records",
    "verified_features", "regression_baseline", "test_evidence",
    "change_records", "change_verification", "milestones", "retrospectives",
    "stage_reviews", "release_docs", "release_artifacts", "knowledge_index"
]
metadata_rules = []
try:
    for key in METADATA_KEYS:
        if key not in mapping.get("paths", {}):
            continue
        mapped_path, _ = resolve(root, key)
        rel = mapped_path.resolve(strict=False).relative_to(current_repo_root).as_posix().rstrip("/")
        metadata_rules.append((rel, key in DIRECTORY_KEYS, key))
except (MapError, ValueError) as exc:
    print("BLOCKED: invalid V1.20 metadata mapping:", exc)
    sys.exit(2)

def is_mapped_metadata(path):
    for rel, is_dir, key in metadata_rules:
        if path == rel or (is_dir and path.startswith(rel + "/")):
            return key
    return None

metadata_paths = []
product_paths = []
for path in changed:
    key = is_mapped_metadata(path)
    if key:
        metadata_paths.append((path, key))
    else:
        product_paths.append(path)

try:
    project_rel_raw = root.resolve().relative_to(current_repo_root).as_posix()
    project_rel = "" if project_rel_raw == "." else project_rel_raw.strip("/")
except ValueError:
    print("BLOCKED: project root is outside the current Git repository")
    sys.exit(2)

def matches_one(path, rule):
    if rule.endswith("/"):
        return path.startswith(rule)
    if any(ch in rule for ch in "*?["):
        return fnmatch.fnmatchcase(path, rule)
    return path == rule or path.startswith(rule.rstrip("/") + "/")

def matches(path, rule):
    rule = rule.replace("\\", "/").strip().rstrip("/")
    if not rule or rule.startswith("/") or re.match(r"^[A-Za-z]:", rule) or any(part == ".." for part in rule.split("/")):
        return False
    candidates = [rule]
    if project_rel:
        candidates.append(project_rel + "/" + rule)
    return any(matches_one(path, candidate) for candidate in candidates)

outside = [path for path in product_paths if not any(matches(path, rule) for rule in rules)]
print("PROJECT_ID:", mapping["project_id"])
print("TASK_ID:", args.task_id)
print("PROJECT_RELATIVE_PATH:", project_rel or ".")
print("BASELINE_COMMIT:", base_commit)
print("CURRENT_HEAD:", head_commit)
print("CHANGED_PATHS:", len(changed))
print("PRODUCT_PATHS:", len(product_paths))
for item in product_paths:
    print("  PRODUCT:", item)
print("MAPPED_METADATA_PATHS:", len(metadata_paths))
for item, key in metadata_paths:
    print(f"  METADATA[{key}]:", item)

if outside:
    print("FAIL: changed paths outside declared task scope:")
    for item in outside:
        print(" ", item)
    sys.exit(1)

print("PASS: all product/source paths are within declared task scope; mapped V1.20 metadata paths are separately classified.")
print("LIMITATION: path-scope detection does not judge semantic drift or functional correctness; independent review remains required.")
