# V6.0结构升级迁移

## 适用范围

用于从结构版本1升级到结构版本2。升级前必须检查用户修改并建立Git检查点或可恢复备份。

| 旧路径 | 新路径 | 处理 |
|---|---|---|
| `rules/` | `.ai/.ai-engineering/rules/` | 整目录迁移，用户修改需三方合并 |
| `disciplines/` | `.ai/.ai-engineering/disciplines/` | 整目录迁移 |
| `project/` | `.ai/.ai-engineering/project/` | 项目事实必须保留，不得用模板覆盖 |
| `project-framework/` | `.ai/.ai-engineering/project-framework/` | 使用路径适配后的完整V1.20 |
| `workflows/` | `.ai/.ai-engineering/workflows/` | 整目录迁移 |
| `templates/` | `.ai/.ai-engineering/templates/` | 整目录迁移并新增AI加载回执 |
| `work/` | `.ai/.ai-engineering/work/` | 保留所有历史任务和证据索引 |
| `installation/` | `.ai/.ai-engineering/installation/` | 替换为结构版本2说明 |
| `RULES_INDEX.md`、`VERSION.md` | `.ai/.ai-engineering/` | 更新入口引用 |

`.ai/AGENTS.md`、`CLAUDE.md`、`GEMINI.md`、`AI-INSTRUCTIONS.md`、`README.md`和`.ai/.github/copilot-instructions.md`采用三方合并，不直接覆盖。

## 语义变化

- 专业选择初始状态由“默认软件”改为`UNINITIALIZED`。
- 专业Profile由可选改为任务命中后必读；真实工具任务必读`TOOL_CAPABILITIES.md`。
- 正式审核、测试、放行和跨AI交接即使无文件修改也必须建立任务记录。
- 一个主工作流允许追加必要交接工作流。
- 最终状态统一增加`BLOCKED_BY_AUTH`；PCB阶段统一为六级。
- 新增系统、机械热可靠性、生产校准、安全合规、供应链与现场维护专业。

## 升级验收

1. 根目录不存在旧版散落的`rules/`、`project/`等规范目录；真实业务同名目录不得移动。
2. 所有入口只指向`.ai/.ai-engineering/`。
3. 本文件描述的是早期结构版本升级历史，不作为当前V1.20目录规范依据。当前项目根目录`.ai/PROJECT_PROFILE.md`与`.ai/项目目录框架.md`是V1.20规定的有效路径，必须保留并按当前存储映射使用。
4. 项目Profile及历史任务记录按当前项目存储映射核对数量、大小及哈希；不得把历史任务记录迁入约束包的`.ai/.ai-engineering/work/`作为项目权威记录。
5. 使用至少一个软件任务和一个非软件任务生成AI加载回执，验证专业路由。
