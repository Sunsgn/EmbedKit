#!/usr/bin/env python3
"""20 deterministic positive/negative tests for V6.1.2 RC2 validators."""
from pathlib import Path
import tempfile,subprocess,sys,hashlib,runpy,contextlib,io
HERE=Path(__file__).resolve().parent
results=[]
def run(script,*args):
 old=sys.argv[:]; out=io.StringIO(); err=io.StringIO(); sys.path.insert(0,str(HERE))
 try:
  sys.modules.pop("storage_map",None)
  sys.argv=[str(HERE/script),*map(str,args)]
  with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
   try: runpy.run_path(str(HERE/script),run_name="__main__"); code=0
   except SystemExit as e: code=e.code if isinstance(e.code,int) else 0
  class Result: pass
  r=Result();r.returncode=code;r.stdout=out.getvalue();r.stderr=err.getvalue();return r
 finally:sys.argv=old
def check(name,ok,detail=''): results.append((name,bool(ok),detail.strip().replace('\n','; ')[:220]))
with tempfile.TemporaryDirectory() as td:
 r=Path(td)/'T-1';r.mkdir();(r/'STAGE_GATES').mkdir();(r/'evidence').mkdir()
 for n in ['STATE_CARD.md','STARTUP_RECEIPT.md','PROJECT_DISCOVERY_REPORT.md','INPUT_LOCK.md','TASK_PLAN.md','DECISIONS.md','HANDOFF.md']:(r/n).write_text('# template\n',encoding='utf-8')
 (r/'STATUS.md').write_text('# 状态\n- 生命周期：NEW\n- 任务ID：T-1\n',encoding='utf-8')
 (r/'STATE_HISTORY.csv').write_text('timestamp,from_state,to_state,reason,gate_ref,session_id\n',encoding='utf-8')
 x=run('validate_task.py',r,'--mode','acceptance');check('T01 blank task rejected',x.returncode!=0,x.stdout+x.stderr)
 x=run('validate_task.py',r,'--mode','structure');check('T02 structure mode accepts structure-only NEW task',x.returncode==0,x.stdout+x.stderr)
 (r/'STATUS.md').write_text('# 状态\n- 生命周期：ALIEN\n- 任务ID：T-1\n',encoding='utf-8')
 x=run('validate_task.py',r);check('T03 invalid lifecycle rejected',x.returncode!=0,x.stdout+x.stderr)
 (r/'STATUS.md').write_text('# 状态\n- 生命周期：PLANNED\n- 任务ID：T-1\n',encoding='utf-8')
 # Populate required acceptance fields so subsequent state tests exercise history rules, not blank-template rules.
 vals={'STATE_CARD.md':['任务ID：T-1','用户需求原文/目标：test request','任务等级：STANDARD','主专业及交叉专业：SOFTWARE','本次验收目标：compile'],'STARTUP_RECEIPT.md':['任务ID：T-1','实际工作目录：/tmp/task','已读取通用规则及版本：rules 00-10','允许执行范围：project dir'],'PROJECT_DISCOVERY_REPORT.md':['项目路径：/tmp/task','工程类型及证据：CMakeLists.txt','扫描范围/排除范围：root only'],'INPUT_LOCK.md':['任务ID：T-1','锁定时间：2026-01-01','项目根目录：/tmp/task','哈希算法：SHA-256'],'TASK_PLAN.md':['任务目标：test','验收标准：build pass','阶段计划：discover then build']}
 for fn,lines in vals.items():(r/fn).write_text('# Filled\n'+'\n'.join('- '+x for x in lines)+'\n',encoding='utf-8')
 (r/'STATE_HISTORY.csv').write_text('timestamp,from_state,to_state,reason,gate_ref,session_id\n2026-01-01,NEW,CLOSED,skip,,S1\n',encoding='utf-8')
 x=run('validate_task.py',r,'--mode','acceptance');check('T04 illegal transition rejected',x.returncode!=0,x.stdout+x.stderr)
 (r/'STATE_HISTORY.csv').write_text('timestamp,from_state,to_state,reason,gate_ref,session_id\n2026-01-01,NEW,DISCOVERING,start,,S1\n',encoding='utf-8')
 x=run('validate_task.py',r,'--mode','acceptance');check('T05 STATUS/history mismatch rejected',x.returncode!=0,x.stdout+x.stderr)
 # Handoff missing fields
 h=r/'HANDOFF.md';h.write_text('# blank\n',encoding='utf-8');x=run('validate_handoff.py',h,'--task-root',r);check('T06 blank handoff rejected',x.returncode!=0,x.stdout+x.stderr)
 fields={'任务ID/目标':'T-1 test','规范包版本/结构版本':'6.1.2-RC2/6','当前生命周期/阶段':'VERIFYING','当前结论/结果状态':'PASS','已完成修改及文件身份':'src.c SHA256 abc','已验证内容/命令/工具版本':'执行命令 python test.py；Python 3.13工具版本','证据索引（相对任务目录路径）':'evidence/proof.txt','未执行/不可用/阻塞':'无未执行项','输入锁定ID/清单路径/变化':'lock-1 INPUT_LOCK.md无变化','工作区/Git状态':'git clean','当前授权边界':'项目目录内修改','下一步最小动作':'人工审阅','不得自动重放的动作':'不得自动烧录'}
 h.write_text('# Handoff\n'+'\n'.join(f'- {k}：{v}' for k,v in fields.items())+'\n',encoding='utf-8')
 x=run('validate_handoff.py',h,'--task-root',r);check('T07 PASS without evidence rejected',x.returncode!=0,x.stdout+x.stderr)
 (r/'evidence/proof.txt').write_text('synthetic evidence',encoding='utf-8');x=run('validate_handoff.py',h,'--task-root',r);check('T08 evidence path accepted structurally',x.returncode==0,x.stdout+x.stderr)
 fields['证据索引（相对任务目录路径）']='evidence/../../outside.txt';h.write_text('# Handoff\n'+'\n'.join(f'- {k}：{v}' for k,v in fields.items())+'\n',encoding='utf-8');x=run('validate_handoff.py',h,'--task-root',r);check('T09 evidence path traversal rejected',x.returncode!=0,x.stdout+x.stderr)
 fields['证据索引（相对任务目录路径）']='evidence/empty.txt';(r/'evidence/empty.txt').write_text('',encoding='utf-8');h.write_text('# Handoff\n'+'\n'.join(f'- {k}：{v}' for k,v in fields.items())+'\n',encoding='utf-8');x=run('validate_handoff.py',h,'--task-root',r);check('T10 empty evidence rejected',x.returncode!=0,x.stdout+x.stderr)
 x=run('task_lock.py','inspect',r);check('T11 inspect needs no session',x.returncode==0,x.stdout+x.stderr)
 x=run('task_lock.py','acquire',r,'--session','A');check('T12 lock acquired',x.returncode==0,x.stdout+x.stderr)
 x=run('task_lock.py','acquire',r,'--session','B');check('T13 second session refused',x.returncode==2,x.stdout+x.stderr)
 x=run('task_lock.py','release',r,'--session','B');check('T14 non-owner release refused',x.returncode==3,x.stdout+x.stderr)
 x=run('task_lock.py','release',r,'--session','A');check('T15 owner release succeeds',x.returncode==0,x.stdout+x.stderr)
 doc=r/'doc.md';doc.write_text('# Test\n## 1. A\n## 1. B\n',encoding='utf-8');x=run('validate_document_structure.py',doc);check('T16 duplicate chapter rejected',x.returncode!=0,x.stdout+x.stderr)
 doc.write_text('# Test\n## 1. A\n## 2. B\n',encoding='utf-8');x=run('validate_document_structure.py',doc);check('T17 unique chapters accepted',x.returncode==0,x.stdout+x.stderr)
 disc=r/'discipline.md';disc.write_text('# D\n适用范围 输入 原理 设计方法 计算 工具 诊断 整改 验收 案例\n',encoding='utf-8');x=run('validate_discipline.py',disc);check('T18 ten dimensions structurally accepted',x.returncode==0,x.stdout+x.stderr)
 disc.write_text('# D\n适用范围 输入\n',encoding='utf-8');x=run('validate_discipline.py',disc);check('T19 incomplete discipline rejected',x.returncode!=0,x.stdout+x.stderr)
 gate=r/'STAGE_GATES/gate.md';gate.write_text('- 阶段目标：x\n- 输入及版本：x\n- 实际执行动作：x\n- 验证命令/工具版本：x\n- 原始证据路径：x\n- 结果：PASS\n',encoding='utf-8');x=run('validate_gates.py',r);check('T20 complete gate accepted',x.returncode==0,x.stdout+x.stderr)
print('TOTAL',len(results),'PASS',sum(x[1] for x in results),'FAIL',sum(not x[1] for x in results))
for n,ok,d in results: print(('PASS' if ok else 'FAIL')+' | '+n+' | '+d)
sys.exit(1 if any(not x[1] for x in results) else 0)
