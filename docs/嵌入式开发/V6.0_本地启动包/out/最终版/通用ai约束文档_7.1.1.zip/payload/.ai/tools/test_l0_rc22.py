#!/usr/bin/env python3
"""RC2.2 developer workflow regressions: task creation, scope, V1.20 metadata and input identity."""
from pathlib import Path
import tempfile, shutil, subprocess, sys, json, os, re

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / "tools"
ENV = os.environ.copy()
ENV.pop("PYTHONDONTWRITEBYTECODE", None)
# The package's test runner must not inherit notebook-host artifact warmup hooks.
for _key in ("CUA_DD_PYTHON_TOOL_WARM_SPREADSHEET_RUNTIME",
             "CUA_DD_INIT_ARTIFACT_TOOL_V2_RECORD_OPERATIONS",
             "CUA_DD_INIT_ARTIFACT_TOOL_V2", "CUA_DD_PYTHON_TOOL"):
    ENV.pop(_key, None)

def check(ok, message):
    if not ok:
        raise AssertionError(message)

def run(script, *args, cwd=None, env=None):
    return subprocess.run(
        [sys.executable, str(TOOLS / script), *map(str, args)],
        cwd=cwd, text=True, capture_output=True, env=env or ENV
    )

def git(root, *args):
    return subprocess.run(
        ["git", "-C", str(root), *args],
        cwd=root, text=True, capture_output=True, encoding="utf-8", errors="replace"
    )

def set_field(path, label, value):
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(r"(?m)^([ \t]*[-*][ \t]*" + re.escape(label) + r"[ \t]*[:：])[ \t]*.*$")
    updated, count = pattern.subn(lambda m: m.group(1) + " " + value, text, count=1)
    check(count == 1, f"template field not found: {path.name}:{label}")
    path.write_text(updated, encoding="utf-8", newline="\n")

def make_project(root, repo_root=None):
    root.mkdir(parents=True, exist_ok=True)
    repo_root = Path(repo_root).resolve() if repo_root else root.resolve()
    repo_root.mkdir(parents=True, exist_ok=True)
    (root / ".ai").mkdir()
    mapping = json.loads((ROOT / ".ai-engineering/templates/project/COGNITION_STORAGE_MAP.json").read_text(encoding="utf-8"))
    mapping["project_id"] = "P-RC22-DEV"
    mapping["status"] = "CONFIRMED"
    (root / ".ai/COGNITION_STORAGE_MAP.json").write_text(
        json.dumps(mapping, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    (root / ".ai/PROJECT_PROFILE.md").write_text("# RC2.2 developer test\n", encoding="utf-8")
    for folder in [
        "项目管理/项目状态报告/任务记录", "项目管理/会议与决策", "项目管理/风险与问题",
        "开发文档/技术文档", "开发文档/开发记录", "测试/测试计划", "测试/测试报告",
        "配置与变更管理/ECO工程变更", "配置与变更管理/变更验证",
        "项目管理/计划与里程碑", "项目管理/项目状态报告/复盘", "阶段评审", "release"
    ]:
        (root / folder).mkdir(parents=True, exist_ok=True)
    (root / "program").mkdir()
    (root / "program/main.c").write_text("int main(void) { return 0; }\n", encoding="utf-8")
    for args in [
        ("init", "-q"), ("config", "user.name", "RC22 Developer"),
        ("config", "user.email", "rc22@example.invalid"), ("add", "."),
        ("commit", "-qm", "clean project baseline")
    ]:
        result = git(repo_root, *args)
        check(result.returncode == 0, f"git {args} failed: {result.stderr}")
    return mapping

def main():
    tmp = Path(tempfile.mkdtemp(prefix="rc22-developer-"))
    try:
        project = tmp / "project"
        mapping = make_project(project)
        baseline_commit = git(project, "rev-parse", "HEAD").stdout.strip()

        # A normal `python tools/create_task.py` invocation must not create pycache and dirty the clean baseline.
        cache_dir = TOOLS / "__pycache__"
        if cache_dir.exists():
            shutil.rmtree(cache_dir)
        created = run("create_task.py", project, "--task-id", "T-DEV-001",
                      "--baseline-id", "BL-DEV-001", "--title", "A22 UART task analysis")
        check(created.returncode == 0, "normal task creation failed: " + created.stdout + created.stderr)
        check(not cache_dir.exists(), "create_task generated tools/__pycache__")
        task = project / mapping["paths"]["task_root"] / "T-DEV-001"
        anchor = task / "TASK_ANCHOR.md"
        for label, value in {
            "最终项目目标": "Complete developer workflow regression",
            "当前阶段目标": "Validate RC2.2 tooling",
            "允许修改范围": "program/",
            "验收标准": "All RC2.2 developer tests pass"
        }.items():
            set_field(anchor, label, value)
        required_files = [
            "TASK_ANCHOR.md", "STATE_CARD.md", "STARTUP_RECEIPT.md",
            "PROJECT_DISCOVERY_REPORT.md", "INPUT_LOCK.md", "TASK_PLAN.md",
            "STATUS.md", "STATE_HISTORY.csv", "HANDOFF.md", "DECISIONS.md",
            "GIT_BASELINE.json"
        ]
        missing = [name for name in required_files if not (task / name).is_file()]
        check(not missing, "task creator omitted required files: " + repr(missing))
        status = (task / "STATUS.md").read_text(encoding="utf-8")
        check(status.count("- 任务ID：") == 1 and "- 任务ID： T-DEV-001" in status,
              "STATUS template task ID is missing or duplicated")
        check("- 任务ID： T-DEV-001" in (task / "STATE_CARD.md").read_text(encoding="utf-8"),
              "STATE_CARD task ID was not prefilled")
        check("- 任务ID： T-DEV-001" in (task / "STARTUP_RECEIPT.md").read_text(encoding="utf-8"),
              "STARTUP_RECEIPT task ID was not prefilled")
        check("- 任务ID： T-DEV-001" in (task / "INPUT_LOCK.md").read_text(encoding="utf-8"),
              "INPUT_LOCK task ID was not prefilled")
        structure = run("validate_task.py", task, "--mode", "structure")
        check(structure.returncode == 0, "new task failed its own structure validator: " + structure.stdout)

        # Fill only the minimum acceptance fields and prove validator/template labels align.
        for filename, values in {
            "STATE_CARD.md": {
                "用户需求原文/目标": "A22 UART task analysis",
                "主专业及交叉专业": "Embedded software / FreeRTOS",
                "本次验收目标": "Task record acceptance"
            },
            "STARTUP_RECEIPT.md": {
                "已读取通用规则及版本": "RC2.2",
                "允许执行范围": "Read-only"
            },
            "PROJECT_DISCOVERY_REPORT.md": {
                "工程类型及证据": "C firmware project; source evidence",
                "扫描范围/排除范围": "program/; exclude build outputs"
            },
            "INPUT_LOCK.md": {
                "哈希算法": "SHA-256"
            },
            "TASK_PLAN.md": {
                "任务目标": "A22 UART task analysis",
                "验收标准": "Acceptance validator passes",
                "阶段计划": "Discover -> plan -> verify"
            }
        }.items():
            for label, value in values.items():
                set_field(task / filename, label, value)
        acceptance = run("validate_task.py", task, "--mode", "acceptance")
        check(acceptance.returncode == 0,
              "acceptance validator disagrees with its templates: " + acceptance.stdout)

        # Task-bound input lock: same root passes, copied project root is rejected.
        lock = task / "input-lock.json"
        locked = run("lock_inputs.py", project, "--task-id", "T-DEV-001",
                     "--baseline-id", "BL-DEV-001", "--output", lock,
                     "--include", "program/**")
        check(locked.returncode == 0, "task-bound input lock failed: " + locked.stdout + locked.stderr)
        verify = run("lock_inputs.py", project, "--task-id", "T-DEV-001",
                     "--output", lock, "--verify")
        check(verify.returncode == 0, "same-project input lock verify failed: " + verify.stdout)
        lock_original = lock.read_text(encoding="utf-8")
        legacy_data = json.loads(lock_original)
        legacy_data["schema_version"] = 2
        lock.write_text(json.dumps(legacy_data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        legacy_lock = run("lock_inputs.py", project, "--task-id", "T-DEV-001",
                          "--output", lock, "--verify")
        check(legacy_lock.returncode == 2 and "LEGACY_INPUT_LOCK_SCHEMA" in legacy_lock.stdout,
              "legacy input-lock schema was not rejected for regeneration: " + legacy_lock.stdout)
        lock.write_text(lock_original, encoding="utf-8")
        no_task = run("lock_inputs.py", project, "--output", lock, "--verify")
        check(no_task.returncode == 2 and "TASK_ID_MISMATCH" in no_task.stdout,
              "task-bound manifest verified without its task ID")
        wrong_baseline = run("lock_inputs.py", project, "--task-id", "T-DEV-001",
                             "--baseline-id", "WRONG-BASELINE", "--output", lock, "--verify")
        check(wrong_baseline.returncode == 2 and "BASELINE_ID does not match" in wrong_baseline.stdout,
              "input lock accepted a mismatched BASELINE_ID argument")
        map_file = project / ".ai/COGNITION_STORAGE_MAP.json"
        map_original = map_file.read_text(encoding="utf-8")
        changed_map = json.loads(map_original)
        changed_map["project_id"] = "P-WRONG-PROJECT"
        map_file.write_text(json.dumps(changed_map, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        wrong_project = run("lock_inputs.py", project, "--task-id", "T-DEV-001",
                            "--output", lock, "--verify")
        check(wrong_project.returncode == 2 and "TASK_GIT_BASELINE_IDENTITY_MISMATCH" in wrong_project.stdout,
              "input lock did not reject a changed PROJECT_ID")
        map_file.write_text(map_original, encoding="utf-8")
        baseline_file = task / "GIT_BASELINE.json"
        baseline_original = baseline_file.read_text(encoding="utf-8")
        baseline_data = json.loads(baseline_original)
        baseline_data["baseline_id"] = "TAMPERED-BASELINE"
        baseline_file.write_text(json.dumps(baseline_data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        tampered_baseline = run("lock_inputs.py", project, "--task-id", "T-DEV-001",
                                "--output", lock, "--verify")
        check(tampered_baseline.returncode == 2 and "TASK_BASELINE_CHANGED_SINCE_INPUT_LOCK" in tampered_baseline.stdout,
              "input lock failed to detect task baseline identity tampering")
        baseline_file.write_text(baseline_original, encoding="utf-8")
        clone = tmp / "project-clone"
        shutil.copytree(project, clone)
        clone_task = clone / mapping["paths"]["task_root"] / "T-DEV-001"
        clone_verify = run("lock_inputs.py", clone, "--task-id", "T-DEV-001",
                           "--output", clone_task / "input-lock.json", "--verify")
        check(clone_verify.returncode == 2 and "PROJECT_ROOT_MISMATCH" in clone_verify.stdout,
              "input lock was reusable from a different project root")

        # A byte change in a locked input must still be detected.
        with (project / "program/main.c").open("a", encoding="utf-8") as f:
            f.write("/* input-lock regression */\n")
        changed_lock = run("lock_inputs.py", project, "--task-id", "T-DEV-001",
                           "--output", lock, "--verify")
        check(changed_lock.returncode == 1 and "CHANGED: program/main.c" in changed_lock.stdout,
              "input lock did not detect changed source bytes")

        # Create allowed source changes plus mapped V1.20 development and test records.
        git(project, "add", "program/main.c")
        git(project, "commit", "-qm", "allowed source change")
        dev_record = project / mapping["paths"]["development_records"] / "stages" / "STAGE-001.md"
        dev_record.parent.mkdir(parents=True, exist_ok=True)
        dev_record.write_text("# Stage summary\n", encoding="utf-8")
        evidence = project / mapping["paths"]["test_evidence"] / "evidence.txt"
        evidence.parent.mkdir(parents=True, exist_ok=True)
        evidence.write_text("test evidence\n", encoding="utf-8")
        snapshot = run("protect_verified.py", "snapshot", project, "--baseline-id", "VERIFIED-001",
                       "--files", "program/main.c")
        check(snapshot.returncode == 0, "verified snapshot failed: " + snapshot.stdout)
        expected_snapshot = project / mapping["paths"]["test_evidence"] / "verified_file_baselines" / "VERIFIED-001.json"
        check(expected_snapshot.is_file(), "verified snapshot was written outside mapped test-evidence directory")
        # Unsafe scope paths must block rather than normalize into an unintended allowlist.
        anchor_text = (task / "TASK_ANCHOR.md").read_text(encoding="utf-8")
        unsafe_anchor = anchor_text.replace("- 允许修改范围: program/", "- 允许修改范围: ../")
        (task / "TASK_ANCHOR.md").write_text(unsafe_anchor, encoding="utf-8")
        unsafe_scope = run("detect_drift.py", project, "--task-id", "T-DEV-001")
        check(unsafe_scope.returncode == 2 and "unsafe allowed-scope rule" in unsafe_scope.stdout,
              "drift detector accepted a path-traversal scope rule")
        (task / "TASK_ANCHOR.md").write_text(anchor_text, encoding="utf-8")

        metadata_check = run("detect_drift.py", project, "--task-id", "T-DEV-001")
        check(metadata_check.returncode == 0,
              "mapped V1.20 records were incorrectly treated as source-scope violations: " + metadata_check.stdout)
        check("METADATA[development_records]" in metadata_check.stdout and
              "METADATA[test_evidence]" in metadata_check.stdout,
              "drift report did not separately classify mapped metadata paths")

        # Reproduce the original false PASS: one allowed path sorts before an out-of-scope path.
        outside = project / "zz_outside.c"
        outside.write_text("int forbidden_change;\n", encoding="utf-8")
        git(project, "add", "zz_outside.c")
        git(project, "commit", "-qm", "out-of-scope source change")
        drift = run("detect_drift.py", project, "--task-id", "T-DEV-001")
        check(drift.returncode == 1, "drift detector falsely passed an out-of-scope committed file: " + drift.stdout)
        check("zz_outside.c" in drift.stdout, "drift detector omitted the out-of-scope file path")
        check("PRODUCT_PATHS: 2" in drift.stdout and
              "PRODUCT: program/main.c" in drift.stdout and
              "PRODUCT: zz_outside.c" in drift.stdout,
              "drift detector did not parse/classify separate NUL-delimited paths: " + drift.stdout)

        # A project nested inside a monorepo must use project-relative task scope correctly.
        mono = tmp / "monorepo"
        nested_project = mono / "firmware"
        make_project(nested_project, mono)
        nested_created = run("create_task.py", nested_project, "--task-id", "T-NESTED-001",
                             "--baseline-id", "BL-NESTED", "--title", "nested project test")
        check(nested_created.returncode == 0,
              "task creation failed for project nested in Git repository: " + nested_created.stdout)
        nested_task = nested_project / mapping["paths"]["task_root"] / "T-NESTED-001"
        nested_anchor = nested_task / "TASK_ANCHOR.md"
        for label, value in {
            "最终项目目标": "Nested repository scope test",
            "当前阶段目标": "Validate project-relative path prefix",
            "允许修改范围": "program/",
            "验收标准": "Nested project source path passes"
        }.items():
            set_field(nested_anchor, label, value)
        (nested_project / "program/main.c").write_text("int main(void) { return 9; }\n", encoding="utf-8")
        git(mono, "add", "firmware/program/main.c")
        git(mono, "commit", "-qm", "nested allowed source change")
        nested_drift = run("detect_drift.py", nested_project, "--task-id", "T-NESTED-001")
        check(nested_drift.returncode == 0 and "PROJECT_RELATIVE_PATH: firmware" in nested_drift.stdout,
              "nested project relative scope was not applied: " + nested_drift.stdout)

        # Confirm workflow no longer points to the stale package-internal work/<task-id> path.
        workflow = (ROOT / ".ai-engineering/workflows/软件任务工作流.md").read_text(encoding="utf-8")
        check("work/<task-id>/TASK_PLAN.md" not in workflow,
              "software workflow still points to stale .ai-engineering/work storage")

        print("PASS: RC2.2 developer workflow regression suite (31/31 assertions)")
        print("PASS GROUPS: normal task creation/no pycache, structure+acceptance template alignment,")
        print("             task-bound input-lock identity, changed-input detection, mapped V1.20 metadata,")
        print("             verified snapshot placement, NUL-safe drift rejection, workflow path consistency")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

if __name__ == "__main__":
    main()
