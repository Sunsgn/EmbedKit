# 规范包文件所有权清单

包主体路径均相对项目根目录 `.ai/`；规则正文唯一权威位置为项目根目录 `.ai/.ai-engineering/`。

## A. 规范包管理文件（升级可替换，但须先检查本地改动）
- `.ai/.ai-engineering/rules/**/*.md`
- `.ai/.ai-engineering/disciplines/**/*.md`
- `.ai/.ai-engineering/workflows/**/*.md`
- `.ai/.ai-engineering/templates/**/*.md`
- `.ai/.ai-engineering/project-framework/项目目录框架_V1.20.md`
- `.ai/.ai-engineering/project-framework/目录框架适用与裁剪规则.md`
- `.ai/.ai-engineering/installation/**/*.md`（`PACKAGE_MANIFEST.md`自身除外）
- `.ai/.ai-engineering/RULES_INDEX.md`
- `.ai/.ai-engineering/cognition/COGNITION_CORE.md`
- `.ai/.ai-engineering/workflows/L0认知连续性与研发知识沉淀工作流.md`
- `.ai/.ai-engineering/knowledge/**/*TEMPLATE.md`及`knowledge/INDEX.md`（模板/索引基线）
- `.ai/.ai-engineering/VERSION.md`
- `.ai/tools/**/*.py`、`.ai/tools/README.md`（可选辅助工具，升级前检查本地改动）
- `.ai/docs/**/*.md`（版本变更和验证说明）

## B. 合并管理文件（禁止无条件覆盖）
- 根目录 `CLAUDE.md`、`GEMINI.md`、`README.md`（入口/说明文件，升级前三方合并）
- `.ai/AGENTS.md`、`.ai/AI-INSTRUCTIONS.md`（统一规则入口，升级前三方合并）
- `.ai/.github/copilot-instructions.md`

## C. 项目拥有文件（升级/卸载必须保留）
- `.ai/.ai-engineering/project/*.md`中的项目事实值
- 项目根目录`.ai/`及V1.20映射业务目录中的项目事实、决策、检查点和验证记录
- 项目根目录V1.20映射业务目录中的研发总结、专题和复盘
- `.ai/.ai-engineering/project-framework/现有项目目录映射规则.md`中的项目映射
- 项目根目录V1.20映射的`任务记录/<TASK_ID>/**`全部任务记录、锁、状态和证据索引

## D. 包内结构要求
- 规则真源、空白模板、工作流和通用工具位于 `.ai/.ai-engineering/`；项目真实工作记录位于项目根目录V1.20映射业务目录；工具代码位于包根 `.ai/tools/`，版本说明位于 `.ai/docs/`。
- L0规则是执行约束，不是模型永久记忆或操作系统强制访问控制；项目级认知/知识记录必须由项目自行持有并在升级时保留。
- 工具代码是可选辅助能力，不是规则真源；工具不可用时必须按文档手工执行等价检查，并标记工具能力状态。
- Python 辅助脚本允许作为包交付文件，必须纳入包级 SHA-256 清单；不允许缓存、虚拟环境、临时日志或未授权二进制。
- 根入口只负责加载和路由，不得复制专业规范正文。
- 项目任务数据不得被规范升级覆盖或删除。
