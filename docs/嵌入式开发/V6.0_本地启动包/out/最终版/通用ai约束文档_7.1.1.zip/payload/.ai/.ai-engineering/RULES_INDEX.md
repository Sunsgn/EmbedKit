# 规则索引与任务路由

本文件只定位权威规则，不复制技术规则。

## 通用执行规则
所有STANDARD/FULL任务：`.ai/.ai-engineering/rules/00`至`03`；修改任务追加`04`和`07`；阶段管理读取`06`；遇到停止/恢复读取`08`；离场运行读取`09`；跨版本恢复读取`10`。接口/持久化变更追加`05`。

| 任务 | 必须专业规范 | 必须Profile | 主工作流 |
|---|---|---|---|
| 固件/驱动/RTOS/协议/构建 | `disciplines/software/嵌入式软件工程规范.md` | SOFTWARE、TOOL_CAPABILITIES | 软件任务 |
| 电路/电源/器件 | 电子硬件总规范 | HARDWARE | 原理图设计或审核 |
| 原理图设计 | 电子硬件总规范、原理图审核规范 | HARDWARE、TOOL_CAPABILITIES | 原理图设计 |
| PCB布局布线/制造输出 | 电子硬件总规范、PCB设计与审核规范 | HARDWARE、TOOL_CAPABILITIES | PCB设计 |
| 软硬件接口/板级联调 | 软硬件协同规范及受影响专业 | SOFTWARE、HARDWARE、TOOL_CAPABILITIES | 软硬件协同 |
| 测试/复现/整改 | 真实测试与交付规范 | TEST、TOOL_CAPABILITIES | 测试与问题整改 |
| 生产/工装/校准 | 生产制造与校准规范 | MANUFACTURING、HARDWARE、TEST | 生产校准 |
| 系统需求/架构/预算 | 系统工程与需求规范 | SYSTEM | 系统工程 |
| 机械/热/可靠性 | 机械热与可靠性规范 | HARDWARE、TEST | 按任务选测试/系统工作流 |
| 安全/合规/发布 | 安全合规与发布规范 | SECURITY | 安全合规 |
| 供应链/EOL/现场维护 | 供应链与现场维护规范 | SYSTEM及受影响Profile | 发布交付 |
| 项目目录新建/迁移 | V1.20框架及裁剪规则 | PROJECT | 对应安装/迁移流程 |

任务识别首先读取项目事实；专业勾选仅控制常态加载，不得屏蔽当前任务明确命中的专业。跨专业追加规范必须记录触发原因。工具能力未知时先探测，不能把“工具存在”推断为具备自动修改/布线能力。


## V6.1.2专业深化路由补充
- 软件任务：除软件规范外，涉及RTOS/DMA/Cache时必须加载对应章节；涉及Flash/OTA时加载持久化与升级章节。
- 原理图设计与审核：均加载电子硬件总规范和原理图审核规范；设计任务使用原理图设计工作流。
- PCB自动化：必须加载PCB规范、PCB工作流和EDA工具能力探测工作流；工具能力未验证时不得承诺自动修改/布线。
- 生产校准：同时加载生产制造与校准规范、测试规范和生产校准工作流。
- 跨专业产品任务：先加载系统需求与软硬件协同规范，再按影响追加软件、硬件、机械、测试、制造、安全和生命周期规范。
- 专业文件完成度：任何专业分册状态必须遵循`workflows/专业规范完成度验收.md`，不能按文件存在或字数判定。


## V6.2.0 L0 认知连续性控制（所有实质任务前置）
- 所有任务遵循 `.ai/.ai-engineering/cognition/COGNITION_CORE.md`；LIGHT只读任务可简化记录，但不得忽略项目身份、事实冲突和权限边界。
- STANDARD/FULL：先读取项目根目录`.ai/COGNITION_STORAGE_MAP.json`；映射CONFIRMED后，从V1.20映射位置读取项目级认知记录，并在`任务记录/<TASK_ID>/TASK_ANCHOR.md`维护任务锚点。
- 修改前检索 `DECISION_LEDGER.md`、`FAILED_APPROACHES.md`、`VERIFIED_FEATURES.md` 和相关 `knowledge/` 条目；只检索当前任务相关内容，不全文加载知识库。
- 修改前进行最小变更和依赖影响分析；涉及受保护功能时保留旧基线并执行回归。
- 节点总结按触发规则生成，写入V1.20映射的`开发文档/开发记录/`等业务目录，并更新映射的知识索引；检查点与HANDOFF按TASK_ID存放。
- 辅助工具：`validate_cognition.py`、`detect_drift.py`、`protect_verified.py`、`checkpoint.py`、`generate_summary.py`。工具输出不替代语义审查或真实工程验证。
