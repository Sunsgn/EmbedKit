#!/usr/bin/env python3
"""Structural completeness check for a discipline document; never grants pilot approval."""
from pathlib import Path
import argparse,sys,re
REQUIRED=['适用范围','输入','原理','设计方法','计算','工具','诊断','整改','验收','案例']
p=argparse.ArgumentParser();p.add_argument('file');a=p.parse_args();f=Path(a.file);t=f.read_text(encoding='utf-8');missing=[x for x in REQUIRED if x not in t]
if missing:print('FAIL: missing dimensions:',','.join(missing));sys.exit(1)
print('STRUCTURE_PASS: all ten dimensions are mentioned. Human technical review and real-project pilot remain required; no approval status is changed.')
