# AI 嵌入式工程统一约束包入口

本文件是项目 AI 工程规则的权威入口，存放于项目根目录 `.ai/AGENTS.md`。唯一规则源位于项目根目录 `.ai/.ai-engineering/`；版本见 `.ai/.ai-engineering/VERSION.md`。

7.0.0-alpha.1 起，项目根目录四类客户端薄入口先加载 `.ai/system/ENTRYPOINT.md`，再进入本文件和 V6 规则正文。安装、升级、包身份和回滚以 `.ai/system/` 与 `.ai/INSTALL_STATE.json` 为准。

## 强制加载顺序

1. 确认用户指定的项目根目录、可访问范围和当前 AI 工具环境；读取 `.ai/.ai-engineering/rules/00` 至 `03`。
2. 读取 `.ai/.ai-engineering/cognition/COGNITION_CORE.md` 和 `.ai/.ai-engineering/project-framework/L0认知记录与研发资料存储映射.md`；核对项目根目录 `.ai/PROJECT_PROFILE.md`、`.ai/COGNITION_STORAGE_MAP.json`。映射未确认时，不得写入正式项目记录。
3. 读取 `.ai/.ai-engineering/rules/04` 至 `10` 中与任务相关的规则；L0认知连续性、方向控制、成果保护和恢复机制优先于具体专业任务约束。
4. 读取 `.ai/.ai-engineering/project/ENABLED_DISCIPLINES.md`、相关 Profile 和任务命中的专业规范；按需加载，不无差别读取全部专业正文。
5. 修改前建立任务锚点、输入锁定和基线；修改后执行适用验证，记录证据、失败方案、已验证功能和阶段总结。
6. 所有任务记录必须按 `.ai/COGNITION_STORAGE_MAP.json` 的已确认映射写入，不得默认写入约束包内部规则目录。

## 目录职责

- `.ai/AGENTS.md`、`.ai/AI-INSTRUCTIONS.md`：AI 入口与通用加载要求。
- `.ai/.ai-engineering/`：通用规则、专业规范、工作流、模板、知识库和版本资料。
- `.ai/tools/`：本地辅助工具。
- `.ai/docs/`：历史变更、测试和验证报告。
- `.ai/.github/`：GitHub Copilot 专属入口。
- 项目根目录 `.ai/PROJECT_PROFILE.md`、`.ai/COGNITION_STORAGE_MAP.json` 等：项目自身认知档案，由初始化工具按需创建；不得覆盖 `.ai/` 内已有约束包文件。

## 工具路径

从项目根目录运行工具时使用 `.ai/tools/<脚本名>`，例如：

`python .ai/tools/init_cognition.py .`

阶段 1 安装器会在保留已有内容的前提下创建或增量合并项目根目录 `AGENTS.md`，由其引导 Codex 读取 `.ai/system/ENTRYPOINT.md`。文件存在不代表 AI 已实际读取；每个会话仍需根据统一入口生成真实加载回执。
