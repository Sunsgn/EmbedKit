#!/usr/bin/env python3
"""Create immutable summary drafts in V1.20 paths, bound to a validated task."""
from pathlib import Path
import argparse, sys, re, datetime, json
sys.dont_write_bytecode = True
from storage_map import resolve, task_dir, MapError

MAP = {
    "stage": ("development_records", "stages", "STAGE_SUMMARY_TEMPLATE.md"),
    "technical": ("technical_knowledge", "", "TECHNICAL_NOTE_TEMPLATE.md"),
    "issue": ("issue_records", "", "ISSUE_CLOSURE_TEMPLATE.md"),
    "change": ("development_records", "changes", "CHANGE_SUMMARY_TEMPLATE.md"),
    "milestone": ("milestones", "", "MILESTONE_TEMPLATE.md"),
    "retro": ("retrospectives", "", "RETROSPECTIVE_TEMPLATE.md")
}
TEMPLATE_DIR = {
    "stage": "stages", "technical": "technical", "issue": "issues",
    "change": "changes", "milestone": "milestones", "retro": "retrospectives"
}

parser = argparse.ArgumentParser()
parser.add_argument("type", choices=MAP)
parser.add_argument("--root", default=".")
parser.add_argument("--task-id", required=True)
parser.add_argument("--record-id", default="")
parser.add_argument("--output", default="")
args = parser.parse_args()

root = Path(args.root).resolve()
key, sub, template = MAP[args.type]
package_root = Path(__file__).resolve().parent.parent
template_path = package_root / ".ai-engineering/knowledge" / TEMPLATE_DIR[args.type] / template
if not template_path.is_file():
    print("TEMPLATE_MISSING:", template_path)
    sys.exit(2)

try:
    task_path, mapping = task_dir(root, args.task_id)
    folder, _ = resolve(root, key, *([sub] if sub else []))
    index_path, _ = resolve(root, "knowledge_index")
except MapError as exc:
    print("BLOCKED:", exc)
    sys.exit(2)

anchor = task_path / "TASK_ANCHOR.md"
if anchor.is_symlink() or not anchor.resolve(strict=False).is_relative_to(task_path.resolve()) or not anchor.is_file():
    print("BLOCKED: TASK_ANCHOR_MISSING_OR_UNSAFE:", anchor)
    sys.exit(2)
anchor_text = anchor.read_text(encoding="utf-8")
if f"- PROJECT_ID: {mapping['project_id']}" not in anchor_text or f"- TASK_ID: {args.task_id}" not in anchor_text:
    print("BLOCKED: TASK_ANCHOR_IDENTITY_MISMATCH")
    sys.exit(2)

def read_field(label, default):
    match = re.search(r"^[ \t]*-[ \t]*" + re.escape(label) + r"[ \t]*[:：][ \t]*(.*)$", anchor_text, re.M)
    return match.group(1).strip() if match else default

baseline_id = read_field("BASELINE_ID", "UNKNOWN")
git_base = read_field("GIT_BASE_COMMIT", "NOT_CAPTURED")
baseline_file = task_path / "GIT_BASELINE.json"
if baseline_file.is_symlink() or not baseline_file.resolve(strict=False).is_relative_to(task_path.resolve()) or not baseline_file.is_file():
    print("BLOCKED: GIT_BASELINE_MISSING_OR_UNSAFE:", baseline_file)
    sys.exit(2)
try:
    git_record = json.loads(baseline_file.read_text(encoding="utf-8"))
except Exception as exc:
    print("BLOCKED: GIT_BASELINE_INVALID:", exc)
    sys.exit(2)
if git_record.get("project_id") != mapping["project_id"] or git_record.get("task_id") != args.task_id:
    print("BLOCKED: GIT_BASELINE_IDENTITY_MISMATCH")
    sys.exit(2)
if (git_record.get("commit") or "NOT_CAPTURED") != git_base:
    print("BLOCKED: GIT_BASELINE_COMMIT_MISMATCH")
    sys.exit(2)
record_id = args.record_id or (
    f"{args.type.upper()}-{datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}-{args.task_id}"
)
if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{2,99}", record_id):
    parser.error("invalid record id")

if args.output:
    requested = Path(args.output)
    dest = (root / requested).resolve() if not requested.is_absolute() else requested.resolve()
else:
    dest = (folder / (record_id + ".md")).resolve()
if not dest.is_relative_to(root):
    print("PATH_ESCAPE:", dest)
    sys.exit(2)
if dest.is_symlink():
    print("REFUSE_SYMLINK_TARGET:", dest)
    sys.exit(2)
if dest.exists():
    print("REFUSE_OVERWRITE:", dest)
    sys.exit(3)

text = template_path.read_text(encoding="utf-8")
metadata = (
    f"<!-- PROJECT_ID: {mapping['project_id']} | TASK_ID: {args.task_id} | "
    f"BASELINE_ID: {baseline_id} | GIT_BASE_COMMIT: {git_base} | RECORD_ID: {record_id} -->\n"
)
dest.parent.mkdir(parents=True, exist_ok=True)
dest.write_text(metadata + text, encoding="utf-8", newline="\n")

index_path.parent.mkdir(parents=True, exist_ok=True)
if index_path.is_symlink():
    print("BLOCKED: KNOWLEDGE_INDEX_SYMLINK:", index_path)
    sys.exit(2)
if not index_path.exists():
    index_path.write_text(
        "# 研发知识索引\n\n| RECORD_ID | 类型 | 路径 | 状态 | TASK_ID | 创建时间 |\n"
        "|---|---|---|---|---|---|\n",
        encoding="utf-8"
    )
relative = dest.relative_to(root).as_posix()
with index_path.open("a", encoding="utf-8", newline="\n") as stream:
    stream.write(
        f"| {record_id} | {args.type} | `{relative}` | DRAFT | {args.task_id} | "
        f"{datetime.datetime.now(datetime.timezone.utc).isoformat()} |\n"
    )
print("SUMMARY_DRAFT_CREATED:", dest)
print("INDEX_UPDATED:", index_path)
print("STATUS: DRAFT; fill from actual project files and test evidence.")
