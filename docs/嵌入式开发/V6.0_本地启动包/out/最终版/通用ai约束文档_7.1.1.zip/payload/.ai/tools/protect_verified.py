#!/usr/bin/env python3
"""Append-only SHA-256 snapshots for verified files; never overwrite a prior baseline."""
from pathlib import Path
import argparse,hashlib,json,sys,datetime,re
sys.dont_write_bytecode = True
from storage_map import resolve,MapError
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()
p=argparse.ArgumentParser()
p.add_argument("action",choices=["snapshot","check"]); p.add_argument("project_root",nargs="?",default=".")
p.add_argument("--files",nargs="*",default=[]); p.add_argument("--baseline-id",default="")
p.add_argument("--manifest",default="")
a=p.parse_args(); root=Path(a.project_root).resolve()
if a.manifest:
    mpath=(root/a.manifest).resolve()
    if not mpath.is_relative_to(root): print("PATH_ESCAPE"); sys.exit(2)
    manifest_dir=mpath if mpath.suffix=="" else mpath.parent
else:
    try: mapped,_=resolve(root,"test_evidence")
    except MapError as e: print("BLOCKED:",e); sys.exit(2)
    manifest_dir=mapped
manifest_dir=manifest_dir/"verified_file_baselines"
if a.action=="snapshot":
    if not a.files: p.error("snapshot requires --files")
    if not re.fullmatch(r"[A-Za-z0-9._-]{3,80}",a.baseline_id or ""): p.error("snapshot requires --baseline-id")
    manifest_dir.mkdir(parents=True,exist_ok=True); mf=manifest_dir/(a.baseline_id+".json")
    if mf.exists(): print("REFUSE_OVERWRITE:",mf); sys.exit(3)
    files={}
    for rel in a.files:
        q=(root/rel).resolve()
        if not q.is_relative_to(root) or not q.is_file(): print("INVALID_FILE:",rel); sys.exit(2)
        files[rel.replace("\\","/")]=sha(q)
    data={"schema_version":"1.0","baseline_id":a.baseline_id,
          "created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "algorithm":"sha256","files":files,"status":"CANDIDATE_NOT_APPROVED",
          "note":"Hash identity only; functional verification/approval are separate."}
    tmp=mf.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    json.loads(tmp.read_text(encoding="utf-8")); tmp.replace(mf)
    print("SNAPSHOT_CREATED_CANDIDATE:",mf)
else:
    if not a.baseline_id: p.error("check requires --baseline-id")
    mf=manifest_dir/(a.baseline_id+".json")
    if not mf.is_file(): print("BASELINE_NOT_FOUND:",mf); sys.exit(2)
    try: data=json.loads(mf.read_text(encoding="utf-8"))
    except Exception as e: print("INVALID_JSON:",e); sys.exit(4)
    changed=[]
    for rel,expected in data.get("files",{}).items():
        q=(root/rel).resolve()
        if not q.is_relative_to(root) or not q.is_file(): changed.append((rel,"MISSING_OR_INVALID")); continue
        if sha(q)!=expected: changed.append((rel,"HASH_MISMATCH"))
    if changed:
        print("FAIL: protected files changed")
        for x in changed: print(*x)
        sys.exit(1)
    print("PASS: hash baseline matches; functional behavior is not certified.")
