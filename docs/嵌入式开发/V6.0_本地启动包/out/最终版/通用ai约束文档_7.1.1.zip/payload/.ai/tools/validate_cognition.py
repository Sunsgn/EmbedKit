#!/usr/bin/env python3
"""Validate V1.20-mapped project cognition records; never writes project records."""
from pathlib import Path
import argparse,re,sys,json
sys.dont_write_bytecode = True
from storage_map import load_map,task_dir,resolve,MapError
p=argparse.ArgumentParser()
p.add_argument("project_root",nargs="?",default=".")
p.add_argument("--mode",choices=["structure","task","checkpoint"],default="structure")
p.add_argument("--task-id",default="")
a=p.parse_args()
root=Path(a.project_root).resolve(); err=[]
try:
    mapping=load_map(root)
except MapError as e:
    print("BLOCKED:",e); sys.exit(2)
profile=root/".ai/PROJECT_PROFILE.md"
if not profile.is_file(): err.append("MISSING:.ai/PROJECT_PROFILE.md")
if mapping.get("project_id") in {"","待填写","TODO"}: err.append("PROJECT_ID_UNSET")
if a.mode in {"task","checkpoint"}:
    if not a.task_id: print("BLOCKED: --task-id required for task/checkpoint validation"); sys.exit(2)
    try: td,_=task_dir(root,a.task_id)
    except MapError as e: print("BLOCKED:",e); sys.exit(2)
    anchor=td/"TASK_ANCHOR.md"
    anchor_safe=(not anchor.is_symlink() and anchor.resolve(strict=False).is_relative_to(td.resolve()))
    if not anchor_safe: err.append("TASK_ANCHOR_PATH_UNSAFE")
    def fields(path,labels,prefix):
        if not path.is_file(): err.append(prefix+":MISSING:"+str(path)); return
        s=path.read_text(encoding="utf-8")
        for label in labels:
            m=re.search(r"^[ \t]*-[ \t]*"+re.escape(label)+r"[ \t]*[:：][ \t]*(.*)$",s,re.M)
            if not m or m.group(1).strip() in {"","TODO","待填写","待确认","UNKNOWN"}:
                err.append(prefix+":EMPTY:"+label)
    if anchor_safe:
        fields(anchor,["PROJECT_ID","TASK_ID","BASELINE_ID","GIT_BASE_COMMIT","最终项目目标","当前阶段目标","当前唯一主任务","允许修改范围","验收标准"],"TASK_ANCHOR")
    if anchor_safe and anchor.is_file():
        s=anchor.read_text(encoding="utf-8")
        if f"- PROJECT_ID: {mapping['project_id']}" not in s: err.append("TASK_PROJECT_ID_MISMATCH")
        if f"- TASK_ID: {a.task_id}" not in s: err.append("TASK_ID_MISMATCH")
        baseline_file=td/"GIT_BASELINE.json"
        if baseline_file.is_symlink() or not baseline_file.resolve(strict=False).is_relative_to(td.resolve()):
            err.append("GIT_BASELINE_PATH_UNSAFE")
        elif not baseline_file.is_file():
            err.append("GIT_BASELINE_MISSING")
        else:
            try:
                gb=json.loads(baseline_file.read_text(encoding="utf-8"))
                gm=re.search(r"^[ \t]*-[ \t]*GIT_BASE_COMMIT[ \t]*[:：][ \t]*(.*)$",s,re.M)
                recorded=gm.group(1).strip() if gm else ""
                if gb.get("project_id")!=mapping["project_id"] or gb.get("task_id")!=a.task_id:
                    err.append("GIT_BASELINE_IDENTITY_MISMATCH")
                if (gb.get("commit") or "NOT_CAPTURED")!=recorded:
                    err.append("GIT_BASELINE_COMMIT_MISMATCH")
                if gb.get("status")=="CAPTURED" and gb.get("working_tree_clean") is not True:
                    err.append("GIT_BASELINE_NOT_CLEAN")
            except Exception:
                err.append("GIT_BASELINE_INVALID")
if a.mode=="checkpoint":
    cdir=td/"CONTEXT_CHECKPOINTS"
    if cdir.is_symlink() or not cdir.resolve(strict=False).is_relative_to(td.resolve()):
        err.append("CHECKPOINT_DIR_PATH_UNSAFE")
        cps=[]
    else:
        cps=sorted(cdir.glob("CP-*.md")) if cdir.is_dir() else []
    if not cps: err.append("NO_CHECKPOINT")
    else:
        latest=cps[-1]
        if latest.is_symlink() or not latest.resolve(strict=False).is_relative_to(cdir.resolve()):
            err.append("CHECKPOINT_FILE_PATH_UNSAFE")
            latest=None
        s=latest.read_text(encoding="utf-8") if latest else ""
        for label in ["PROJECT_ID","TASK_ID","BASELINE_ID","GIT_BASE_COMMIT","CHECKPOINT_ID","当前阶段/状态","当前唯一主任务","已完成且有证据的工作","下一步最小动作"]:
            m=re.search(r"^[ \t]*-[ \t]*"+re.escape(label)+r"[ \t]*[:：][ \t]*(.*)$",s,re.M)
            if not m or m.group(1).strip() in {"","TODO","待填写","待确认"}: err.append("CHECKPOINT_EMPTY:"+label)
        if f"- PROJECT_ID: {mapping['project_id']}" not in s: err.append("CHECKPOINT_PROJECT_ID_MISMATCH")
        if f"- TASK_ID: {a.task_id}" not in s: err.append("CHECKPOINT_TASK_ID_MISMATCH")
if err:
    print("FAIL: cognition validation"); print("\n".join(err)); sys.exit(1)
print(f"PASS: mode={a.mode}; project={mapping['project_id']}; task={a.task_id or 'N/A'}; structural validation only.")
