# AI 嵌入式全栈工程研发规范

> 7.0.0-alpha.1 兼容说明：本目录保留 V6 规则、模板和工具能力。新安装、升级、回滚和四类 AI 客户端入口由 `.ai/system/bootstrap.py`、`.ai/system/ENTRYPOINT.md` 和 `.ai/INSTALL_STATE.json` 管理；不再要求修改产品根目录 `README.md`。本文件中的 V6 手工安装说明只用于理解历史包，不能覆盖阶段 1 事务安装结果。

这是一套可直接放入新项目或已有项目的纯 Markdown 工程规范。目标是让 Codex、Claude Code、Gemini CLI、GitHub Copilot及其他AI工具遵循同一套要求，像工程团队一样完成嵌入式软件、原理图、PCB、软硬件协同、真实测试、整改和交付。

## 使用特点

- **固定命名空间**：规范正文统一位于`.ai/.ai-engineering/`，不占用项目常见的`project/`、`rules/`、`work/`目录。
- **一个规则真源**：`.ai/.ai-engineering/rules/`和`.ai/.ai-engineering/disciplines/`是强制规则；入口、工作流和模板不复制技术正文。
- **专业独立启用**：软件、原理图、PCB、测试和协同分析可以单独使用，不强制走完整生命周期。
- **项目事实分离**：通用规则不写死芯片、RTOS、EDA或工具链；通用Profile模板位于`.ai/.ai-engineering/project/`；项目真实事实按V1.20写入项目根目录`.ai/`及映射的业务目录。
- **真实证据判定**：无法访问EDA、硬件、仪器或生产环境时明确降级，禁止模拟为PASS。
- **新旧项目兼容**：新项目可以采用V1.20目录；已有项目使用目录映射，不强制重构。

## 最快开始

1. 先按外部《AI工程约束包通用接入与初始化执行指令.md》运行阶段 1 事务安装；安装后从根目录客户端入口进入 `.ai/system/ENTRYPOINT.md`。
2. 在`.ai/.ai-engineering/project/ENABLED_DISCIPLINES.md`完成首次专业选择；初始为`UNINITIALIZED`，不默认软件。
3. 只填写当前任务必需的项目事实，不要求一次填完所有Profile。
4. 向AI提出具体任务；AI从`.ai/AGENTS.md`进入并按`RULES_INDEX.md`加载。

## 文件效力

- 正式强制约束：`.ai/.ai-engineering/rules/*.md`、`.ai/.ai-engineering/disciplines/**/*.md`。
- 约束包Profile模板：`.ai/.ai-engineering/project/*.md`；项目真实事实：项目根目录`.ai/`及`.ai/COGNITION_STORAGE_MAP.json`映射的V1.20业务目录。
- 权威目录基线：`.ai/.ai-engineering/project-framework/项目目录框架_V1.20.md`。
- 执行辅助：`.ai/.ai-engineering/workflows/`、`.ai/.ai-engineering/templates/`、`.ai/.ai-engineering/work/`。
- 工具入口：根目录 `AGENTS.md`、`CLAUDE.md`、`GEMINI.md`、`.github/copilot-instructions.md` 统一路由到 `.ai/system/ENTRYPOINT.md`；V6 规则入口继续为 `.ai/AGENTS.md` 和 `.ai/AI-INSTRUCTIONS.md`。

入口和辅助文件不得产生与权威规则冲突的新要求。详细冲突优先级见`.ai/.ai-engineering/rules/00_规范效力与加载规则.md`。


## V6.1.1-RC2 增量能力

本候选版在保留 V6.0 原有专业分册和 V1.20 项目目录框架的基础上，新增任务生命周期、输入锁定、停止恢复、离场权限、跨版本交接、项目识别工作流、原理图设计工作流、PCB深化工作流、生产校准工作流及状态/证据模板。

### 本地校验
需要 Python 3.10+（脚本只使用标准库）：
```bash
python .ai/tools/validate_package.py
python .ai/tools/discover_project.py <项目路径>
```
工具只提供确定性辅助检查；项目识别输出是候选事实，必须由AI结合原生工程证据复核。工具存在不代表具备EDA自动布局布线能力。


## V6.1.1-RC2 修复说明

- 统一任务记录目录，旧 `AI加载回执.md` / `INPUT_HASHES.md` 仅作历史兼容，不再双写。
- 明确任务状态允许迁移和阶段最低门禁。
- 修正规则入口中的相对路径。
- 修复包完整性校验，使其验证完整清单哈希、文件集合和本地链接。
- 修复交接校验，空模板/缺少证据的 PASS 不得通过。
- 新增任务结构校验、输入哈希锁定和单写入任务锁工具。
- 明确工具代码属于可选包管理文件，并纳入包级清单。

## V6.1.2-RC1 专业深化

本版基于V6.1.1-RC2，重点深化嵌入式软件、电子硬件、原理图、PCB和测试规范；补充EDA工具能力探测工作流、专业规范完成度验收及FreeRTOS UART DMA、PCB自动化、压力传感器校准三个教学流程案例。

本版不代表任何具体EDA版本已具备自动布局/布线能力，也不代表目标板、量产校准或产品安全已完成验证。真实项目必须绑定当前输入、工具版本和证据；未执行项保持NOT_RUN/UNAVAILABLE/BLOCKED。


## V6.2.0 RC1 自测命令
```bash
python .ai/tools/validate_package.py
python .ai/tools/test_validators.py
python .ai/tools/test_l0_rc2.py
python .ai/tools/validate_document_structure.py .ai/.ai-engineering/disciplines
python -m py_compile .ai/tools/*.py
```
20项工具测试使用临时合成数据，仅验证检查器行为；不代表真实项目或硬件验收。


本候选版新增 L0 工程认知与行为控制、研发知识沉淀、检查点和相关辅助工具。真实多轮 AI 工程试点仍未完成，详见 `.ai/docs/V6.2.0-RC1_升级与验证报告.md`。


## V6.2.0 RC2.2 开发者工作流与任务保护
项目研发记录遵循 `.ai/.ai-engineering/project-framework/项目目录框架_V1.20.md`。项目根目录 `.ai/` 保存Profile和存储映射；任务锚点/检查点放入映射任务根目录下的 `<TASK_ID>/`；技术总结、问题闭环、测试证据、变更和里程碑记录分别放入V1.20对应业务目录。约束包 `.ai/.ai-engineering/` 只保存规则、模板、工作流和工具，不作为项目真实记录库。详见 `L0认知记录与研发资料存储映射.md`。

## V6.2.0 RC2.1 增量修复（历史）

- TASK_ID统一严格校验，拒绝路径穿越、绝对路径、反斜杠注入和任务目录符号链接。
- 所有任务写入入口统一通过`storage_map.task_dir()`解析；总结生成也必须先验证TASK_ID和TASK_ANCHOR身份。
- 创建任务时自动捕获Git完整Commit SHA，记录于`GIT_BASELINE.json`和`TASK_ANCHOR.md`。
- 偏离检测固定比较任务创建Commit到当前工作树，覆盖已提交、暂存、未暂存和未跟踪文件。
- 基线缺失、篡改、仓库根目录改变或当前HEAD不属于基线后代时，必须BLOCKED/UNAVAILABLE。
- 任务记录根目录从产品源码路径检查中排除，避免检查点和交接文档被误报为产品代码改动。
- 新增专项回归：路径穿越、任务符号链接、映射目录穿越、固定Git基线、已提交越界修改、暂存/未暂存/未跟踪文件和基线篡改。

### RC2.2任务启动与Git基线要求

创建任务前，Git工作区必须干净（V1.20映射的任务记录目录除外）。工具自动记录创建任务时的完整HEAD Commit SHA；显式指定`--base-commit`时必须与当前HEAD相同。若工作区有未提交改动，创建任务会BLOCKED，不会自动stash/reset/checkout，也不会修改用户文件。后续偏离检测覆盖基线之后的提交、暂存、未暂存和未跟踪文件；任务记录及其他已映射V1.20研发记录按元数据单独列示，不与产品源码范围混判。

回归命令：

```bash
python .ai/tools/test_validators.py
python .ai/tools/test_l0_rc22.py
python .ai/tools/test_l0_rc2.py
python .ai/tools/validate_package.py
```

RC2.1历史修复细节见 `.ai/docs/V6.2.0-RC2.1_修复与验证报告.md`；本版本修复与验证证据见 `.ai/docs/V6.2.0-RC2.3_开发者使用修复与验证报告.md`。

## V6.2.0 RC2.2 开发者使用修复

- `detect_drift.py`使用真正的NUL分隔符解析Git路径，逐个文件判定，不再把多个路径拼成一个字符串。
- 产品源码/配置路径范围与V1.20映射的研发记录路径分开报告；阶段总结、检查点、测试证据等正常记录不再被误判为产品代码越界。
- `create_task.py`创建任务时同时生成`DECISIONS.md`，并预填任务ID、项目路径、启动时间、输入锁定ID和任务目标；新任务可立即通过结构验证。
- `validate_task.py`的必填字段与实际模板名称对齐，并核对STATUS任务ID与任务目录名一致。
- `lock_inputs.py`清单绑定精确项目根目录和PROJECT_ID；任务模式进一步绑定TASK_ID、BASELINE_ID和Git基线，禁止跨工程副本复用。
- 已验证文件快照统一写入V1.20映射的`测试/测试报告/verified_file_baselines/`，不再写入未映射的测试计划旁路目录。
- 所有使用`storage_map`的本地工具在导入前关闭Python字节码缓存写入，避免工具自身生成`__pycache__`干扰任务基线建立。

已有项目若维护`.gitignore`，建议将以下规则合并进去（不要覆盖原文件）：

```gitignore
__pycache__/
*.py[cod]
.pytest_cache/
```

任务创建和偏离检测命令见`.ai/tools/README.md`。RC2.2历史专项回归：`python .ai/tools/test_l0_rc22.py`。

### RC2.2开发者使用修复

本版本针对开发者实际接入测试发现的问题进行修复：Git路径使用NUL字节正确分割；产品代码范围与V1.20映射研发记录分开报告；任务创建自动生成`DECISIONS.md`并预填关键身份字段；任务结构/验收验证器与模板对齐；输入锁定绑定项目根目录、PROJECT_ID以及任务级TASK_ID/BASELINE_ID/Git Commit；已验证文件快照写入映射的测试报告目录；软件任务工作流不再引用约束包内部的`work/<task-id>`。

运行`python .ai/tools/test_l0_rc22.py`进行RC2.2开发者流程回归；本次目录重构验证报告见`.ai/docs/V6.2.0-RC2.3_目录重构与验证报告.md`。

## V6.2.0-RC2.3 目录布局

本版本将约束包主体统一收纳在项目根目录 `.ai/`：

- 根目录只保留 `CLAUDE.md`、`GEMINI.md`、`README.md` 三个入口/说明文件。
- `.ai/AGENTS.md`、`.ai/AI-INSTRUCTIONS.md` 为统一规则入口。
- `.ai/.ai-engineering/` 为规则、专业规范、模板、工作流和知识库。
- `.ai/tools/` 为辅助脚本。
- `.ai/docs/` 为修复、测试和版本报告。
- `.ai/.github/` 为 Copilot 指令。

**Codex 兼容说明：** Codex 默认按作用域发现 `AGENTS.md`，不会保证递归读取 `.ai/AGENTS.md`。由于本版本按项目要求不在根目录放置 `AGENTS.md`，使用 Codex 时必须在首次会话/新会话明确要求读取 `.ai/AGENTS.md` 和 `.ai/AI-INSTRUCTIONS.md`。Claude Code 与 Gemini 通过根目录入口文件引导加载。GitHub Copilot 默认也不会自动发现 `.ai/.github/copilot-instructions.md`，需配置工作区指令路径或显式加载。


## V6.2.0-RC2.3 入口兼容边界

本包按要求仅在项目根目录放置 `CLAUDE.md`、`GEMINI.md`、`README.md`。Codex 不会保证自动递归读取 `.ai/AGENTS.md`，因此使用 Codex 时必须在首次会话/新会话显式加载 `.ai/AGENTS.md` 与 `.ai/AI-INSTRUCTIONS.md`。这是目录布局约束带来的工具发现限制，不得隐瞒。

## V6.2.0-RC2.4 通用接入与增量安装

本版本完善跨项目接入要求，不把约束包安装等同于覆盖项目 AI 环境：

- 根目录已有 `CLAUDE.md`、`GEMINI.md`、`README.md` 时，必须逐文件备份、比较并增量合并，只补充缺失的规则入口或说明。
- 其他根目录 AI 工具指令文件（包括项目已有 `AGENTS.md`）必须盘点并保留，不为匹配默认目录结构而删除或移动。
- `.ai/` 目录按文件归属、版本和哈希逐项合并；项目认知档案、任务记录、测试证据和本地规则不得整体覆盖。
- 通用安装指令与本约束包分开交付，适用于不同项目；项目类型和专业规范由真实工程证据及任务范围决定。
- 真实项目接入必须在独立暂存目录先完成包级校验，再执行增量安装；冲突无法安全解决时保留原文件并阻断对应项。
