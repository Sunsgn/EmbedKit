# 任务方向锚点
- PROJECT_ID: TODO
- TASK_ID: TODO
- BASELINE_ID: TODO
- GIT_BASE_COMMIT: TODO
- 最终项目目标: TODO
- 当前阶段目标: TODO
- 当前唯一主任务: TODO
- 允许修改范围: TODO
- 明确排除范围: TODO
- 已确认技术路线: TODO
- 验收标准: TODO
- 风险/授权等级: TODO
- 完成后下一步: TODO

## 偏离处理
任何范围、目标、接口或路线变化，先记录原因、影响、证据和授权，不得默默扩大任务。
