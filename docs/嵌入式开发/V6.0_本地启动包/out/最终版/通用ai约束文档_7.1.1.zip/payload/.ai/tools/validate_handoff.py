#!/usr/bin/env python3
"""Validate handoff fields and evidence references. Evidence presence is not proof of truthful execution."""
from pathlib import Path
import argparse,re,sys
REQ=["任务ID/目标","规范包版本/结构版本","当前生命周期/阶段","当前结论/结果状态","已完成修改及文件身份","已验证内容/命令/工具版本","证据索引（相对任务目录路径）","未执行/不可用/阻塞","输入锁定ID/清单路径/变化","工作区/Git状态","当前授权边界","下一步最小动作","不得自动重放的动作"]
BAD={"","待填写","TODO","TBD","N/A待确认","未填写","<填写>","-","待确认","无"}
p=argparse.ArgumentParser();p.add_argument("file");p.add_argument("--task-root");p.add_argument("--require-pass-evidence",action="store_true");a=p.parse_args();f=Path(a.file).resolve();root=Path(a.task_root).resolve() if a.task_root else f.parent;text=f.read_text(encoding="utf-8");vals={};err=[]
for label in REQ:
 m=re.search(rf"^[ \t]*-[ \t]*{re.escape(label)}[ \t]*[:：][ \t]*(.*)$",text,re.M)
 if not m:err.append("MISSING_FIELD:"+label);continue
 v=m.group(1).strip();vals[label]=v
 if v in BAD or len(v)<2:err.append("EMPTY_FIELD:"+label)
status=vals.get("当前结论/结果状态","")
if "PASS" in status:
 detail=vals.get("已验证内容/命令/工具版本","")
 if not re.search(r"(命令|command|执行|exit|退出码)",detail,re.I):err.append("PASS_WITHOUT_EXECUTED_COMMAND")
 if not re.search(r"(版本|version|工具)",detail,re.I):err.append("PASS_WITHOUT_TOOL_VERSION")
 ev=vals.get("证据索引（相对任务目录路径）","");refs=re.findall(r"(?:^|[,，;；\s])((?:evidence/)[^\s,，;；]+)",ev)
 if not refs:err.append("PASS_WITHOUT_EVIDENCE_REF")
 valid=0
 for ref in refs:
  q=(root/ref).resolve()
  if not q.is_relative_to(root):err.append("EVIDENCE_PATH_ESCAPE:"+ref);continue
  if not q.is_file():err.append("EVIDENCE_NOT_FOUND:"+ref);continue
  if q.stat().st_size==0:err.append("EVIDENCE_EMPTY:"+ref);continue
  valid+=1
 if not valid:err.append("PASS_WITHOUT_VALID_EVIDENCE")
if err:print("FAIL: handoff invalid");print("\n".join(err));sys.exit(1)
print(f"PASS: {len(REQ)} handoff fields populated; evidence path/existence checks passed, not proof of truthful execution.")
