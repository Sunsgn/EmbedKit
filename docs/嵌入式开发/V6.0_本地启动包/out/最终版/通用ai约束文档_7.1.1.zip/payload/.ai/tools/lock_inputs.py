#!/usr/bin/env python3
"""Create/verify SHA-256 input lock for explicitly selected project files and patterns."""
from pathlib import Path
import argparse, hashlib, json, sys, fnmatch, datetime
p=argparse.ArgumentParser(description=__doc__)
p.add_argument("root"); p.add_argument("--output",required=True)
p.add_argument("--include",action="append",default=[],help="relative file or glob; repeatable")
p.add_argument("--exclude",action="append",default=[])
p.add_argument("--task-id",default="",help="Bind the manifest to a mapped task directory.")
p.add_argument("--baseline-id",default="",help="Optionally assert the task BASELINE_ID.")
p.add_argument("--verify",action="store_true"); a=p.parse_args()
root=Path(a.root).resolve()
out_arg=Path(a.output)
out=(root/out_arg).resolve() if not out_arg.is_absolute() else out_arg.resolve()
if not out.is_relative_to(root):
 print("FAIL: manifest output must be inside the project root"); sys.exit(2)

def read_project_id():
 mapping_file=root/".ai/COGNITION_STORAGE_MAP.json"
 if not mapping_file.is_file(): return None
 try: mapping=json.loads(mapping_file.read_text(encoding="utf-8"))
 except Exception as exc: raise ValueError(f"INVALID_PROJECT_MAPPING: {exc}")
 if mapping.get("status")!="CONFIRMED": raise ValueError("PROJECT_MAPPING_NOT_CONFIRMED")
 project_id=mapping.get("project_id")
 if not isinstance(project_id,str) or not project_id.strip() or project_id in {"TODO","待填写"}:
  raise ValueError("PROJECT_ID_MISSING")
 return project_id

def read_task_identity(task_id):
 if not task_id: return None
 sys.dont_write_bytecode=True
 from storage_map import task_dir, MapError
 try: task_path, mapping=task_dir(root,task_id)
 except MapError as exc: raise ValueError(str(exc))
 baseline_file=task_path/"GIT_BASELINE.json"
 if baseline_file.is_symlink() or not baseline_file.is_file() or not baseline_file.resolve().is_relative_to(task_path.resolve()):
  raise ValueError("TASK_GIT_BASELINE_MISSING_OR_UNSAFE")
 try: baseline=json.loads(baseline_file.read_text(encoding="utf-8"))
 except Exception as exc: raise ValueError(f"TASK_GIT_BASELINE_INVALID: {exc}")
 if baseline.get("project_id")!=mapping.get("project_id") or baseline.get("task_id")!=task_id:
  raise ValueError("TASK_GIT_BASELINE_IDENTITY_MISMATCH")
  if not isinstance(baseline.get("baseline_id"),str) or not baseline.get("baseline_id").strip():
   raise ValueError("TASK_BASELINE_ID_MISSING")
 return {
  "project_id": mapping["project_id"], "task_id": task_id,
  "baseline_id": baseline.get("baseline_id"),
  "git_base_commit": baseline.get("commit") or "NOT_CAPTURED"
 }

try:
 project_id=read_project_id()
 task_identity=read_task_identity(a.task_id) if a.task_id else None
except Exception as exc:
 print("BLOCKED:",exc); sys.exit(2)
if a.baseline_id and not a.task_id:
 print("FAIL: --baseline-id requires --task-id"); sys.exit(2)
if a.baseline_id and task_identity and a.baseline_id!=task_identity["baseline_id"]:
 print("FAIL: BASELINE_ID does not match task GIT_BASELINE.json"); sys.exit(2)
def sha(f):
 h=hashlib.sha256()
 with f.open('rb') as x:
  for b in iter(lambda:x.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def collect(patterns, excludes):
 files=set()
 for pat in patterns:
  for f in root.glob(pat):
   if f.is_file(): files.add(f.resolve())
   elif f.is_dir(): files.update(x.resolve() for x in f.rglob('*') if x.is_file())
 rows=[]
 for f in sorted(files):
  if f == out: continue
  try: rel=f.relative_to(root).as_posix()
  except ValueError: raise ValueError(f"OUTSIDE_ROOT: {f}")
  if any(fnmatch.fnmatch(rel,x) for x in excludes): continue
  rows.append({"path":rel,"size":f.stat().st_size,"sha256":sha(f)})
 return rows
if a.verify:
 if not out.is_file(): print(f"MISSING_MANIFEST: {out}"); sys.exit(1)
 try: data=json.loads(out.read_text(encoding='utf-8'))
 except Exception as exc: print(f"INVALID_MANIFEST: {exc}"); sys.exit(2)
 errors=[]
 if data.get("schema_version",0) < 3:
  errors.append("LEGACY_INPUT_LOCK_SCHEMA: regenerate this manifest with RC2.2 Schema 3")
 recorded_root=data.get("root")
 if not recorded_root or Path(recorded_root).resolve()!=root:
  errors.append(f"PROJECT_ROOT_MISMATCH: recorded={recorded_root!r}; current={str(root)!r}")
 if data.get("project_id")!=project_id:
  errors.append(f"PROJECT_ID_MISMATCH: recorded={data.get('project_id')!r}; current={project_id!r}")
 recorded_task=data.get("task_id") or ""
 if recorded_task and a.task_id!=recorded_task:
  errors.append(f"TASK_ID_MISMATCH: manifest requires --task-id {recorded_task}")
 if a.task_id and recorded_task!=a.task_id:
  errors.append(f"TASK_ID_MISMATCH: recorded={recorded_task!r}; current={a.task_id!r}")
 if data.get("baseline_id") and a.baseline_id and data.get("baseline_id")!=a.baseline_id:
  errors.append("BASELINE_ID_ARGUMENT_MISMATCH")
 if recorded_task:
  if task_identity is None:
   errors.append("TASK_ID_REQUIRED_FOR_TASK_BOUND_MANIFEST")
  elif task_identity["baseline_id"]!=data.get("baseline_id") or task_identity["git_base_commit"]!=data.get("git_base_commit"):
   errors.append("TASK_BASELINE_CHANGED_SINCE_INPUT_LOCK")
 if errors:
  print("FAIL: input-lock identity mismatch"); print("\n".join(errors)); sys.exit(2)
 try: current=collect(data.get('include_patterns',[]),data.get('exclude_patterns',[]))
 except Exception as e: print(f"FAIL: {e}"); sys.exit(1)
 locked={x['path']:x for x in data.get('files',[])}; now={x['path']:x for x in current}
 for rel in sorted(set(locked)-set(now)): errors.append(f"MISSING_OR_EXCLUDED: {rel}")
 for rel in sorted(set(now)-set(locked)): errors.append(f"NEW_FILE: {rel}")
 for rel in sorted(set(locked)&set(now)):
  if locked[rel]['size']!=now[rel]['size'] or locked[rel]['sha256']!=now[rel]['sha256']: errors.append(f"CHANGED: {rel}")
 if errors: print("FAIL: input changes detected\n"+"\n".join(errors)); sys.exit(1)
 print(f"PASS: {len(locked)} locked files unchanged; include patterns also checked for added/removed files."); sys.exit(0)
if not a.include: p.error("at least one --include is required; refusing to hash the entire project implicitly")
try: rows=collect(a.include,a.exclude)
except Exception as e: print(f"FAIL: {e}"); sys.exit(1)
if not rows: print("NO_FILES_MATCHED"); sys.exit(1)
data={"schema_version":3,"root":str(root),"project_id":project_id,
      "task_id":task_identity["task_id"] if task_identity else None,
      "baseline_id":task_identity["baseline_id"] if task_identity else None,
      "git_base_commit":task_identity["git_base_commit"] if task_identity else None,
      "generated_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
      "algorithm":"SHA-256","include_patterns":a.include,"exclude_patterns":a.exclude,
      "files":rows,"limitations":["Manifest is bound to this exact project root and project identity.",
      "Task-bound manifests also bind TASK_ID, BASELINE_ID and task-start Git commit.",
      "Only explicitly selected files/patterns are included.",
      "External dependencies, submodules, environment variables, toolchain and hardware state must be recorded separately.",
      "Hashes prove byte identity, not engineering correctness."]}
out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding='utf-8')
print(f"LOCKED: {len(rows)} files -> {out}")
