# 阶段门禁记录

- 任务ID/阶段：
- 阶段目标：
- 前置条件：
- 输入及版本：
- 授权范围：
- 实际执行动作：
- 输出：
- 验证命令/工具版本：
- 原始证据路径：
- 结果：PASS / FAIL / BLOCKED / BLOCKED_BY_AUTH / NOT_RUN / UNAVAILABLE / NOT_APPLICABLE
- 未解决问题：
- 例外及批准：
- 下一阶段准入：
- 审核时间：
