#!/usr/bin/env python3
"""Validate task record structure, lifecycle history, gates and evidence references."""
from pathlib import Path
import argparse,csv,re,sys
STATES={"NEW","DISCOVERING","INPUT_LOCKED","PLANNED","EXECUTING","VERIFYING","PAUSED","BLOCKED","ACCEPTED","CLOSED"}
ALLOWED={"NEW":{"DISCOVERING","PAUSED","BLOCKED"},"DISCOVERING":{"INPUT_LOCKED","PAUSED","BLOCKED"},"INPUT_LOCKED":{"PLANNED","DISCOVERING","PAUSED","BLOCKED"},"PLANNED":{"EXECUTING","PAUSED","BLOCKED"},"EXECUTING":{"VERIFYING","PAUSED","BLOCKED"},"VERIFYING":{"EXECUTING","ACCEPTED","PAUSED","BLOCKED"},"ACCEPTED":{"CLOSED","BLOCKED"},"PAUSED":{"DISCOVERING","INPUT_LOCKED","PLANNED","EXECUTING","VERIFYING","BLOCKED"},"BLOCKED":{"DISCOVERING","INPUT_LOCKED","PLANNED","PAUSED"},"CLOSED":set()}
FILES=["STATE_CARD.md","STARTUP_RECEIPT.md","PROJECT_DISCOVERY_REPORT.md","INPUT_LOCK.md","TASK_PLAN.md","STATUS.md","STATE_HISTORY.csv","DECISIONS.md","HANDOFF.md"]
PLACE={"","待填写","TODO","TBD","<填写>","-","待确认"}
def field(path,label):
 if not path.exists(): return ""
 m=re.search(rf"^[ \t]*-[ \t]*{re.escape(label)}[ \t]*[:：][ \t]*(.*)$",path.read_text(encoding="utf-8"),re.M)
 return m.group(1).strip() if m else ""
ap=argparse.ArgumentParser();ap.add_argument("task_dir");ap.add_argument("--mode",choices=["structure","acceptance"],default="structure");a=ap.parse_args();r=Path(a.task_dir).resolve();err=[]
for f in FILES:
 if not (r/f).is_file():err.append("MISSING_FILE:"+f)
for d in ["STAGE_GATES","evidence"]:
 if not (r/d).is_dir():err.append("MISSING_DIR:"+d)
status=r/"STATUS.md";state=field(status,"生命周期")
if state not in STATES:err.append("INVALID_OR_MISSING_STATE:"+state)
taskid=field(status,"任务ID")
if not taskid or taskid in PLACE:err.append("STATUS_TASK_ID_EMPTY")
elif taskid != r.name:err.append(f"STATUS_TASK_ID_MISMATCH: expected {r.name}, got {taskid}")
if a.mode=="acceptance":
 required={"STATE_CARD.md":["任务ID","用户需求原文/目标","任务等级","主专业及交叉专业","本次验收目标"],"STARTUP_RECEIPT.md":["任务ID","实际工作目录","已读取通用规则及版本","允许执行范围"],"PROJECT_DISCOVERY_REPORT.md":["项目路径","工程类型及证据","扫描范围/排除范围"],"INPUT_LOCK.md":["任务ID","锁定时间","项目根目录","哈希算法"],"TASK_PLAN.md":["任务目标","验收标准","阶段计划"]}
 for fn,labels in required.items():
  p=r/fn
  if p.exists():
   txt=p.read_text(encoding="utf-8")
   for label in labels:
    m=re.search(rf"^[ \t]*[-*][ \t]*{re.escape(label)}[ \t]*[:：][ \t]*(.*)$",txt,re.M)
    if not m or m.group(1).strip() in PLACE:err.append(f"EMPTY_REQUIRED:{fn}:{label}")
 hist=r/"STATE_HISTORY.csv";rows=list(csv.DictReader(hist.open(encoding="utf-8",newline=""))) if hist.exists() else []
 if state!="NEW" and not rows:err.append("STATE_HISTORY_EMPTY_FOR_ADVANCED_STATE")
 prev=None
 for n,row in enumerate(rows,2):
  fr=row.get("from_state","").strip();to=row.get("to_state","").strip()
  if fr not in STATES or to not in STATES:err.append(f"HISTORY_BAD_STATE_LINE_{n}");continue
  if to not in ALLOWED.get(fr,set()):err.append(f"ILLEGAL_TRANSITION_LINE_{n}:{fr}->{to}")
  if prev is not None and fr!=prev:err.append(f"HISTORY_DISCONTINUITY_LINE_{n}")
  if any(not row.get(k,"").strip() for k in ["timestamp","reason","session_id"]):err.append(f"HISTORY_MISSING_AUDIT_FIELDS_LINE_{n}")
  prev=to
 if rows and prev!=state:err.append("STATUS_HISTORY_MISMATCH")
 if state in {"ACCEPTED","CLOSED"}:
  gates=list((r/"STAGE_GATES").glob("*.md")) if (r/"STAGE_GATES").exists() else []
  if not gates:err.append("ACCEPTED_WITHOUT_GATE_RECORDS")
  if not any(re.search(r"结果[：:]\s*PASS",g.read_text(encoding="utf-8")) for g in gates):err.append("ACCEPTED_WITHOUT_PASS_GATE")
  if not (r/"HANDOFF.md").is_file() or field(r/"HANDOFF.md","任务ID/目标") in PLACE:err.append("ACCEPTED_WITHOUT_HANDOFF")
if err:print("FAIL: task validation failed");print("\n".join(err));sys.exit(1)
print(f"PASS: task {taskid or '(unassigned)'} passed {a.mode} checks; not proof of engineering correctness.")
