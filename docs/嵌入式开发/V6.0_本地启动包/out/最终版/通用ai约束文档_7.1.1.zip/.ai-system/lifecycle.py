#!/usr/bin/env python3
"""Evidence, lifecycle gates and deterministic engineering summaries."""

from __future__ import annotations

import json
import hashlib
import os
from pathlib import Path
import platform
import subprocess
import sys
from typing import Any

from state_core import (
    NEXT_STATUSES,
    SCHEMA_VERSION,
    StateError,
    StateStore,
    file_sha256,
    new_id,
    utc_now,
)


MAX_EVIDENCE_BYTES = 20 * 1024 * 1024
SUMMARY_TYPES = {
    "INITIALIZATION", "STAGE", "TECHNICAL", "ISSUE_CLOSURE", "CHANGE",
    "MILESTONE", "RETROSPECTIVE", "HANDOFF", "RECOVERY", "MAINTENANCE", "COMPLETION",
}


def acceptance_records(task: dict[str, Any]) -> list[dict[str, Any]]:
    """Read 1.1 records and deterministically project legacy 1.0 strings."""
    records = []
    for index, item in enumerate(task.get("acceptance_criteria", [])):
        if isinstance(item, dict):
            records.append(dict(item))
            continue
        text = str(item).strip()
        digest = hashlib.sha256(f"{task.get('id')}:{index}:{text}".encode("utf-8")).hexdigest()[:24].upper()
        records.append({
            "id": f"ACPT-{digest}", "text": text, "required_evidence_types": [],
            "status": "UNVERIFIED", "evidence_refs": [], "verified_at": None,
            "migrated_from_legacy": True,
        })
    return records


def _input_manifest(store: StateStore, supplied: list[str]) -> list[dict[str, Any]]:
    values = []
    for item in supplied:
        path, relative = _project_relative_file(store, item)
        values.append({"path": relative, "sha256": file_sha256(path), "size": path.stat().st_size, "role": "input"})
    values.sort(key=lambda value: value["path"])
    return values


def _environment_fingerprint(working_directory: str) -> dict[str, Any]:
    details = {
        "python": platform.python_version(), "implementation": platform.python_implementation(),
        "platform": platform.platform(), "working_directory": working_directory,
    }
    encoded = json.dumps(details, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return {"sha256": "sha256:" + hashlib.sha256(encoded).hexdigest(), "details": details}


def observe_evidence(store: StateStore, evidence: dict[str, Any]) -> dict[str, Any]:
    artifact = (store.root / evidence.get("artifact_path", "")).resolve(strict=False)
    if not artifact.is_relative_to(store.root) or not artifact.is_file():
        return {"valid": False, "reason": "artifact-missing"}
    if file_sha256(artifact) != evidence.get("content_sha256"):
        return {"valid": False, "reason": "artifact-hash-changed"}
    for item in evidence.get("input_manifest", []):
        path = (store.root / item.get("path", "")).resolve(strict=False)
        if not path.is_relative_to(store.root) or not path.is_file():
            return {"valid": False, "reason": "input-missing", "path": item.get("path")}
        if file_sha256(path) != item.get("sha256") or path.stat().st_size != item.get("size"):
            return {"valid": False, "reason": "input-changed", "path": item.get("path")}
    return {"valid": True, "reason": None}


def load_registry() -> dict[str, Any]:
    path = Path(__file__).resolve().parent / "rules" / "lifecycle-registry.json"
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise StateError("RULE_REGISTRY_INVALID", "生命周期规则注册表无法读取", path=str(path), error=str(exc)) from exc
    if value.get("schema") != "aic.rule-registry" or value.get("schema_version") != SCHEMA_VERSION:
        raise StateError("RULE_REGISTRY_UNSUPPORTED", "生命周期规则注册表版本不兼容")
    return value


def list_rules() -> dict[str, Any]:
    registry = load_registry()
    return {
        "registry_version": registry["registry_version"],
        "rules": registry["rules"],
        "task_transitions": registry["task_transitions"],
        "next_transitions": registry["next_transitions"],
    }


def _project_relative_file(store: StateStore, supplied: str) -> tuple[Path, str]:
    path = Path(supplied)
    if not path.is_absolute():
        path = store.root / path
    resolved = path.resolve(strict=False)
    if not resolved.is_relative_to(store.root):
        raise StateError("PATH_OUTSIDE_PROJECT", "证据文件必须位于项目根目录内", path=str(resolved))
    if not resolved.is_file():
        raise StateError("EVIDENCE_ARTIFACT_MISSING", "证据文件不存在", path=str(resolved))
    if resolved.is_symlink():
        raise StateError("PATH_SYMLINK_UNSUPPORTED", "证据文件不能是符号链接", path=str(resolved))
    size = resolved.stat().st_size
    if size > MAX_EVIDENCE_BYTES:
        raise StateError("EVIDENCE_SIZE_LIMIT", "证据文件超过阶段 3 单文件上限", size=size, limit=MAX_EVIDENCE_BYTES)
    return resolved, resolved.relative_to(store.root).as_posix()


def add_evidence(
    store: StateStore,
    task_id: str,
    evidence_type: str,
    result: str,
    artifact: str,
    expected_state_revision: int,
    session_id: str,
    limitations: list[str],
    acceptance_refs: list[str] | None = None,
    producer_kind: str = "IMPORTED",
    command_argv: list[str] | None = None,
    exit_code: int | None = None,
    tool_name: str | None = None,
    tool_version: str | None = None,
    inputs: list[str] | None = None,
    working_directory: str | None = None,
    result_basis: str | None = None,
) -> dict[str, Any]:
    task = store._load_entity("task", task_id)
    if task is None:
        raise StateError("TASK_NOT_FOUND", "任务不存在", task_id=task_id)
    if not evidence_type.strip() or not result.strip():
        raise StateError("INPUT_EVIDENCE_FIELDS_REQUIRED", "证据类型和结果不能为空")
    criteria = acceptance_records(task)
    requested_refs = list(dict.fromkeys(acceptance_refs or []))
    known_refs = {item["id"] for item in criteria}
    if not requested_refs:
        raise StateError("EVIDENCE_ACCEPTANCE_REQUIRED", "证据必须关联至少一条验收条件")
    unknown_refs = [item for item in requested_refs if item not in known_refs]
    if unknown_refs:
        raise StateError("EVIDENCE_ACCEPTANCE_UNKNOWN", "证据引用了不属于任务的验收条件", acceptance_refs=unknown_refs)
    normalized_kind = producer_kind.strip().upper()
    if normalized_kind not in {"COMMAND", "TOOL", "MANUAL", "IMPORTED"}:
        raise StateError("INPUT_EVIDENCE_PRODUCER_INVALID", "证据生产者类型无效", producer_kind=producer_kind)
    argv = [str(item) for item in (command_argv or [])]
    if normalized_kind == "COMMAND" and (not argv or exit_code is None):
        raise StateError("EVIDENCE_COMMAND_PROVENANCE_REQUIRED", "命令证据必须记录参数数组和退出码")
    if normalized_kind in {"COMMAND", "TOOL"} and not (tool_name or "").strip():
        raise StateError("EVIDENCE_TOOL_REQUIRED", "命令或工具证据必须记录工具名称")
    if normalized_kind in {"MANUAL", "IMPORTED"} and not (result_basis or "").strip():
        raise StateError("EVIDENCE_RESULT_BASIS_REQUIRED", "人工或导入证据必须记录结果依据")
    path, relative = _project_relative_file(store, artifact)
    now = utc_now()
    evidence_id = new_id("EVD")
    normalized_result = result.strip().upper()
    status = "VALID" if normalized_result in {"PASS", "SUCCESS", "OK", "VERIFIED"} else "FAILED"
    cwd = working_directory or "."
    if Path(cwd).is_absolute():
        resolved_cwd = Path(cwd).resolve(strict=False)
    else:
        resolved_cwd = (store.root / cwd).resolve(strict=False)
    if not resolved_cwd.is_relative_to(store.root):
        raise StateError("PATH_WORKING_DIRECTORY_INVALID", "证据工作目录必须位于项目内", path=str(resolved_cwd))
    relative_cwd = resolved_cwd.relative_to(store.root).as_posix() or "."
    input_manifest = _input_manifest(store, inputs or [])
    evidence = {
        "schema": "aic.evidence", "schema_version": SCHEMA_VERSION, "id": evidence_id,
        "project_id": task["project_id"], "revision": 1, "status": status,
        "evidence_type": evidence_type.strip(), "type": evidence_type.strip(),
        "source": relative, "producer": session_id, "captured_at": now,
        "project_revision": expected_state_revision, "git_commit": git_baseline(store.root).get("commit"),
        "input_refs": [task_id], "acceptance_refs": requested_refs, "artifact_path": relative,
        "content_sha256": file_sha256(path), "sha256": file_sha256(path), "size": path.stat().st_size,
        "artifact_manifest": [{"path": relative, "sha256": file_sha256(path), "size": path.stat().st_size, "role": "result"}],
        "input_manifest": input_manifest, "producer_kind": normalized_kind,
        "command_argv": argv, "exit_code": exit_code,
        "tool_name": (tool_name or "").strip() or None, "tool_version": (tool_version or "").strip() or None,
        "working_directory": relative_cwd, "environment_fingerprint": _environment_fingerprint(relative_cwd),
        "result_basis": (result_basis or "").strip() or None,
        "result": normalized_result, "validity": "VALID" if status == "VALID" else "UNKNOWN",
        "limitations": limitations, "invalidated_by": [], "created_at": now, "updated_at": now,
        "created_by": session_id, "updated_by": session_id, "extensions": {},
    }
    updated_task = dict(task)
    updated_task["revision"] = task["revision"] + 1
    updated_task["updated_at"] = now
    updated_task["updated_by"] = session_id
    updated_task["evidence_refs"] = list(dict.fromkeys([*task.get("evidence_refs", []), evidence_id]))
    updated_criteria = acceptance_records(updated_task)
    for criterion in updated_criteria:
        if criterion["id"] not in requested_refs:
            continue
        required_types = {str(item).upper() for item in criterion.get("required_evidence_types", [])}
        if required_types and evidence_type.strip().upper() not in required_types:
            raise StateError(
                "EVIDENCE_TYPE_MISMATCH", "证据类型不满足验收条件要求",
                acceptance_id=criterion["id"], required_types=sorted(required_types), actual=evidence_type.strip(),
            )
        criterion["evidence_refs"] = list(dict.fromkeys([*criterion.get("evidence_refs", []), evidence_id]))
        criterion["status"] = "VERIFIED" if status == "VALID" else "UNVERIFIED"
        criterion["verified_at"] = now if status == "VALID" else None
    updated_task["acceptance_criteria"] = updated_criteria
    changes = [
        store._change("evidence", evidence, 0, "evidence.captured"),
        store._change("task", updated_task, task["revision"], "task.evidence-linked"),
    ]
    committed = store.commit(changes, expected_state_revision, session_id)
    return {"evidence": evidence, "task_revision": updated_task["revision"], **committed}


def verify_evidence(
    store: StateStore,
    evidence_id: str,
    expected_state_revision: int,
    expected_entity_revision: int,
    session_id: str,
) -> dict[str, Any]:
    evidence = store._load_entity("evidence", evidence_id)
    if evidence is None:
        raise StateError("EVIDENCE_NOT_FOUND", "证据不存在", evidence_id=evidence_id)
    if evidence.get("revision") != expected_entity_revision:
        raise StateError("ENTITY_REVISION_CONFLICT", "证据实体修订已变化", expected=expected_entity_revision, actual=evidence.get("revision"))
    path = (store.root / evidence["artifact_path"]).resolve(strict=False)
    observation = observe_evidence(store, evidence)
    observed = "VALID" if observation["valid"] else ("UNAVAILABLE" if observation["reason"].endswith("missing") else "CORRUPT")
    reason = observation["reason"]
    actual_hash = file_sha256(path) if path.is_file() else None
    if observed == "VALID":
        return {"changed": False, "evidence": evidence, "observed": observed, "actual_sha256": actual_hash}
    return invalidate_evidence(
        store, evidence_id, reason or "verification-failed", expected_state_revision,
        expected_entity_revision, session_id, forced_status=observed,
    )


def invalidate_evidence(
    store: StateStore,
    evidence_id: str,
    reason: str,
    expected_state_revision: int,
    expected_entity_revision: int,
    session_id: str,
    forced_status: str = "STALE",
) -> dict[str, Any]:
    evidence = store._load_entity("evidence", evidence_id)
    if evidence is None:
        raise StateError("EVIDENCE_NOT_FOUND", "证据不存在", evidence_id=evidence_id)
    if not reason.strip():
        raise StateError("INPUT_INVALIDATION_REASON_REQUIRED", "证据失效原因不能为空")
    now = utc_now()
    updated = dict(evidence)
    updated["revision"] = expected_entity_revision + 1
    updated["status"] = forced_status
    updated["validity"] = "STALE" if forced_status == "STALE" else forced_status
    updated["invalidated_by"] = [*evidence.get("invalidated_by", []), {"reason": reason.strip(), "at": now, "session_id": session_id}]
    updated["updated_at"] = now
    updated["updated_by"] = session_id
    changes = [store._change("evidence", updated, expected_entity_revision, "evidence.invalidated")]
    affected_tasks: list[str] = []
    affected_summaries: list[str] = []
    for entity in store._all_entities():
        if evidence_id not in entity.get("evidence_refs", []):
            continue
        if entity.get("schema") == "aic.task":
            changed = dict(entity)
            changed["revision"] = entity["revision"] + 1
            if entity.get("status") in {"VERIFYING", "COMPLETED"}:
                changed["status"] = "STALE"
            criteria = acceptance_records(changed)
            for criterion in criteria:
                if evidence_id in criterion.get("evidence_refs", []):
                    criterion["status"] = "STALE"
                    criterion["verified_at"] = None
            changed["acceptance_criteria"] = criteria
            changed["updated_at"] = now
            changed["updated_by"] = session_id
            changes.append(store._change("task", changed, entity["revision"], "task.evidence-stale"))
            affected_tasks.append(entity["id"])
        if entity.get("schema") == "aic.summary" and entity.get("status") == "VERIFIED":
            changed = dict(entity)
            changed["revision"] = entity["revision"] + 1
            changed["status"] = "STALE"
            changed["updated_at"] = now
            changed["updated_by"] = session_id
            changes.append(store._change("summary", changed, entity["revision"], "summary.evidence-stale"))
            affected_summaries.append(entity["id"])
    committed = store.commit(changes, expected_state_revision, session_id)
    return {"changed": True, "evidence": updated, "affected_tasks": affected_tasks, "affected_summaries": affected_summaries, **committed}


def transition_task(
    store: StateStore,
    task_id: str,
    to_status: str,
    expected_entity_revision: int,
    expected_state_revision: int,
    session_id: str,
    completed: list[str],
    remaining: list[str],
    blockers: list[str],
    resolved_blockers: list[str],
    failed_attempts: list[str],
    unknowns: list[str],
    resume_condition: str | None,
    resolution_condition: str | None,
) -> dict[str, Any]:
    task = store._load_entity("task", task_id)
    if task is None:
        raise StateError("TASK_NOT_FOUND", "任务不存在", task_id=task_id)
    registry = load_registry()
    allowed = registry["task_transitions"].get(task["status"], [])
    if to_status not in allowed:
        raise StateError("TASK_TRANSITION_INVALID", "任务状态转换不允许", current=task["status"], requested=to_status, allowed=allowed)
    if to_status == "PAUSED" and not resume_condition:
        raise StateError("TASK_RESUME_CONDITION_REQUIRED", "暂停任务必须提供恢复条件")
    if to_status == "BLOCKED" and not resolution_condition:
        raise StateError("TASK_RESOLUTION_CONDITION_REQUIRED", "阻断任务必须提供解除条件")
    if to_status == "FAILED" and not failed_attempts:
        raise StateError("TASK_FAILURE_EVIDENCE_REQUIRED", "失败任务必须记录失败方案或原因")
    now = utc_now()
    updated = dict(task)
    updated["revision"] = expected_entity_revision + 1
    updated["status"] = to_status
    updated["updated_at"] = now
    updated["updated_by"] = session_id
    for key, values in (
        ("completed_work", completed), ("remaining_work", remaining), ("blockers", blockers),
        ("failed_attempts", failed_attempts), ("unknowns", unknowns),
    ):
        if values:
            updated[key] = list(dict.fromkeys([*task.get(key, []), *values]))
    if completed:
        updated["remaining_work"] = [item for item in updated.get("remaining_work", []) if item not in set(completed)]
    if resolved_blockers:
        updated["blockers"] = [item for item in updated.get("blockers", []) if item not in set(resolved_blockers)]
    if resume_condition:
        updated["resume_condition"] = resume_condition
    if resolution_condition:
        updated["resolution_condition"] = resolution_condition
    if to_status == "COMPLETED":
        _completion_gate(store, updated)
    committed = store.commit(
        [store._change("task", updated, expected_entity_revision, "task.status.changed")],
        expected_state_revision, session_id,
    )
    return {"task": updated, **committed}


def _completion_gate(store: StateStore, task: dict[str, Any]) -> None:
    failures: list[dict[str, Any]] = []
    criteria = acceptance_records(task)
    if not criteria:
        failures.append({"code": "ACCEPTANCE_CRITERIA_MISSING"})
    for criterion in criteria:
        if criterion.get("status") != "VERIFIED":
            failures.append({"code": "ACCEPTANCE_NOT_VERIFIED", "acceptance_id": criterion.get("id")})
            continue
        criterion_evidence = [store._load_entity("evidence", item) for item in criterion.get("evidence_refs", [])]
        current = [item for item in criterion_evidence if item and item.get("status") == "VALID" and item.get("validity") == "VALID" and observe_evidence(store, item)["valid"]]
        if not current:
            failures.append({"code": "ACCEPTANCE_EVIDENCE_MISSING", "acceptance_id": criterion.get("id")})
    if task.get("remaining_work"):
        failures.append({"code": "REMAINING_WORK_EXISTS", "items": task["remaining_work"]})
    if task.get("blockers"):
        failures.append({"code": "BLOCKERS_EXIST", "items": task["blockers"]})
    evidence = [store._load_entity("evidence", item) for item in task.get("evidence_refs", [])]
    valid_evidence = [item for item in evidence if item and item.get("status") == "VALID" and item.get("validity") == "VALID" and observe_evidence(store, item)["valid"]]
    if not valid_evidence:
        failures.append({"code": "VALID_EVIDENCE_MISSING"})
    summaries = [store._load_entity("summary", item) for item in task.get("summary_refs", [])]
    if not any(item and item.get("status") == "VERIFIED" for item in summaries):
        failures.append({"code": "VERIFIED_SUMMARY_MISSING"})
    active_next = []
    for action_id in task.get("next_action_refs", []):
        action = store._load_entity("next_action", action_id)
        if action and action.get("status") not in {"DONE", "CANCELLED", "STALE"}:
            active_next.append(action_id)
    if active_next:
        failures.append({"code": "ACTIVE_NEXT_ACTIONS_EXIST", "items": active_next})
    if failures:
        raise StateError("TASK_COMPLETION_GATE_FAILED", "任务不满足完成门禁", failures=failures)


def update_next(
    store: StateStore,
    action_id: str,
    to_status: str,
    expected_entity_revision: int,
    expected_state_revision: int,
    session_id: str,
) -> dict[str, Any]:
    action = store._load_entity("next_action", action_id)
    if action is None:
        raise StateError("NEXT_ACTION_NOT_FOUND", "下一步不存在", next_action_id=action_id)
    if to_status not in NEXT_STATUSES:
        raise StateError("INPUT_NEXT_STATUS_INVALID", "下一步状态无效", status=to_status)
    allowed = load_registry()["next_transitions"].get(action["status"], [])
    if to_status not in allowed:
        raise StateError("NEXT_TRANSITION_INVALID", "下一步状态转换不允许", current=action["status"], requested=to_status, allowed=allowed)
    updated = dict(action)
    updated["revision"] = expected_entity_revision + 1
    updated["status"] = to_status
    updated["updated_at"] = utc_now()
    updated["updated_by"] = session_id
    committed = store.commit([store._change("next_action", updated, expected_entity_revision, "next-action.status.changed")], expected_state_revision, session_id)
    return {"next_action": updated, **committed}


def git_baseline(root: Path) -> dict[str, Any]:
    try:
        process = subprocess.run(
            ["git", "-C", str(root), "status", "--porcelain=v1", "--branch"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=8, shell=False,
        )
        commit = subprocess.run(
            ["git", "-C", str(root), "rev-parse", "HEAD"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=8, shell=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"available": False, "error": str(exc), "commit": None, "status": []}
    return {
        "available": process.returncode == 0, "commit": commit.stdout.strip() if commit.returncode == 0 else None,
        "status": process.stdout.splitlines()[:200], "truncated": len(process.stdout.splitlines()) > 200,
    }


def generate_summary(
    store: StateStore,
    task_id: str,
    summary_type: str,
    trigger: str,
    expected_state_revision: int,
    session_id: str,
) -> dict[str, Any]:
    if summary_type not in SUMMARY_TYPES:
        raise StateError("INPUT_SUMMARY_TYPE_INVALID", "总结类型无效", summary_type=summary_type)
    task = store._load_entity("task", task_id)
    if task is None:
        raise StateError("TASK_NOT_FOUND", "任务不存在", task_id=task_id)
    if not trigger.strip():
        raise StateError("INPUT_SUMMARY_TRIGGER_REQUIRED", "总结触发原因不能为空")
    for item in store._all_entities():
        if item.get("schema") == "aic.summary" and item.get("task_id") == task_id and item.get("summary_type") == summary_type and item.get("source_state_revision") == expected_state_revision:
            return {"created": False, "duplicate_of": item["id"], "summary": item}
    evidence = [store._load_entity("evidence", item) for item in task.get("evidence_refs", [])]
    evidence = [item for item in evidence if item]
    next_actions = [store._load_entity("next_action", item) for item in task.get("next_action_refs", [])]
    next_actions = [item for item in next_actions if item]
    now = utc_now()
    summary_id = new_id("SUM")
    summary = {
        "schema": "aic.summary", "schema_version": SCHEMA_VERSION, "id": summary_id,
        "project_id": task["project_id"], "revision": 1, "status": "DRAFT",
        "summary_type": summary_type, "task_id": task_id, "session_id": session_id,
        "source_state_revision": expected_state_revision, "source_task_revision": task.get("revision"), "trigger": trigger.strip(),
        "git_baseline": git_baseline(store.root), "goal": task.get("normalized_goal"),
        "completed_work": task.get("completed_work", []), "remaining_work": task.get("remaining_work", []),
        "evidence_refs": [item["id"] for item in evidence],
        "evidence_status": [{"id": item["id"], "revision": item.get("revision"), "status": item["status"], "result": item.get("result"), "content_sha256": item.get("content_sha256")} for item in evidence],
        "facts": [
            {"kind": "task-status", "value": task.get("status")},
            {"kind": "completed-count", "value": len(task.get("completed_work", []))},
            {"kind": "evidence-count", "value": len(evidence)},
        ],
        "inferences": [], "unknowns": task.get("unknowns", []),
        "failed_attempts": task.get("failed_attempts", []), "risks": task.get("blockers", []),
        "recovery": task.get("resume_condition") or task.get("resolution_condition"),
        "next_action_refs": [item["id"] for item in sorted(next_actions, key=lambda value: (value.get("priority", 999), value["id"])) if item.get("status") not in {"DONE", "CANCELLED", "STALE"}],
        "created_at": now, "updated_at": now, "created_by": session_id, "updated_by": session_id,
        "extensions": {},
    }
    updated_task = dict(task)
    updated_task["revision"] = task["revision"] + 1
    updated_task["updated_at"] = now
    updated_task["updated_by"] = session_id
    updated_task["summary_refs"] = list(dict.fromkeys([*task.get("summary_refs", []), summary_id]))
    changes = [
        store._change("summary", summary, 0, "summary.generated"),
        store._change("task", updated_task, task["revision"], "task.summary-linked"),
    ]
    committed = store.commit(changes, expected_state_revision, session_id)
    return {"created": True, "summary": summary, "task_revision": updated_task["revision"], **committed}


def verify_summary(
    store: StateStore,
    summary_id: str,
    expected_entity_revision: int,
    expected_state_revision: int,
    session_id: str,
) -> dict[str, Any]:
    summary = store._load_entity("summary", summary_id)
    if summary is None:
        raise StateError("SUMMARY_NOT_FOUND", "总结不存在", summary_id=summary_id)
    if summary.get("source_state_revision", -1) > expected_state_revision:
        raise StateError("SUMMARY_SOURCE_REVISION_INVALID", "总结来源修订晚于当前状态")
    task = store._load_entity("task", summary.get("task_id"))
    expected_task_revision = int(summary.get("source_task_revision", -1)) + 1
    if task is None or int(task.get("revision", -1)) != expected_task_revision:
        raise StateError("SUMMARY_SOURCE_STALE", "总结生成后任务已经变化，必须重新生成", expected_task_revision=expected_task_revision, actual_task_revision=task.get("revision") if task else None)
    invalid = []
    for recorded in summary.get("evidence_status", []):
        current = store._load_entity("evidence", recorded.get("id"))
        if current is None or current.get("status") != "VALID" or current.get("revision") != recorded.get("revision"):
            invalid.append({"id": recorded.get("id"), "reason": "entity-changed-or-invalid"})
            continue
        observation = observe_evidence(store, current)
        if not observation["valid"]:
            invalid.append({"id": recorded.get("id"), **observation})
    if invalid:
        raise StateError("SUMMARY_EVIDENCE_INVALID", "总结包含无效证据，不能验证", evidence=invalid)
    updated = dict(summary)
    updated["revision"] = expected_entity_revision + 1
    updated["status"] = "VERIFIED"
    updated["verified_at"] = utc_now()
    updated["updated_at"] = updated["verified_at"]
    updated["updated_by"] = session_id
    committed = store.commit([store._change("summary", updated, expected_entity_revision, "summary.verified")], expected_state_revision, session_id)
    return {"summary": updated, **committed}
