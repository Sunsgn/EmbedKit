#!/usr/bin/env python3
"""Read-only diagnostics and conservative repair plans."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from concurrency import ConcurrencyManager, parse_time
from lifecycle import git_baseline, invalidate_evidence, observe_evidence
from state_core import (
    SCHEMA_VERSION,
    StateError,
    StateStore,
    atomic_write,
    canonical_bytes,
    file_sha256,
    new_id,
    pretty_bytes,
    read_json,
    sha256_bytes,
    utc_now,
)


AUTHORITATIVE_CODES = {
    "EVENT_JSON_INVALID", "EVENT_SEQUENCE_INVALID", "EVENT_CHAIN_INVALID", "EVENT_HASH_INVALID",
    "HEAD_EVENT_MISMATCH", "COMMITTED_TRANSACTION_MISSING", "COMMITTED_TRANSACTION_INVALID",
    "TRANSACTION_ENVELOPE_HASH_INVALID", "TRANSACTION_AFTER_HEAD",
}
REPLAYABLE_CODES = {"STATE_DERIVED_STALE", "ENTITY_SNAPSHOT_MISSING", "ENTITY_SNAPSHOT_INVALID", "ENTITY_SNAPSHOT_MISMATCH"}


def diagnose(store: StateStore) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    try:
        verification = store.verify()
    except StateError as exc:
        verification = {"healthy": False, "errors": [{"code": exc.code, **exc.details}]}
    for error in verification.get("errors", []):
        code = str(error.get("code"))
        severity = "CRITICAL" if code in AUTHORITATIVE_CODES else "ERROR"
        findings.append({"category": "state", "severity": severity, **error})

    manager = ConcurrencyManager(store)
    findings.extend(manager.diagnose_internal_mutexes())
    capacity = store.capacity_report()
    for warning in capacity["warnings"]:
        findings.append({"category": "capacity", "severity": "WARNING", "code": "STATE_CAPACITY_WARNING", **warning})
    sessions: dict[str, dict[str, Any]] = {}
    now = datetime.now(timezone.utc)
    for path in sorted((store.run / "sessions").glob("SES-*.json")):
        try:
            session = read_json(path)
            sessions[session["id"]] = session
            if session.get("status") == "ACTIVE" and parse_time(session.get("lease_expires_at", session.get("updated_at"))) <= now:
                findings.append({"category": "session", "severity": "WARNING", "code": "SESSION_LEASE_EXPIRED", "session_id": session["id"], "path": str(path)})
        except StateError as exc:
            findings.append({"category": "session", "severity": "ERROR", "code": "SESSION_RECORD_INVALID", "path": str(path), "error": exc.code})

    active_locks = []
    for path in sorted((store.run / "locks").glob("LOCK-*.json")):
        try:
            record = read_json(path)
        except StateError as exc:
            findings.append({"category": "lock", "severity": "ERROR", "code": "LOCK_RECORD_INVALID", "path": str(path), "error": exc.code})
            continue
        if record.get("status") != "ACTIVE":
            continue
        active_locks.append(record)
        owner = sessions.get(record.get("owner_session_id"))
        expired = parse_time(record["lease_expires_at"]) <= now
        if owner is None:
            findings.append({"category": "lock", "severity": "ERROR", "code": "LOCK_OWNER_MISSING", "lock_id": record["id"]})
        if expired:
            findings.append({"category": "lock", "severity": "WARNING", "code": "LOCK_LEASE_EXPIRED", "lock_id": record["id"], "owner_session_id": record.get("owner_session_id")})
    for index, left in enumerate(active_locks):
        for right in active_locks[index + 1 :]:
            overlaps = [(a, b) for a in left.get("scopes", []) for b in right.get("scopes", []) if manager.overlaps(a, b)]
            if overlaps:
                findings.append({"category": "lock", "severity": "CRITICAL", "code": "LOCK_ACTIVE_OVERLAP", "left": left["id"], "right": right["id"], "overlaps": overlaps})

    for path in sorted((store.run / "transactions").glob("TXN-*.json")):
        try:
            transaction = read_json(path)
        except StateError as exc:
            findings.append({"category": "transaction", "severity": "ERROR", "code": "RUN_TRANSACTION_INVALID", "path": str(path), "error": exc.code})
            continue
        if transaction.get("phase") not in {"COMMITTED", "ABORTED"}:
            committed = (store.committed / path.name).is_file()
            findings.append({"category": "transaction", "severity": "WARNING", "code": "RUN_TRANSACTION_INCOMPLETE", "path": str(path), "transaction_id": transaction.get("transaction_id"), "phase": transaction.get("phase"), "committed_envelope_exists": committed})

    try:
        entities = store._all_entities()
    except StateError:
        # State verification already records the exact invalid snapshot. Keep
        # diagnosis running so a replay plan can be produced.
        entities = []
    for evidence in (item for item in entities if item.get("schema") == "aic.evidence" and item.get("status") == "VALID"):
        observation = observe_evidence(store, evidence)
        if not observation["valid"]:
            findings.append({
                "category": "evidence", "severity": "ERROR", "code": "EVIDENCE_DRIFT_DETECTED",
                "evidence_id": evidence["id"], "reason": observation.get("reason"),
                "path": observation.get("path"),
            })

    current_git = git_baseline(store.root)
    if current_git.get("commit"):
        for summary in (item for item in entities if item.get("schema") == "aic.summary" and item.get("status") == "VERIFIED"):
            recorded = summary.get("git_baseline", {}).get("commit")
            if recorded and recorded != current_git["commit"]:
                findings.append({
                    "category": "git", "severity": "WARNING", "code": "GIT_BASELINE_DRIFT",
                    "summary_id": summary["id"], "recorded_commit": recorded,
                    "current_commit": current_git["commit"],
                    "message": "需要重新核验证据和总结，不能继续沿用旧结论",
                })

    try:
        view_check = store.check_views()
        if not view_check.get("valid", True):
            findings.append({"category": "view", "severity": "WARNING", "code": "VIEW_MANUAL_EDIT_CONFLICT", "details": view_check})
    except StateError as exc:
        findings.append({"category": "view", "severity": "WARNING", "code": exc.code, **exc.details})

    critical = [item for item in findings if item["severity"] == "CRITICAL"]
    return {
        "diagnosed_at": utc_now(), "state_revision": verification.get("state_revision"), "capacity": capacity,
        "healthy": not findings, "read_only_required": bool(critical),
        "findings": findings, "counts": {
            "critical": len(critical),
            "error": len([item for item in findings if item["severity"] == "ERROR"]),
            "warning": len([item for item in findings if item["severity"] == "WARNING"]),
        },
    }


def create_repair_plan(store: StateStore) -> dict[str, Any]:
    diagnosis = diagnose(store)
    actions: list[dict[str, Any]] = []
    codes = {item["code"] for item in diagnosis["findings"]}
    if codes & REPLAYABLE_CODES and not codes & AUTHORITATIVE_CODES:
        actions.append({"type": "REPLAY_AUTHORITATIVE_HISTORY", "automatic": True})
    for finding in diagnosis["findings"]:
        if finding["code"] == "RUN_TRANSACTION_INCOMPLETE":
            actions.append({"type": "RECONCILE_RUN_TRANSACTION", "automatic": True, "path": finding["path"], "committed_envelope_exists": finding["committed_envelope_exists"]})
        elif finding["code"] == "SESSION_LEASE_EXPIRED":
            actions.append({"type": "MARK_SESSION_CRASHED", "automatic": True, "session_id": finding["session_id"]})
        elif finding["code"] in {"LOCK_LEASE_EXPIRED", "LOCK_OWNER_MISSING"}:
            actions.append({"type": "USER_REVIEW_EXPIRED_LOCK", "automatic": False, "lock_id": finding["lock_id"]})
        elif finding["code"] == "INTERNAL_MUTEX_ORPHANED":
            actions.append({
                "type": "RECOVER_ORPHANED_INTERNAL_MUTEX", "automatic": True,
                "path": finding["path"], "mutex_kind": finding["mutex_kind"],
                "observed_pid": finding.get("pid"), "observed_age_seconds": finding.get("age_seconds"),
            })
        elif finding["code"] == "EVIDENCE_DRIFT_DETECTED":
            actions.append({
                "type": "INVALIDATE_DRIFTED_EVIDENCE", "automatic": True,
                "evidence_id": finding["evidence_id"], "reason": finding.get("reason") or "doctor-detected-drift",
            })
        elif finding["code"] in AUTHORITATIVE_CODES:
            actions.append({"type": "MANUAL_AUTHORITATIVE_RECOVERY", "automatic": False, "finding": finding})
    plan_id = new_id("RPL")
    plan = {
        "schema": "aic.repair-plan", "schema_version": SCHEMA_VERSION, "plan_id": plan_id,
        "created_at": utc_now(), "project_root": str(store.root),
        "expected_state_revision": diagnosis.get("state_revision"),
        "diagnosis_hash": sha256_bytes(canonical_bytes(diagnosis)), "diagnosis": diagnosis,
        "actions": actions, "status": "PLANNED",
    }
    path = store.ai / "audit" / "repair-plans" / f"{plan_id}.json"
    atomic_write(path, pretty_bytes(plan))
    return {"plan": plan, "path": str(path)}


def apply_repair_plan(store: StateStore, plan_path: str, session_id: str, acknowledged: bool) -> dict[str, Any]:
    path = Path(plan_path).resolve(strict=False)
    allowed = (store.ai / "audit" / "repair-plans").resolve(strict=False)
    if not path.is_relative_to(allowed) or not path.is_file():
        raise StateError("PATH_REPAIR_PLAN_INVALID", "修复计划必须来自项目审计目录", path=str(path))
    if not acknowledged:
        raise StateError("USER_DECISION_REQUIRED", "应用修复计划需要明确确认")
    manager = ConcurrencyManager(store)
    manager._session(session_id)
    plan = read_json(path)
    if plan.get("status") != "PLANNED":
        raise StateError("STATE_REPAIR_PLAN_USED", "修复计划不是待执行状态", status=plan.get("status"))
    current_head = read_json(store.head_path)
    if current_head.get("state_revision") != plan.get("expected_state_revision"):
        raise StateError("STATE_REVISION_CONFLICT", "修复计划生成后状态已经变化", expected=plan.get("expected_state_revision"), actual=current_head.get("state_revision"))
    manual = [item for item in plan.get("actions", []) if not item.get("automatic")]
    if manual:
        raise StateError("STATE_REPAIR_MANUAL_ACTIONS", "计划包含不能自动执行的修复项", actions=manual)
    results = []
    for action in plan.get("actions", []):
        if action["type"] == "REPLAY_AUTHORITATIVE_HISTORY":
            results.append({"type": action["type"], "result": store.replay_authoritative_history(session_id)})
        elif action["type"] == "RECONCILE_RUN_TRANSACTION":
            tx_path = Path(action["path"])
            tx = read_json(tx_path)
            tx["phase"] = "COMMITTED" if action["committed_envelope_exists"] else "ABORTED"
            tx["doctor_reconciled_at"] = utc_now()
            tx["doctor_reconciled_by"] = session_id
            atomic_write(tx_path, pretty_bytes(tx))
            results.append({"type": action["type"], "path": str(tx_path), "phase": tx["phase"]})
        elif action["type"] == "MARK_SESSION_CRASHED":
            session_path = store.run / "sessions" / f"{action['session_id']}.json"
            session = read_json(session_path)
            session["status"] = "CRASHED"
            session["updated_at"] = utc_now()
            atomic_write(session_path, pretty_bytes(session))
            results.append({"type": action["type"], "session_id": action["session_id"]})
        elif action["type"] == "RECOVER_ORPHANED_INTERNAL_MUTEX":
            mutex_path = Path(action["path"]).resolve(strict=False)
            allowed_mutexes = {store.lock_path.resolve(strict=False), manager.registry_mutex.resolve(strict=False)}
            if mutex_path not in allowed_mutexes or not mutex_path.is_file():
                raise StateError("PATH_INTERNAL_MUTEX_INVALID", "内部互斥锁路径无效或已经变化", path=str(mutex_path))
            live_findings = manager.diagnose_internal_mutexes()
            matching = [item for item in live_findings if item.get("code") == "INTERNAL_MUTEX_ORPHANED" and Path(item["path"]).resolve(strict=False) == mutex_path]
            if not matching:
                raise StateError("INTERNAL_MUTEX_RECOVERY_STALE", "内部互斥锁状态已经变化，必须重新诊断", path=str(mutex_path))
            repair_id = new_id("RPR")
            backup_dir = store.ai / "audit" / "repairs" / repair_id
            backup_dir.mkdir(parents=True, exist_ok=False)
            backup_path = backup_dir / (mutex_path.name + ".backup")
            atomic_write(backup_path, mutex_path.read_bytes())
            mutex_path.unlink()
            report = {
                "schema": "aic.internal-mutex-recovery", "schema_version": SCHEMA_VERSION,
                "repair_id": repair_id, "mutex_kind": action["mutex_kind"],
                "original_path": str(mutex_path), "backup_path": str(backup_path),
                "recovered_at": utc_now(), "recovered_by": session_id,
                "diagnosis": matching[0],
            }
            atomic_write(backup_dir / "report.json", pretty_bytes(report))
            results.append({"type": action["type"], "repair_id": repair_id, "mutex_kind": action["mutex_kind"], "backup": str(backup_path)})
        elif action["type"] == "INVALIDATE_DRIFTED_EVIDENCE":
            evidence = store._load_entity("evidence", action["evidence_id"])
            if evidence is None:
                raise StateError("EVIDENCE_NOT_FOUND", "漂移证据已经不存在", evidence_id=action["evidence_id"])
            head = read_json(store.head_path)
            invalidated = invalidate_evidence(
                store, evidence["id"], action["reason"], head["state_revision"],
                evidence["revision"], session_id,
                forced_status="UNAVAILABLE" if str(action["reason"]).endswith("missing") else "CORRUPT",
            )
            results.append({"type": action["type"], "evidence_id": evidence["id"], "state_revision": invalidated["state_revision"]})
    plan["status"] = "APPLIED"
    plan["applied_at"] = utc_now()
    plan["applied_by"] = session_id
    plan["results"] = results
    atomic_write(path, pretty_bytes(plan))
    return {"plan_id": plan["plan_id"], "results": results, "post_diagnosis": diagnose(store)}
