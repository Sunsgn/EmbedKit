#!/usr/bin/env python3
"""Local-session leases and overlapping scope protection.

These locks coordinate processes in one working copy only. They are not a
distributed lock and expiry never grants automatic ownership transfer.
"""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
import os
from pathlib import Path, PurePosixPath
import secrets
from typing import Any, Iterator

from state_core import SCHEMA_VERSION, StateError, StateStore, atomic_write, new_id, pretty_bytes, read_json, utc_now


MIN_LEASE_SECONDS = 30
MAX_LEASE_SECONDS = 3600
INTERNAL_MUTEX_STALE_SECONDS = 300


def parse_time(value: str) -> datetime:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (AttributeError, ValueError) as exc:
        raise StateError("LOCK_TIME_INVALID", "锁或会话时间格式无效", value=value) from exc


class ConcurrencyManager:
    def __init__(self, store: StateStore) -> None:
        self.store = store
        self.sessions = store.run / "sessions"
        self.locks = store.run / "locks"
        self.registry_mutex = self.locks / ".registry.lock"

    @contextmanager
    def _registry_lock(self) -> Iterator[None]:
        self.locks.mkdir(parents=True, exist_ok=True)
        token = secrets.token_hex(16)
        try:
            descriptor = os.open(self.registry_mutex, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError as exc:
            raise StateError("LOCK_REGISTRY_BUSY", "锁注册表正在被其他进程更新，请重新读取后重试") from exc
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(pretty_bytes({"token": token, "pid": os.getpid(), "created_at": utc_now()}))
            handle.flush()
            os.fsync(handle.fileno())
        try:
            yield
        finally:
            try:
                current = read_json(self.registry_mutex)
                if current.get("token") == token:
                    self.registry_mutex.unlink()
            except (StateError, OSError):
                pass

    def _session(self, session_id: str, require_active: bool = True) -> dict[str, Any]:
        path = self.sessions / f"{session_id}.json"
        if not path.is_file():
            raise StateError("SESSION_NOT_FOUND", "会话不存在", session_id=session_id)
        session = read_json(path)
        if require_active and session.get("status") != "ACTIVE":
            raise StateError("SESSION_NOT_ACTIVE", "会话不是活动状态", session_id=session_id, status=session.get("status"))
        if require_active and parse_time(session.get("lease_expires_at", session.get("updated_at"))) <= datetime.now(timezone.utc):
            raise StateError("SESSION_LEASE_EXPIRED", "会话租约已过期，禁止继续写入", session_id=session_id, lease_expires_at=session.get("lease_expires_at"))
        return session

    def _lock_records(self) -> list[dict[str, Any]]:
        records = []
        for path in sorted(self.locks.glob("LOCK-*.json")):
            try:
                records.append(read_json(path))
            except StateError:
                records.append({"id": path.stem, "status": "CORRUPT", "path": str(path)})
        return records

    def normalize_scope(self, scope: str) -> str:
        if scope == "project:state":
            return scope
        if scope.startswith("task:"):
            task_id = scope[5:]
            if not task_id.startswith("TASK-"):
                raise StateError("INPUT_LOCK_SCOPE_INVALID", "task 范围必须引用 TASK ID", scope=scope)
            return "task:" + task_id
        if scope.startswith("file:") or scope.startswith("path:"):
            kind, raw = scope.split(":", 1)
            if not raw or "\\" in raw:
                raw = raw.replace("\\", "/")
            pure = PurePosixPath(raw)
            if pure.is_absolute() or ".." in pure.parts or not pure.parts:
                raise StateError("PATH_LOCK_SCOPE_INVALID", "文件锁范围必须是项目内相对路径", scope=scope)
            normalized = pure.as_posix().rstrip("/")
            candidate = (self.store.root / Path(*pure.parts)).resolve(strict=False)
            if not candidate.is_relative_to(self.store.root):
                raise StateError("PATH_LOCK_SCOPE_ESCAPE", "文件锁范围逃逸项目根", scope=scope)
            return f"{kind}:{normalized}"
        raise StateError("INPUT_LOCK_SCOPE_INVALID", "锁范围必须使用 project:state、task:、file: 或 path:", scope=scope)

    @staticmethod
    def overlaps(left: str, right: str) -> bool:
        left_kind, left_value = left.split(":", 1)
        right_kind, right_value = right.split(":", 1)
        if left_kind == "project" or right_kind == "project":
            return left == right
        if left_kind == "task" or right_kind == "task":
            return left_kind == right_kind and left_value == right_value
        left_parts = PurePosixPath(left_value).parts
        right_parts = PurePosixPath(right_value).parts
        if left_kind == "file" and right_kind == "file":
            return left_parts == right_parts
        if left_kind == "path" and right_kind == "path":
            shorter = min(len(left_parts), len(right_parts))
            return left_parts[:shorter] == right_parts[:shorter]
        if left_kind == "path":
            return right_parts[: len(left_parts)] == left_parts
        return left_parts[: len(right_parts)] == right_parts

    @staticmethod
    def covers(held: str, wanted: str) -> bool:
        """Return whether an owned scope fully covers a requested write scope."""
        held_kind, held_value = held.split(":", 1)
        wanted_kind, wanted_value = wanted.split(":", 1)
        if held_kind == "project" or wanted_kind == "project":
            return held == wanted
        if held_kind == "task" or wanted_kind == "task":
            return held == wanted
        held_parts = PurePosixPath(held_value).parts
        wanted_parts = PurePosixPath(wanted_value).parts
        if held_kind == "file":
            return wanted_kind == "file" and held_parts == wanted_parts
        return wanted_parts[: len(held_parts)] == held_parts

    def acquire(self, session_id: str, scopes: list[str], lease_seconds: int) -> dict[str, Any]:
        self._session(session_id)
        if not scopes:
            raise StateError("INPUT_LOCK_SCOPE_REQUIRED", "至少需要一个锁范围")
        if not MIN_LEASE_SECONDS <= lease_seconds <= MAX_LEASE_SECONDS:
            raise StateError("INPUT_LEASE_RANGE", "租约时长超出允许范围", minimum=MIN_LEASE_SECONDS, maximum=MAX_LEASE_SECONDS)
        normalized = sorted(set(self.normalize_scope(item) for item in scopes))
        now = datetime.now(timezone.utc)
        with self._registry_lock():
            for record in self._lock_records():
                if record.get("status") != "ACTIVE":
                    continue
                conflicts = [(wanted, held) for wanted in normalized for held in record.get("scopes", []) if self.overlaps(wanted, held)]
                if not conflicts:
                    continue
                expired = parse_time(record["lease_expires_at"]) <= now
                code = "LOCK_EXPIRED_NEEDS_REVIEW" if expired else "LOCK_SCOPE_CONFLICT"
                raise StateError(code, "锁范围与现有锁重叠，禁止自动接管", conflicting_lock=record.get("id"), owner_session_id=record.get("owner_session_id"), overlaps=conflicts, lease_expires_at=record.get("lease_expires_at"))
            lock_id = new_id("LOCK")
            acquired = utc_now()
            expires = (now + timedelta(seconds=lease_seconds)).isoformat(timespec="milliseconds").replace("+00:00", "Z")
            record = {
                "schema": "aic.scope-lock", "schema_version": SCHEMA_VERSION, "id": lock_id,
                "status": "ACTIVE", "owner_session_id": session_id, "scopes": normalized,
                "acquired_at": acquired, "last_renewed_at": acquired, "lease_expires_at": expires,
                "lease_seconds": lease_seconds, "pid": os.getpid(), "extensions": {},
            }
            atomic_write(self.locks / f"{lock_id}.json", pretty_bytes(record))
        self._refresh_current(session_id)
        return {"lock": record}

    def assert_write_allowed(self, session_id: str, scopes: list[str]) -> dict[str, Any]:
        """Reject a write that overlaps another active session's declared scope."""
        self._session(session_id)
        normalized = [self.normalize_scope(item) for item in scopes]
        now = datetime.now(timezone.utc)
        checked = []
        for record in self._lock_records():
            if record.get("status") != "ACTIVE":
                continue
            conflicts = [(wanted, held) for wanted in normalized for held in record.get("scopes", []) if self.overlaps(wanted, held)]
            if not conflicts:
                continue
            checked.append(record["id"])
            if parse_time(record["lease_expires_at"]) <= now:
                raise StateError("LOCK_EXPIRED_NEEDS_REVIEW", "写入范围存在过期锁，必须先核对恢复", conflicting_lock=record["id"], overlaps=conflicts)
            if record.get("owner_session_id") != session_id:
                raise StateError("LOCK_SCOPE_CONFLICT", "写入范围由其他会话锁定", conflicting_lock=record["id"], owner_session_id=record.get("owner_session_id"), overlaps=conflicts)
        return {"allowed": True, "matching_owned_locks": checked}

    def guard_write(self, session_id: str, scopes: list[str], expected_state_revision: int) -> dict[str, Any]:
        """Mandatory public-write guard: health, live session, revision and owned locks."""
        self._session(session_id)
        verification = self.store.verify()
        if not verification.get("healthy"):
            raise StateError(
                "STATE_READ_ONLY_REQUIRED",
                "权威历史或派生状态校验失败，禁止继续写入",
                errors=verification.get("errors", []),
            )
        actual_revision = verification.get("state_revision")
        if actual_revision != expected_state_revision:
            raise StateError(
                "STATE_REVISION_CONFLICT",
                "状态修订已变化，必须重新读取后再修改",
                expected=expected_state_revision,
                actual=actual_revision,
            )
        normalized = [self.normalize_scope(item) for item in scopes]
        if not normalized:
            raise StateError("INPUT_LOCK_SCOPE_REQUIRED", "写入门禁至少需要一个范围")
        now = datetime.now(timezone.utc)
        owned: list[str] = []
        covered: set[str] = set()
        for record in self._lock_records():
            if record.get("status") != "ACTIVE":
                continue
            held_scopes = record.get("scopes", [])
            overlaps = [(wanted, held) for wanted in normalized for held in held_scopes if self.overlaps(wanted, held)]
            if not overlaps:
                continue
            if parse_time(record["lease_expires_at"]) <= now:
                raise StateError("LOCK_EXPIRED_NEEDS_REVIEW", "写入范围存在过期锁，必须先核对恢复", conflicting_lock=record["id"], overlaps=overlaps)
            if record.get("owner_session_id") != session_id:
                raise StateError("LOCK_SCOPE_CONFLICT", "写入范围由其他会话锁定", conflicting_lock=record["id"], owner_session_id=record.get("owner_session_id"), overlaps=overlaps)
            owned.append(record["id"])
            for wanted in normalized:
                if any(self.covers(held, wanted) for held in held_scopes):
                    covered.add(wanted)
        missing = [item for item in normalized if item not in covered]
        if missing:
            raise StateError("LOCK_REQUIRED", "写入前必须持有覆盖全部目标的有效范围锁", missing_scopes=missing)
        return {"allowed": True, "owned_lock_ids": sorted(set(owned)), "scopes": normalized}

    @staticmethod
    def _pid_alive(pid: object) -> bool | None:
        try:
            numeric = int(pid)
            if numeric <= 0:
                return False
            os.kill(numeric, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return None
        except OSError:
            return False
        except (TypeError, ValueError):
            return False

    def diagnose_internal_mutexes(self) -> list[dict[str, Any]]:
        findings: list[dict[str, Any]] = []
        now = datetime.now(timezone.utc)
        for kind, path in (("state-write", self.store.lock_path), ("lock-registry", self.registry_mutex)):
            if not path.exists():
                continue
            try:
                record = read_json(path)
                acquired = parse_time(record.get("acquired_at") or record.get("created_at"))
                age = max(0.0, (now - acquired).total_seconds())
                alive = self._pid_alive(record.get("pid"))
                orphaned = alive is False and age >= INTERNAL_MUTEX_STALE_SECONDS
                findings.append({
                    "category": "internal-mutex",
                    "severity": "ERROR" if orphaned else "WARNING",
                    "code": "INTERNAL_MUTEX_ORPHANED" if orphaned else "INTERNAL_MUTEX_ACTIVE_OR_UNCERTAIN",
                    "mutex_kind": kind,
                    "path": str(path),
                    "pid": record.get("pid"),
                    "pid_alive": alive,
                    "age_seconds": round(age, 3),
                })
            except StateError as exc:
                findings.append({
                    "category": "internal-mutex", "severity": "ERROR",
                    "code": "INTERNAL_MUTEX_INVALID", "mutex_kind": kind,
                    "path": str(path), "error": exc.code,
                })
        return findings

    def renew(self, lock_id: str, session_id: str, lease_seconds: int) -> dict[str, Any]:
        self._session(session_id)
        if not MIN_LEASE_SECONDS <= lease_seconds <= MAX_LEASE_SECONDS:
            raise StateError("INPUT_LEASE_RANGE", "租约时长超出允许范围", minimum=MIN_LEASE_SECONDS, maximum=MAX_LEASE_SECONDS)
        with self._registry_lock():
            record = self._owned_lock(lock_id, session_id)
            if parse_time(record["lease_expires_at"]) <= datetime.now(timezone.utc):
                raise StateError("LOCK_EXPIRED_NEEDS_REVIEW", "租约已经过期，不能直接续租", lock_id=lock_id)
            now = datetime.now(timezone.utc)
            record["last_renewed_at"] = now.isoformat(timespec="milliseconds").replace("+00:00", "Z")
            record["lease_expires_at"] = (now + timedelta(seconds=lease_seconds)).isoformat(timespec="milliseconds").replace("+00:00", "Z")
            record["lease_seconds"] = lease_seconds
            atomic_write(self.locks / f"{lock_id}.json", pretty_bytes(record))
        return {"lock": record}

    def release(self, lock_id: str, session_id: str) -> dict[str, Any]:
        with self._registry_lock():
            record = self._owned_lock(lock_id, session_id)
            record["status"] = "RELEASED"
            record["released_at"] = utc_now()
            atomic_write(self.locks / f"{lock_id}.json", pretty_bytes(record))
        self._refresh_current(session_id)
        return {"lock": record}

    def recover_expired(self, lock_id: str, reviewer_session_id: str, acknowledged: bool) -> dict[str, Any]:
        self._session(reviewer_session_id)
        if not acknowledged:
            raise StateError("USER_DECISION_REQUIRED", "过期锁恢复需要明确核对并确认")
        with self._registry_lock():
            path = self.locks / f"{lock_id}.json"
            if not path.is_file():
                raise StateError("LOCK_NOT_FOUND", "锁不存在", lock_id=lock_id)
            record = read_json(path)
            if record.get("status") != "ACTIVE" or parse_time(record["lease_expires_at"]) > datetime.now(timezone.utc):
                raise StateError("LOCK_NOT_RECOVERABLE", "锁未过期或不是活动锁", lock_id=lock_id)
            owner = self._session(record["owner_session_id"], require_active=False)
            if owner.get("status") == "ACTIVE" and parse_time(owner.get("lease_expires_at", owner.get("updated_at"))) > datetime.now(timezone.utc):
                raise StateError("LOCK_OWNER_STILL_ACTIVE", "原会话仍处于有效活动期", owner_session_id=owner["id"])
            pending = []
            for tx_path in (self.store.run / "transactions").glob("TXN-*.json"):
                tx = read_json(tx_path)
                if tx.get("session_id") == owner["id"] and tx.get("phase") not in {"COMMITTED", "ABORTED"}:
                    pending.append(str(tx_path))
            if pending:
                raise StateError("LOCK_OWNER_TRANSACTION_PENDING", "原会话存在未完成事务，不能接管", transactions=pending)
            record["status"] = "RECOVERED"
            record["recovered_at"] = utc_now()
            record["recovered_by"] = reviewer_session_id
            atomic_write(path, pretty_bytes(record))
        self._refresh_current(reviewer_session_id)
        return {"lock": record, "message": "旧锁已标记恢复；需要重新 acquire 获取新锁"}

    def heartbeat(self, session_id: str, ttl_seconds: int) -> dict[str, Any]:
        if not MIN_LEASE_SECONDS <= ttl_seconds <= MAX_LEASE_SECONDS:
            raise StateError("INPUT_SESSION_TTL_RANGE", "会话 TTL 超出允许范围", minimum=MIN_LEASE_SECONDS, maximum=MAX_LEASE_SECONDS)
        session = self._session(session_id)
        now = datetime.now(timezone.utc)
        session["last_heartbeat_at"] = now.isoformat(timespec="milliseconds").replace("+00:00", "Z")
        session["lease_expires_at"] = (now + timedelta(seconds=ttl_seconds)).isoformat(timespec="milliseconds").replace("+00:00", "Z")
        session["updated_at"] = session["last_heartbeat_at"]
        atomic_write(self.sessions / f"{session_id}.json", pretty_bytes(session))
        return {"session": session}

    def end_session(self, session_id: str) -> dict[str, Any]:
        session = self._session(session_id)
        active = [item["id"] for item in self._lock_records() if item.get("status") == "ACTIVE" and item.get("owner_session_id") == session_id]
        if active:
            raise StateError("SESSION_ACTIVE_LOCKS", "会话仍持有活动锁，必须先释放", locks=active)
        session["status"] = "ENDED"
        session["ended_at"] = utc_now()
        session["updated_at"] = session["ended_at"]
        atomic_write(self.sessions / f"{session_id}.json", pretty_bytes(session))
        self._refresh_current(session_id)
        return {"session": session}

    def _owned_lock(self, lock_id: str, session_id: str) -> dict[str, Any]:
        path = self.locks / f"{lock_id}.json"
        if not path.is_file():
            raise StateError("LOCK_NOT_FOUND", "锁不存在", lock_id=lock_id)
        record = read_json(path)
        if record.get("status") != "ACTIVE":
            raise StateError("LOCK_NOT_ACTIVE", "锁不是活动状态", lock_id=lock_id, status=record.get("status"))
        if record.get("owner_session_id") != session_id:
            raise StateError("LOCK_NOT_OWNER", "只有锁所有者可以操作", lock_id=lock_id, owner=record.get("owner_session_id"))
        return record

    def _refresh_current(self, session_id: str) -> None:
        try:
            self.store.refresh_runtime_indexes(session_id)
        except StateError:
            # Lock/session records remain authoritative in run/. Doctor reports
            # a stale derived CURRENT view and it can be rebuilt safely.
            pass
