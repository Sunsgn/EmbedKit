#!/usr/bin/env python3
"""Budgeted, platform-neutral project and client adapter discovery."""

from __future__ import annotations

import json
import os
from pathlib import Path
import time
from typing import Any

from state_core import SCHEMA_VERSION, StateError, StateStore, atomic_write, pretty_bytes, utc_now


PROFILES = {
    "LIGHT": {"max_files": 2000, "max_bytes": 64 * 1024 * 1024, "timeout_seconds": 10, "max_depth": 8, "required_evidence": 1, "summary_required": False},
    "STANDARD": {"max_files": 20000, "max_bytes": 512 * 1024 * 1024, "timeout_seconds": 60, "max_depth": 16, "required_evidence": 1, "summary_required": True},
    "FULL": {"max_files": 100000, "max_bytes": 2 * 1024 * 1024 * 1024, "timeout_seconds": 300, "max_depth": 32, "required_evidence": 2, "summary_required": True},
}
EXCLUDED_DIRECTORIES = {".git", ".ai", "node_modules", ".venv", "venv", "__pycache__"}
ARTIFACT_DIRECTORIES = {"dist", "build", "out"}
ARTIFACT_SUFFIXES = {".elf", ".axf", ".out", ".map", ".hex", ".bin", ".uf2", ".log", ".lst", ".sym"}
PROJECT_MARKERS = {"CMakeLists.txt", "Makefile", "package.json", "pyproject.toml", "Cargo.toml", "west.yml", "Kconfig"}


def load_adapters() -> dict[str, Any]:
    path = Path(__file__).resolve().parent / "adapters" / "registry.json"
    try:
        registry = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise StateError("ADAPTER_REGISTRY_INVALID", "适配器注册表无法读取", path=str(path), error=str(exc)) from exc
    if registry.get("schema") != "aic.adapter-registry" or registry.get("schema_version") != SCHEMA_VERSION:
        raise StateError("ADAPTER_REGISTRY_UNSUPPORTED", "适配器注册表版本不兼容")
    return registry


def adapter_list() -> dict[str, Any]:
    registry = load_adapters()
    return {"registry_version": registry["registry_version"], "project_adapters": registry["project_adapters"], "client_adapters": registry["client_adapters"]}


def workflow_profile(level: str) -> dict[str, Any]:
    normalized = level.upper()
    if normalized not in PROFILES:
        raise StateError("INPUT_WORKFLOW_LEVEL_INVALID", "流程等级必须是 LIGHT、STANDARD 或 FULL", level=level)
    return {"level": normalized, **PROFILES[normalized], "safety_invariants": ["package-integrity", "path-boundary", "state-revision", "evidence-for-completion"]}


def inspect_project(
    store: StateStore,
    profile: str,
    max_files: int | None = None,
    max_bytes: int | None = None,
    timeout_seconds: int | None = None,
    cancel_file: str | None = None,
) -> dict[str, Any]:
    settings = workflow_profile(profile)
    limits = {
        "max_files": min(max_files or settings["max_files"], settings["max_files"]),
        "max_bytes": min(max_bytes or settings["max_bytes"], settings["max_bytes"]),
        "timeout_seconds": min(timeout_seconds or settings["timeout_seconds"], settings["timeout_seconds"]),
        "max_depth": settings["max_depth"],
    }
    if limits["max_files"] < 1 or limits["max_bytes"] < 1 or limits["timeout_seconds"] < 1:
        raise StateError("INPUT_SCAN_BUDGET_INVALID", "扫描预算必须大于零")
    cancel_path = None
    if cancel_file:
        cancel_path = Path(cancel_file)
        if not cancel_path.is_absolute():
            cancel_path = store.root / cancel_path
        cancel_path = cancel_path.resolve(strict=False)
        if not cancel_path.is_relative_to(store.root):
            raise StateError("PATH_CANCEL_FILE_INVALID", "取消文件必须位于项目内", path=str(cancel_path))
    started = time.monotonic()
    stack: list[tuple[Path, int, bool, int]] = [(store.root, 0, False, 0)]
    files = 0
    bytes_seen = 0
    names: dict[str, int] = {}
    suffixes: dict[str, int] = {}
    relative_paths: list[str] = []
    subprojects: set[str] = set()
    permission_errors: list[str] = []
    symlinks: list[str] = []
    artifact_files = 0
    artifact_bytes = 0
    artifact_paths: list[str] = []
    artifact_file_limit = max(100, min(5000, limits["max_files"] // 4))
    artifact_byte_limit = min(512 * 1024 * 1024, limits["max_bytes"] // 2)
    stop_reason = None
    while stack:
        if cancel_path and cancel_path.exists():
            stop_reason = "CANCELLED"
            break
        if time.monotonic() - started >= limits["timeout_seconds"]:
            stop_reason = "TIME_BUDGET"
            break
        directory, depth, artifact_mode, artifact_depth = stack.pop()
        try:
            entries = list(os.scandir(directory))
        except (OSError, PermissionError):
            permission_errors.append(directory.relative_to(store.root).as_posix() or ".")
            continue
        for entry in entries:
            path = Path(entry.path)
            relative = path.relative_to(store.root).as_posix()
            try:
                if entry.is_symlink():
                    symlinks.append(relative)
                    continue
                if entry.is_dir(follow_symlinks=False):
                    if entry.name in EXCLUDED_DIRECTORIES or depth >= limits["max_depth"]:
                        continue
                    next_artifact = artifact_mode or entry.name.casefold() in ARTIFACT_DIRECTORIES
                    next_artifact_depth = artifact_depth + 1 if next_artifact else 0
                    if next_artifact and next_artifact_depth > 3:
                        continue
                    stack.append((path, depth + 1, next_artifact, next_artifact_depth))
                    continue
                if not entry.is_file(follow_symlinks=False):
                    continue
                size = entry.stat(follow_symlinks=False).st_size
            except OSError:
                permission_errors.append(relative)
                continue
            suffix = path.suffix.lower()
            if artifact_mode and suffix not in ARTIFACT_SUFFIXES and entry.name not in PROJECT_MARKERS:
                continue
            files += 1
            bytes_seen += size
            names[entry.name] = names.get(entry.name, 0) + 1
            if suffix:
                suffixes[suffix] = suffixes.get(suffix, 0) + 1
            if artifact_mode and suffix in ARTIFACT_SUFFIXES:
                artifact_files += 1
                artifact_bytes += size
                if len(artifact_paths) < 500:
                    artifact_paths.append(relative)
            if len(relative_paths) < 5000:
                relative_paths.append(relative)
            if entry.name in PROJECT_MARKERS:
                parent = path.parent.relative_to(store.root).as_posix() or "."
                subprojects.add(parent)
            if files >= limits["max_files"]:
                stop_reason = "FILE_BUDGET"
                break
            if bytes_seen >= limits["max_bytes"]:
                stop_reason = "BYTE_BUDGET"
                break
            if artifact_files >= artifact_file_limit:
                stop_reason = "ARTIFACT_FILE_BUDGET"
                break
            if artifact_bytes >= artifact_byte_limit:
                stop_reason = "ARTIFACT_BYTE_BUDGET"
                break
        if stop_reason:
            break
    registry = load_adapters()
    matches = []
    for adapter in registry["project_adapters"]:
        evidence = []
        score = 0
        for name in adapter.get("file_names", []):
            if names.get(name):
                score += adapter.get("name_weight", 3)
                evidence.append({"kind": "file-name", "value": name, "count": names[name]})
        for suffix in adapter.get("suffixes", []):
            if suffixes.get(suffix):
                score += min(suffixes[suffix], adapter.get("suffix_cap", 5))
                evidence.append({"kind": "suffix", "value": suffix, "count": suffixes[suffix]})
        if score > 0:
            matches.append({"adapter_id": adapter["id"], "category": adapter["category"], "score": score, "confidence": min(0.99, round(score / max(adapter.get("confidence_divisor", 12), 1), 2)), "evidence": evidence, "limitations": adapter.get("limitations", [])})
    matches.sort(key=lambda item: (-item["score"], item["adapter_id"]))
    primary = matches[0] if matches else {"adapter_id": "project.unknown", "category": "unknown", "score": 0, "confidence": 0.0, "evidence": [], "limitations": ["没有足够标志；使用通用文件和产物分析"]}
    result = {
        "schema": "aic.project-inspection", "schema_version": SCHEMA_VERSION,
        "root": str(store.root), "profile": settings["level"], "limits": limits,
        "files_seen": files, "bytes_seen": bytes_seen, "elapsed_seconds": round(time.monotonic() - started, 3),
        "complete": stop_reason is None, "stop_reason": stop_reason,
        "primary": primary, "matches": matches, "subprojects": sorted(subprojects)[:100],
        "subprojects_truncated": len(subprojects) > 100, "permission_errors": permission_errors[:100],
        "permission_errors_truncated": len(permission_errors) > 100, "symlinks_skipped": symlinks[:100],
        "symlinks_truncated": len(symlinks) > 100, "unknown_items": [] if matches else ["project-framework"],
        "build_artifacts": {
            "files_seen": artifact_files, "bytes_seen": artifact_bytes,
            "sampled_paths": artifact_paths, "sampled_paths_truncated": artifact_files > len(artifact_paths),
            "file_limit": artifact_file_limit, "byte_limit": artifact_byte_limit,
        },
        "inspected_at": utc_now(),
    }
    cache = {
        "schema": "aic.project-scan-cache", "schema_version": SCHEMA_VERSION,
        "root": str(store.root), "profile": settings["level"], "file_count": files,
        "sampled_paths": relative_paths, "result": result, "updated_at": utc_now(),
    }
    atomic_write(store.run / "cache" / "project-scan.json", pretty_bytes(cache))
    return result
