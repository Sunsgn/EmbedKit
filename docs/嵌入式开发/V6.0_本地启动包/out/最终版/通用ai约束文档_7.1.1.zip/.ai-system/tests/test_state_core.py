from __future__ import annotations

import json
from pathlib import Path
import sys
import tempfile
import unittest


SYSTEM_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SYSTEM_ROOT))

from state_core import StateError, StateStore  # noqa: E402


class StateCoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="aic-state-test-")
        self.root = Path(self.temporary.name)
        self.store = StateStore(self.root)
        initialized = self.store.initialize("state-test")
        self.assertTrue(initialized["created"])

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def session(self, client: str = "test") -> str:
        return self.store.start_session(client)["session"]["id"]

    def test_two_sessions_restore_same_task_and_next_action(self) -> None:
        writer = self.session("writer")
        task_result = self.store.create_task("实现状态内核", "跨会话恢复", 1, writer, ["两个会话读到相同下一步"])
        task_id = task_result["task"]["id"]
        next_result = self.store.create_next(task_id, "运行阶段门禁", 1, 2, writer, ["专项测试通过"], False)
        expected_next = next_result["next_action"]["id"]

        first = self.store.start_session("client-a")["context"]
        second = self.store.start_session("client-b")["context"]
        self.assertEqual(first["head"]["state_revision"], second["head"]["state_revision"])
        self.assertEqual(first["active_tasks"][0]["id"], task_id)
        self.assertEqual(second["active_tasks"][0]["id"], task_id)
        self.assertEqual(first["recommended_next_action"]["id"], expected_next)
        self.assertEqual(second["recommended_next_action"]["id"], expected_next)
        self.assertEqual(len(second["current"]["active_sessions"]), 3)
        self.assertTrue(self.store.verify()["healthy"])

    def test_stale_state_revision_is_rejected(self) -> None:
        session_id = self.session()
        self.store.create_task("first", "advance revision", 1, session_id, [])
        with self.assertRaises(StateError) as raised:
            self.store.create_task("stale", "must fail", 1, session_id, [])
        self.assertEqual(raised.exception.code, "STATE_REVISION_CONFLICT")

    def test_stale_entity_revision_is_rejected(self) -> None:
        session_id = self.session()
        created = self.store.create_task("task", "entity revision", 1, session_id, [])
        task_id = created["task"]["id"]
        self.store.update_task(task_id, "EXECUTING", 1, 2, session_id, [], [], [])
        with self.assertRaises(StateError) as raised:
            self.store.update_task(task_id, "VERIFYING", 1, 3, session_id, [], [], [])
        self.assertEqual(raised.exception.code, "ENTITY_REVISION_CONFLICT")

    def test_manual_view_edit_blocks_regeneration(self) -> None:
        self.store.render_view()
        view = self.root / ".ai" / "views" / "CURRENT.md"
        view.write_text(view.read_text(encoding="utf-8") + "人工内容\n", encoding="utf-8")
        self.assertFalse(self.store.check_views()["valid"])
        with self.assertRaises(StateError) as raised:
            self.store.render_view()
        self.assertEqual(raised.exception.code, "VIEW_MANUAL_EDIT_CONFLICT")

    def test_legacy_import_is_reference_only_and_hashed(self) -> None:
        legacy = self.root / ".ai" / "PROJECT_PROFILE.md"
        legacy.write_text("# legacy\n", encoding="utf-8")
        session_id = self.session()
        result = self.store.import_legacy(1, session_id)
        self.assertEqual(result["imported"], 1)
        report = json.loads(Path(result["report"]).read_text(encoding="utf-8"))
        self.assertEqual(report["authority"], "reference-only")
        self.assertTrue(report["source_files"][0]["sha256"].startswith("sha256:"))
        self.assertTrue(self.store.verify()["healthy"])

    def test_derived_state_can_be_rebuilt(self) -> None:
        current_path = self.root / ".ai" / "state" / "CURRENT.json"
        current = json.loads(current_path.read_text(encoding="utf-8"))
        current["state_revision"] = 0
        current_path.write_text(json.dumps(current), encoding="utf-8")
        self.assertFalse(self.store.verify()["healthy"])
        rebuilt = self.store.rebuild()
        self.assertTrue(rebuilt["rebuilt"])
        self.assertTrue(self.store.verify()["healthy"])

    def test_event_tamper_is_detected_and_not_auto_rebuilt(self) -> None:
        event_file = next((self.root / ".ai" / "state" / "events").glob("*.jsonl"))
        event_file.write_text(event_file.read_text(encoding="utf-8").replace("project.created", "project.tampered"), encoding="utf-8")
        verification = self.store.verify()
        self.assertFalse(verification["healthy"])
        self.assertIn("EVENT_HASH_INVALID", {item["code"] for item in verification["errors"]})
        with self.assertRaises(StateError) as raised:
            self.store.rebuild()
        self.assertEqual(raised.exception.code, "STATE_REBUILD_UNSAFE")

    def test_schema_documents_are_valid_json(self) -> None:
        schemas = SYSTEM_ROOT / "schemas"
        for name in ("state-entities.schema.json", "state-records.schema.json"):
            value = json.loads((schemas / name).read_text(encoding="utf-8"))
            self.assertEqual(value["$schema"], "https://json-schema.org/draft/2020-12/schema")


if __name__ == "__main__":
    unittest.main()
