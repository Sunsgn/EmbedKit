from __future__ import annotations

from pathlib import Path
import sys
import tempfile
import unittest


SYSTEM_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SYSTEM_ROOT))

from lifecycle import (  # noqa: E402
    add_evidence,
    generate_summary,
    invalidate_evidence,
    list_rules,
    transition_task,
    update_next,
    verify_summary,
)
from state_core import StateError, StateStore  # noqa: E402


class LifecycleTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="aic-lifecycle-test-")
        self.root = Path(self.temporary.name)
        self.store = StateStore(self.root)
        self.store.initialize("lifecycle-test")
        self.session = self.store.start_session("test")["session"]["id"]

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def create_task(self, acceptance: list[str] | None = None) -> dict:
        return self.store.create_task("真实任务", "完成闭环", 1, self.session, acceptance or ["测试通过"])["task"]

    def transition(self, task: dict, to_status: str, state_revision: int, **kwargs: object) -> dict:
        return transition_task(
            self.store, task["id"], to_status, task["revision"], state_revision,
            self.session, kwargs.get("completed", []), kwargs.get("remaining", []),
            kwargs.get("blockers", []), kwargs.get("resolved_blockers", []),
            kwargs.get("failed_attempts", []), kwargs.get("unknowns", []),
            kwargs.get("resume_condition"), kwargs.get("resolution_condition"),
        )["task"]

    def test_full_task_evidence_summary_completion_and_stale_propagation(self) -> None:
        task = self.create_task()
        task = self.transition(task, "READY", 2)
        task = self.transition(task, "EXECUTING", 3, remaining=["实现并验证"])
        action = self.store.create_next(task["id"], "执行验证", 1, 4, self.session, ["证据通过"], False)["next_action"]
        action = update_next(self.store, action["id"], "DONE", 1, 6, self.session)["next_action"]
        self.assertEqual(action["status"], "DONE")

        artifact = self.root / "test-report.txt"
        artifact.write_text("PASS\n", encoding="utf-8")
        acceptance_id = task["acceptance_criteria"][0]["id"]
        evidence_result = add_evidence(
            self.store, task["id"], "test-execution", "PASS", str(artifact),
            7, self.session, [], [acceptance_id], "MANUAL",
            result_basis="测试报告内容由本用例核验",
        )
        evidence = evidence_result["evidence"]
        task = self.store._load_entity("task", task["id"])
        assert task is not None
        task = self.transition(task, "VERIFYING", 9, completed=["实现并验证"])

        summary_result = generate_summary(self.store, task["id"], "STAGE", "验证完成", 10, self.session)
        self.assertTrue(summary_result["created"])
        summary = summary_result["summary"]
        duplicate = generate_summary(self.store, task["id"], "STAGE", "重复触发", 10, self.session)
        self.assertFalse(duplicate["created"])
        summary = verify_summary(self.store, summary["id"], 1, 12, self.session)["summary"]
        self.assertEqual(summary["status"], "VERIFIED")

        task = self.store._load_entity("task", task["id"])
        assert task is not None
        task = self.transition(task, "COMPLETED", 13)
        self.assertEqual(task["status"], "COMPLETED")

        invalidated = invalidate_evidence(self.store, evidence["id"], "输入已变化", 14, 1, self.session)
        self.assertEqual(invalidated["affected_tasks"], [task["id"]])
        self.assertEqual(invalidated["affected_summaries"], [summary["id"]])
        stale_task = self.store._load_entity("task", task["id"])
        stale_summary = self.store._load_entity("summary", summary["id"])
        self.assertEqual(stale_task["status"], "STALE")
        self.assertEqual(stale_summary["status"], "STALE")
        self.assertTrue(self.store.verify()["healthy"])

    def test_completion_gate_reports_missing_evidence_and_summary(self) -> None:
        task = self.create_task()
        task = self.transition(task, "READY", 2)
        task = self.transition(task, "EXECUTING", 3)
        task = self.transition(task, "VERIFYING", 4)
        with self.assertRaises(StateError) as raised:
            self.transition(task, "COMPLETED", 5)
        self.assertEqual(raised.exception.code, "TASK_COMPLETION_GATE_FAILED")
        codes = {item["code"] for item in raised.exception.details["failures"]}
        self.assertIn("VALID_EVIDENCE_MISSING", codes)
        self.assertIn("VERIFIED_SUMMARY_MISSING", codes)

    def test_invalid_transition_and_failed_attempt_preservation(self) -> None:
        task = self.create_task()
        with self.assertRaises(StateError) as raised:
            self.transition(task, "COMPLETED", 2)
        self.assertEqual(raised.exception.code, "TASK_TRANSITION_INVALID")
        task = self.transition(task, "READY", 2)
        task = self.transition(task, "EXECUTING", 3)
        task = self.transition(task, "FAILED", 4, failed_attempts=["方案 A 超时"], unknowns=["设备固件版本未知"])
        self.assertEqual(task["failed_attempts"], ["方案 A 超时"])
        self.assertEqual(task["unknowns"], ["设备固件版本未知"])

    def test_pause_and_block_require_recovery_conditions(self) -> None:
        task = self.create_task()
        task = self.transition(task, "READY", 2)
        with self.assertRaises(StateError) as paused:
            self.transition(task, "PAUSED", 3)
        self.assertEqual(paused.exception.code, "TASK_RESUME_CONDITION_REQUIRED")
        with self.assertRaises(StateError) as blocked:
            self.transition(task, "BLOCKED", 3)
        self.assertEqual(blocked.exception.code, "TASK_RESOLUTION_CONDITION_REQUIRED")

    def test_rule_registry_has_stable_ids(self) -> None:
        rules = list_rules()["rules"]
        self.assertGreaterEqual(len(rules), 4)
        self.assertEqual(len({item["id"] for item in rules}), len(rules))
        self.assertTrue(all(item["id"].startswith("RULE-") for item in rules))


if __name__ == "__main__":
    unittest.main()
