from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sys
import tempfile
import unittest


SYSTEM_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SYSTEM_ROOT))

from concurrency import ConcurrencyManager  # noqa: E402
from lifecycle import _completion_gate, add_evidence, generate_summary, verify_summary  # noqa: E402
from doctor import apply_repair_plan, create_repair_plan  # noqa: E402
from migrations import migrate_to_v11, migration_status  # noqa: E402
from state_core import StateError, StateStore, atomic_write, pretty_bytes  # noqa: E402


class HardeningV71Tests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="aic-hardening-v71-")
        self.root = Path(self.temporary.name)
        self.store = StateStore(self.root)
        self.store.initialize("hardening-v71")
        self.session = self.store.start_session("test")['session']['id']
        self.manager = ConcurrencyManager(self.store)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def test_write_requires_owned_covering_lock(self) -> None:
        with self.assertRaises(StateError) as missing:
            self.manager.guard_write(self.session, ["project:state"], 1)
        self.assertEqual(missing.exception.code, "LOCK_REQUIRED")

        lock = self.manager.acquire(self.session, ["project:state"], 300)["lock"]
        guarded = self.manager.guard_write(self.session, ["project:state"], 1)
        self.assertEqual(guarded["owned_lock_ids"], [lock["id"]])

    def test_expired_or_fake_session_cannot_write(self) -> None:
        self.manager.acquire(self.session, ["project:state"], 300)
        session_path = self.store.run / "sessions" / f"{self.session}.json"
        session = json.loads(session_path.read_text(encoding="utf-8"))
        session["lease_expires_at"] = (
            datetime.now(timezone.utc) - timedelta(minutes=1)
        ).isoformat(timespec="milliseconds").replace("+00:00", "Z")
        atomic_write(session_path, pretty_bytes(session))
        with self.assertRaises(StateError) as expired:
            self.manager.guard_write(self.session, ["project:state"], 1)
        self.assertEqual(expired.exception.code, "SESSION_LEASE_EXPIRED")
        with self.assertRaises(StateError) as fake:
            self.manager.guard_write("SES-FAKE", ["project:state"], 1)
        self.assertEqual(fake.exception.code, "SESSION_NOT_FOUND")

    def test_authoritative_damage_forces_guard_read_only(self) -> None:
        self.manager.acquire(self.session, ["project:state"], 300)
        event_path = next(self.store.events.glob("*.jsonl"))
        event_path.write_text(
            event_path.read_text(encoding="utf-8").replace("project.created", "project.damaged"),
            encoding="utf-8",
        )
        with self.assertRaises(StateError) as damaged:
            self.manager.guard_write(self.session, ["project:state"], 1)
        self.assertEqual(damaged.exception.code, "STATE_READ_ONLY_REQUIRED")

    def test_crashed_internal_mutex_is_diagnosable(self) -> None:
        lock_path = self.store.lock_path
        atomic_write(lock_path, pretty_bytes({
            "schema": "aic.local-write-lock",
            "schema_version": "1.0.0",
            "owner_session_id": self.session,
            "pid": 99999999,
            "token": "orphan",
            "acquired_at": "2000-01-01T00:00:00.000Z",
        }))
        diagnosis = self.manager.diagnose_internal_mutexes()
        self.assertIn("INTERNAL_MUTEX_ORPHANED", {item["code"] for item in diagnosis})
        plan = create_repair_plan(self.store)
        applied = apply_repair_plan(self.store, plan["path"], self.session, True)
        self.assertFalse(lock_path.exists())
        recovered = [item for item in applied["results"] if item["type"] == "RECOVER_ORPHANED_INTERNAL_MUTEX"]
        self.assertEqual(len(recovered), 1)
        self.assertTrue(Path(recovered[0]["backup"]).is_file())

    def test_completed_history_is_queryable_and_resumable(self) -> None:
        task = self.store.create_task("history target", "remember completed reasoning", 1, self.session, ["recorded"])["task"]
        closed = self.store.update_task(task["id"], "CANCELLED", task["revision"], 2, self.session, ["recorded"], [], [])
        self.assertEqual(closed["task"]["status"], "CANCELLED")
        listed = self.store.list_entities("task", statuses=["CANCELLED"])
        self.assertEqual([item["id"] for item in listed["items"]], [task["id"]])
        searched = self.store.list_entities("task", query="reasoning")
        self.assertEqual(searched["items"][0]["id"], task["id"])
        snapshot = self.store.resume_snapshot()
        self.assertEqual(snapshot["recent_closed_tasks"][0]["id"], task["id"])
        self.assertEqual(snapshot["recommendation"]["kind"], "NO_OPEN_WORK")
        timeline = self.store.history_timeline(limit=10)
        self.assertGreaterEqual(len(timeline["items"]), 3)

    def test_each_acceptance_requires_its_own_current_evidence(self) -> None:
        task = self.store.create_task("criteria", "prove every criterion", 1, self.session, ["first", "second"])["task"]
        artifact = self.root / "result.txt"
        artifact.write_text("PASS\n", encoding="utf-8")
        first = task["acceptance_criteria"][0]["id"]
        add_evidence(
            self.store, task["id"], "TEST", "PASS", str(artifact), 2, self.session,
            [], [first], "MANUAL", result_basis="reviewed test output",
        )
        updated = self.store._load_entity("task", task["id"])
        with self.assertRaises(StateError) as incomplete:
            _completion_gate(self.store, updated)
        failures = incomplete.exception.details["failures"]
        self.assertIn(task["acceptance_criteria"][1]["id"], {item.get("acceptance_id") for item in failures})

    def test_summary_verification_rehashes_live_evidence(self) -> None:
        task = self.store.create_task("summary", "detect drift before verify", 1, self.session, ["artifact stable"])["task"]
        artifact = self.root / "summary-result.txt"
        artifact.write_text("PASS\n", encoding="utf-8")
        evidence = add_evidence(
            self.store, task["id"], "TEST", "PASS", str(artifact), 2, self.session,
            [], [task["acceptance_criteria"][0]["id"]], "MANUAL", result_basis="reviewed",
        )["evidence"]
        summary = generate_summary(self.store, task["id"], "STAGE", "test", 4, self.session)["summary"]
        artifact.write_text("CHANGED\n", encoding="utf-8")
        with self.assertRaises(StateError) as stale:
            verify_summary(self.store, summary["id"], 1, 6, self.session)
        self.assertEqual(stale.exception.code, "SUMMARY_EVIDENCE_INVALID")
        self.assertEqual(evidence["status"], "VALID")

    def test_doctor_propagates_evidence_drift_to_acceptance_and_summary(self) -> None:
        task = self.store.create_task("drift", "propagate stale", 1, self.session, ["stable"])["task"]
        artifact = self.root / "drift-result.txt"
        artifact.write_text("PASS\n", encoding="utf-8")
        evidence = add_evidence(
            self.store, task["id"], "TEST", "PASS", str(artifact), 2, self.session,
            [], [task["acceptance_criteria"][0]["id"]], "MANUAL", result_basis="reviewed",
        )["evidence"]
        summary = generate_summary(self.store, task["id"], "STAGE", "before drift", 4, self.session)["summary"]
        verify_summary(self.store, summary["id"], 1, 6, self.session)
        artifact.write_text("CHANGED\n", encoding="utf-8")
        plan = create_repair_plan(self.store)
        self.assertIn("INVALIDATE_DRIFTED_EVIDENCE", {item["type"] for item in plan["plan"]["actions"]})
        apply_repair_plan(self.store, plan["path"], self.session, True)
        changed_evidence = self.store._load_entity("evidence", evidence["id"])
        changed_task = self.store._load_entity("task", task["id"])
        changed_summary = self.store._load_entity("summary", summary["id"])
        self.assertEqual(changed_evidence["status"], "CORRUPT")
        self.assertEqual(changed_task["acceptance_criteria"][0]["status"], "STALE")
        self.assertEqual(changed_summary["status"], "STALE")

    def test_legacy_acceptance_state_migrates_idempotently(self) -> None:
        task = self.store.create_task("legacy", "migrate strings", 1, self.session, ["old criterion"])["task"]
        project_id = self.store.context()["current"]["project_id"]
        project = self.store.show_entity("project", project_id)
        legacy_task = dict(task)
        legacy_task["revision"] += 1
        legacy_task["acceptance_criteria"] = ["old criterion"]
        legacy_project = dict(project)
        legacy_project["revision"] += 1
        legacy_project["state_model_version"] = "1.0.0"
        self.store.commit([
            self.store._change("task", legacy_task, task["revision"], "test.legacy-task"),
            self.store._change("project", legacy_project, project["revision"], "test.legacy-project"),
        ], 2, self.session)
        self.assertTrue(migration_status(self.store)["migration_required"])
        migrated = migrate_to_v11(self.store, 4, self.session)
        self.assertTrue(migrated["changed"])
        current_task = self.store.show_entity("task", task["id"])
        self.assertEqual(current_task["acceptance_criteria"][0]["text"], "old criterion")
        self.assertTrue(current_task["acceptance_criteria"][0]["id"].startswith("ACPT-"))
        again = migrate_to_v11(self.store, 6, self.session)
        self.assertFalse(again["changed"])

    def test_capacity_report_has_explicit_limits_and_warnings(self) -> None:
        report = self.store.capacity_report({"events": 1})
        self.assertFalse(report["within_limits"])
        self.assertIn("events", {item["resource"] for item in report["warnings"]})
        self.assertGreaterEqual(report["usage"]["bytes"], 1)


if __name__ == "__main__":
    unittest.main()
