from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


SYSTEM_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = SYSTEM_ROOT.parent
sys.path.insert(0, str(SYSTEM_ROOT))

from maintenance_runtime import prepare_workspace, repack_workspace, test_workspace  # noqa: E402
from state_core import StateError  # noqa: E402


class MaintenanceRuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.temporary = tempfile.TemporaryDirectory(prefix="aic-maintenance-test-")
        cls.root = Path(cls.temporary.name)
        cls.project = cls.root / "project"
        cls.project.mkdir()
        cls.source_zip = cls.root / "source.zip"
        process = subprocess.run(
            [sys.executable, str(SYSTEM_ROOT / "maintenance" / "repack.py"), "--package-root", str(PACKAGE_ROOT), "--output", str(cls.source_zip)],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120,
        )
        if process.returncode != 0:
            raise RuntimeError(process.stdout + process.stderr)
        cls.source_hash = hashlib.sha256(cls.source_zip.read_bytes()).hexdigest()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.temporary.cleanup()

    def test_prepare_modify_test_and_repack_is_self_contained(self) -> None:
        if os.environ.get("AIC_MAINTENANCE_NESTED") == "1":
            self.skipTest("avoid recursive maintenance self-test")
        workspace = self.root / "maintenance-workspace"
        prepared = prepare_workspace(self.project, str(self.source_zip), str(workspace), self.source_hash)
        self.assertEqual(Path(prepared["workspace"]), workspace)

        package_path = workspace / "PACKAGE.json"
        package = json.loads(package_path.read_text(encoding="utf-8"))
        package["package_version"] = "7.0.0-selftest"
        package_path.write_text(json.dumps(package, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        readme = workspace / ".ai-system" / "README.md"
        readme.write_text(readme.read_text(encoding="utf-8") + "\n维护演练修复。\n", encoding="utf-8")

        tested = test_workspace(self.project, str(workspace), "test_*.py")
        first = repack_workspace(self.project, str(workspace), str(self.root / "candidate-one.zip"), tested["report"])
        second = repack_workspace(self.project, str(workspace), str(self.root / "candidate-two.zip"), tested["report"])
        self.assertEqual(first["package"]["package_version"], "7.0.0-selftest")
        self.assertEqual(first["sha256"], second["sha256"])

    def test_prepare_rejects_workspace_inside_project(self) -> None:
        with self.assertRaises(StateError) as raised:
            prepare_workspace(self.project, str(self.source_zip), str(self.project / "maintenance"), self.source_hash)
        self.assertEqual(raised.exception.code, "PATH_MAINTENANCE_INSIDE_PROJECT")

    def test_prepare_rejects_wrong_hash(self) -> None:
        with self.assertRaises(StateError) as raised:
            prepare_workspace(self.project, str(self.source_zip), str(self.root / "wrong-hash"), "0" * 64)
        self.assertEqual(raised.exception.code, "PACKAGE_HASH_MISMATCH")

    def test_repack_rejects_workspace_changed_after_tests(self) -> None:
        if os.environ.get("AIC_MAINTENANCE_NESTED") == "1":
            self.skipTest("avoid recursive maintenance self-test")
        workspace = self.root / "stale-report-workspace"
        prepare_workspace(self.project, str(self.source_zip), str(workspace), self.source_hash)
        tested = test_workspace(self.project, str(workspace), "test_*.py")
        readme = workspace / ".ai-system" / "README.md"
        readme.write_text(readme.read_text(encoding="utf-8") + "\npost-test change\n", encoding="utf-8")
        with self.assertRaises(StateError) as changed:
            repack_workspace(
                self.project,
                str(workspace),
                str(self.root / "stale-report-candidate.zip"),
                tested["report"],
            )
        self.assertEqual(changed.exception.code, "MAINTENANCE_WORKSPACE_CHANGED")


if __name__ == "__main__":
    unittest.main()
