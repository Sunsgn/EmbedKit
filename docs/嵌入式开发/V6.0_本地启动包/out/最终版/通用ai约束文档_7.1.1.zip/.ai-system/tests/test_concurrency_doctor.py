from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sys
import tempfile
import unittest


SYSTEM_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SYSTEM_ROOT))

from concurrency import ConcurrencyManager  # noqa: E402
from doctor import apply_repair_plan, create_repair_plan, diagnose  # noqa: E402
from state_core import StateError, StateStore, atomic_write, pretty_bytes  # noqa: E402


class ConcurrencyDoctorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="aic-concurrency-test-")
        self.root = Path(self.temporary.name)
        self.store = StateStore(self.root)
        self.store.initialize("concurrency-test")
        self.first = self.store.start_session("first")["session"]["id"]
        self.second = self.store.start_session("second")["session"]["id"]
        self.manager = ConcurrencyManager(self.store)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def test_non_overlapping_scopes_parallel_and_overlap_blocked(self) -> None:
        left = self.manager.acquire(self.first, ["path:src/module-a"], 300)["lock"]
        right = self.manager.acquire(self.second, ["path:src/module-b"], 300)["lock"]
        self.assertNotEqual(left["id"], right["id"])
        with self.assertRaises(StateError) as conflict:
            self.manager.acquire(self.second, ["file:src/module-a/main.c"], 300)
        self.assertEqual(conflict.exception.code, "LOCK_SCOPE_CONFLICT")
        self.assertTrue(self.manager.assert_write_allowed(self.first, ["file:src/module-a/main.c"])["allowed"])
        with self.assertRaises(StateError) as write_conflict:
            self.manager.assert_write_allowed(self.second, ["file:src/module-a/main.c"])
        self.assertEqual(write_conflict.exception.code, "LOCK_SCOPE_CONFLICT")
        current = self.store.context()["current"]
        self.assertEqual(set(current["active_locks"]), {left["id"], right["id"]})
        self.manager.release(left["id"], self.first)
        replacement = self.manager.acquire(self.second, ["file:src/module-a/main.c"], 300)["lock"]
        self.assertEqual(replacement["status"], "ACTIVE")

    def test_owner_checks_renew_and_session_end(self) -> None:
        lock = self.manager.acquire(self.first, ["task:TASK-EXAMPLE"], 300)["lock"]
        with self.assertRaises(StateError) as wrong_owner:
            self.manager.release(lock["id"], self.second)
        self.assertEqual(wrong_owner.exception.code, "LOCK_NOT_OWNER")
        renewed = self.manager.renew(lock["id"], self.first, 600)["lock"]
        self.assertEqual(renewed["lease_seconds"], 600)
        with self.assertRaises(StateError) as active_lock:
            self.manager.end_session(self.first)
        self.assertEqual(active_lock.exception.code, "SESSION_ACTIVE_LOCKS")
        self.manager.release(lock["id"], self.first)
        ended = self.manager.end_session(self.first)["session"]
        self.assertEqual(ended["status"], "ENDED")

    def test_expired_lock_requires_review_then_controlled_recovery(self) -> None:
        lock = self.manager.acquire(self.first, ["path:application"], 300)["lock"]
        past = (datetime.now(timezone.utc) - timedelta(minutes=10)).isoformat(timespec="milliseconds").replace("+00:00", "Z")
        lock["lease_expires_at"] = past
        atomic_write(self.store.run / "locks" / f"{lock['id']}.json", pretty_bytes(lock))
        session_path = self.store.run / "sessions" / f"{self.first}.json"
        session = json.loads(session_path.read_text(encoding="utf-8"))
        session["lease_expires_at"] = past
        atomic_write(session_path, pretty_bytes(session))
        with self.assertRaises(StateError) as blocked:
            self.manager.acquire(self.second, ["file:application/main.c"], 300)
        self.assertEqual(blocked.exception.code, "LOCK_EXPIRED_NEEDS_REVIEW")
        with self.assertRaises(StateError) as approval:
            self.manager.recover_expired(lock["id"], self.second, False)
        self.assertEqual(approval.exception.code, "USER_DECISION_REQUIRED")
        recovered = self.manager.recover_expired(lock["id"], self.second, True)["lock"]
        self.assertEqual(recovered["status"], "RECOVERED")

    def test_doctor_replays_corrupt_entity_snapshot_with_backup(self) -> None:
        task = self.store.create_task("repair", "replay entity", 1, self.first, ["healthy"])["task"]
        task_path = self.store._entity_path("task", task["id"])
        damaged = json.loads(task_path.read_text(encoding="utf-8"))
        damaged["title"] = "tampered"
        task_path.write_bytes(b"\xef\xbb\xbf" + json.dumps(damaged).encode("utf-8"))
        diagnosis = diagnose(self.store)
        self.assertIn("ENTITY_SNAPSHOT_INVALID", {item["code"] for item in diagnosis["findings"]})
        planned = create_repair_plan(self.store)
        applied = apply_repair_plan(self.store, planned["path"], self.first, True)
        self.assertTrue(applied["post_diagnosis"]["healthy"])
        restored = self.store._load_entity("task", task["id"])
        self.assertEqual(restored["title"], "repair")
        reports = list((self.root / ".ai" / "audit" / "repairs").glob("RPR-*/report.json"))
        self.assertEqual(len(reports), 1)

    def test_authoritative_event_damage_forces_read_only(self) -> None:
        event_path = next((self.store.events).glob("*.jsonl"))
        event_path.write_text(event_path.read_text(encoding="utf-8").replace("project.created", "project.damaged"), encoding="utf-8")
        diagnosis = diagnose(self.store)
        self.assertTrue(diagnosis["read_only_required"])
        plan = create_repair_plan(self.store)["plan"]
        self.assertIn("MANUAL_AUTHORITATIVE_RECOVERY", {item["type"] for item in plan["actions"]})

    def test_incomplete_uncommitted_transaction_is_preserved_as_aborted(self) -> None:
        transaction = {
            "schema": "aic.committed-transaction", "schema_version": "1.0.0",
            "transaction_id": "TXN-ORPHAN", "session_id": self.first, "phase": "PREPARED",
        }
        path = self.store.run / "transactions" / "TXN-ORPHAN.json"
        atomic_write(path, pretty_bytes(transaction))
        planned = create_repair_plan(self.store)
        applied = apply_repair_plan(self.store, planned["path"], self.first, True)
        self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["phase"], "ABORTED")
        self.assertTrue(applied["post_diagnosis"]["healthy"])


if __name__ == "__main__":
    unittest.main()
