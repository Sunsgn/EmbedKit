#!/usr/bin/env python3
"""Explicit, idempotent structured-state migrations."""

from __future__ import annotations

from typing import Any

from lifecycle import acceptance_records
from state_core import StateError, StateStore, utc_now


CURRENT_STATE_MODEL_VERSION = "1.1.0"


def migration_status(store: StateStore) -> dict[str, Any]:
    context = store.context()
    project = store.show_entity("project", context["current"]["project_id"])
    current = project.get("state_model_version", "1.0.0")
    legacy_tasks = []
    offset = 0
    while True:
        page = store.list_entities("task", limit=200, offset=offset)
        for task in page["items"]:
            if any(not isinstance(item, dict) for item in task.get("acceptance_criteria", [])):
                legacy_tasks.append(task["id"])
        if not page["has_more"]:
            break
        offset += len(page["items"])
    return {
        "current_version": current, "target_version": CURRENT_STATE_MODEL_VERSION,
        "migration_required": current != CURRENT_STATE_MODEL_VERSION or bool(legacy_tasks),
        "legacy_task_ids": legacy_tasks,
    }


def migrate_to_v11(store: StateStore, expected_state_revision: int, session_id: str) -> dict[str, Any]:
    status = migration_status(store)
    if not status["migration_required"]:
        return {"changed": False, "status": status, "state_revision": expected_state_revision}
    context = store.context()
    project = store.show_entity("project", context["current"]["project_id"])
    changes = []
    migrated_tasks = []
    for task_id in status["legacy_task_ids"]:
        task = store.show_entity("task", task_id)
        updated = dict(task)
        updated["revision"] = task["revision"] + 1
        updated["acceptance_criteria_legacy"] = [str(item) for item in task.get("acceptance_criteria", [])]
        updated["acceptance_criteria"] = acceptance_records(task)
        updated["updated_at"] = utc_now()
        updated["updated_by"] = session_id
        changes.append(store._change("task", updated, task["revision"], "task.acceptance-model.migrated"))
        migrated_tasks.append(task_id)
    updated_project = dict(project)
    updated_project["revision"] = project["revision"] + 1
    updated_project["state_model_version"] = CURRENT_STATE_MODEL_VERSION
    updated_project["updated_at"] = utc_now()
    updated_project["updated_by"] = session_id
    changes.append(store._change("project", updated_project, project["revision"], "project.state-model.migrated"))
    committed = store.commit(changes, expected_state_revision, session_id)
    return {"changed": True, "from_version": status["current_version"], "to_version": CURRENT_STATE_MODEL_VERSION, "migrated_task_ids": migrated_tasks, **committed}
