# AI 嵌入式工程统一约束包 V6.2.0-RC2.4

本约束包面向不同类型的研发项目；项目实际启用的软件、硬件、PCB、测试和其他专业规范由项目识别与任务范围决定。AI 工程约束体系和辅助工具统一存放在 `.ai/` 目录。

- 约束包规则入口：`.ai/AGENTS.md`
- AI 工具通用说明：`.ai/AI-INSTRUCTIONS.md`
- 规则索引：`.ai/.ai-engineering/RULES_INDEX.md`
- 版本信息：`.ai/.ai-engineering/VERSION.md`
- 本地工具：`.ai/tools/`
- 研发报告与历史验证资料：`.ai/docs/`

## AI 工具启动说明

- Claude Code：读取根目录 `CLAUDE.md`，按其指令继续读取 `.ai/AGENTS.md`。
- Gemini：读取根目录 `GEMINI.md`，按其指令继续读取 `.ai/AGENTS.md`。
- Codex：本包按要求不在根目录放置 `AGENTS.md`。首次打开项目或新会话时，请明确要求 Codex 先读取 `.ai/AGENTS.md` 和 `.ai/AI-INSTRUCTIONS.md`。仅把 `AGENTS.md` 放在 `.ai/` 内，不能保证 Codex 将其作为项目根目录自动发现的指令文件。
- GitHub Copilot：`.ai/.github/copilot-instructions.md` 不是默认根级自动发现路径，需要在工作区配置中显式指定或要求 Copilot 显式读取。

## 常用工具

从项目根目录执行，例如：

```powershell
py -3 .\.ai\tools\init_cognition.py .
py -3 .\.ai\tools\validate_package.py
py -3 .\.ai\tools\test_l0_rc22.py
```

注意：包级完整性校验应在独立的 `.ai/` 包目录执行。若项目 `.ai/` 同时包含项目运行时认知文件，须按校验器定义区分包文件与项目运行时文件，不要对混合目录执行精确文件集合校验。

## V6.2.0-RC2.4 通用接入与增量合并

- 通用初始化指令不绑定某个特定项目、RTOS、芯片、IDE 或单一项目类型。
- 根目录 `CLAUDE.md`、`GEMINI.md`、`README.md` 视为项目现有文件；已存在时必须读取、备份并增量合并，不得直接覆盖。
- 根目录已有 `AGENTS.md`、`AI-INSTRUCTIONS.md` 或其他 AI 工具文件时必须保留，不得为了符合本包默认布局而删除或移动。
- `.ai/` 按文件和目录职责增量接入；项目认知档案、任务记录、测试证据和本地规则不得整体替换。
- 推荐使用单独交付的《AI工程约束包通用接入与初始化执行指令.md》完成自动化接入。
- 具体规则见 `.ai/.ai-engineering/installation/新项目安装.md` 和 `.ai/.ai-engineering/installation/已有项目增量接入.md`。
