#!/usr/bin/env python3
"""Regenerate the package manifest and create a deterministic candidate ZIP."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import zipfile


ENTRYPOINT_TARGETS = {
    "entrypoints/AGENTS.md": "AGENTS.md",
    "entrypoints/CLAUDE.md": "CLAUDE.md",
    "entrypoints/GEMINI.md": "GEMINI.md",
    "entrypoints/copilot-instructions.md": ".github/copilot-instructions.md",
}


def configure_stdio() -> None:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def mapping(relative: str) -> tuple[str, str]:
    if relative in ENTRYPOINT_TARGETS:
        return "managed_block", ENTRYPOINT_TARGETS[relative]
    if relative == "PACKAGE.json":
        return "package_file", ".ai/system/PACKAGE.json"
    if relative == "bootstrap.py":
        return "package_file", ".ai/system/bootstrap.py"
    if relative.startswith(".ai-system/"):
        return "package_file", ".ai/system/" + relative[len(".ai-system/"):]
    if relative.startswith("payload/"):
        return "package_file", relative[len("payload/"):]
    raise ValueError(f"unrecognized package member: {relative}")


def main() -> int:
    configure_stdio()
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", default=".")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    root = Path(args.package_root).resolve()
    output = Path(args.output).resolve()
    if output.is_relative_to(root):
        parser.error("output must be outside package root")
    package = json.loads((root / "PACKAGE.json").read_text(encoding="utf-8"))
    files = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        relative = path.relative_to(root).as_posix()
        if relative == "PACKAGE_MANIFEST.json":
            continue
        strategy, target = mapping(relative)
        data = path.read_bytes()
        files.append({
            "path": relative,
            "sha256": sha256(data),
            "size": len(data),
            "strategy": strategy,
            "target": target,
        })
    targets = [entry["target"].casefold() for entry in files]
    if len(targets) != len(set(targets)):
        raise SystemExit("target collision detected")
    manifest = {
        "schema": "aic.package-manifest",
        "schema_version": "1.0.0",
        "package_id": package["package_id"],
        "package_version": package["package_version"],
        "generated_at": package["created_at"],
        "hash_algorithm": "SHA-256",
        "files": files,
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")
    (root / "PACKAGE_MANIFEST.json").write_bytes(manifest_bytes)
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_name(output.name + ".tmp")
    if temp.exists():
        temp.unlink()
    members = [path for path in root.rglob("*") if path.is_file() and "__pycache__" not in path.parts]
    with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(members, key=lambda item: item.relative_to(root).as_posix()):
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(2026, 11, 17, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    temp.replace(output)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    print(json.dumps({
        "ok": True,
        "code": "PACKAGE_REPACKED",
        "output": str(output),
        "sha256": digest,
        "members": len(members),
        "manifest_entries": len(files),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
