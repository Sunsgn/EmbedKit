<!-- AI-CONSTRAINTS:BEGIN managed version=1 -->
## AI 工程约束系统入口

开始任何项目任务前，先读取 `.ai/system/ENTRYPOINT.md`。如果当前客户端能够运行本地工具，执行 `python .ai/system/aic.py status --json`；否则明确报告 `LOCAL_RUNTIME_UNAVAILABLE`，不得直接编辑状态文件模拟初始化或状态更新成功。
<!-- AI-CONSTRAINTS:END managed -->
