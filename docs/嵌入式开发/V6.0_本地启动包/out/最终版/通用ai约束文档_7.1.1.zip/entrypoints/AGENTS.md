<!-- AI-CONSTRAINTS:BEGIN managed version=1 -->
## AI 工程约束系统入口

开始任何项目任务前，必须读取 `.ai/system/ENTRYPOINT.md`，运行 `python .ai/system/aic.py status --json`，并按回执加载项目事实、当前状态和任务相关规则。不得把入口存在描述为规则已经实际加载。
<!-- AI-CONSTRAINTS:END managed -->
